-- cPanel mysql backup
GRANT USAGE ON *.* TO 'nononick'@'185.130.50.190' IDENTIFIED BY PASSWORD '*19A0F4690AA6C38B7641AC247C24410584C2129D';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick'@'185.130.50.190';
GRANT USAGE ON *.* TO 'nononick'@'a2891.calalemedba.com' IDENTIFIED BY PASSWORD '*19A0F4690AA6C38B7641AC247C24410584C2129D';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick'@'a2891.calalemedba.com';
GRANT USAGE ON *.* TO 'nononick'@'localhost' IDENTIFIED BY PASSWORD '*19A0F4690AA6C38B7641AC247C24410584C2129D';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick'@'localhost';
GRANT USAGE ON *.* TO 'nononick'@'sarv.shetabanhost.com' IDENTIFIED BY PASSWORD '*19A0F4690AA6C38B7641AC247C24410584C2129D';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick'@'sarv.shetabanhost.com';
GRANT USAGE ON *.* TO 'nononick_admin'@'185.130.50.190' IDENTIFIED BY PASSWORD '*7A7BED42179AA489B652310D6ABCB2FDA492EE87';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick_admin'@'185.130.50.190';
GRANT USAGE ON *.* TO 'nononick_admin'@'a2891.calalemedba.com' IDENTIFIED BY PASSWORD '*7A7BED42179AA489B652310D6ABCB2FDA492EE87';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick_admin'@'a2891.calalemedba.com';
GRANT USAGE ON *.* TO 'nononick_admin'@'localhost' IDENTIFIED BY PASSWORD '*7A7BED42179AA489B652310D6ABCB2FDA492EE87';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick_admin'@'localhost';
GRANT USAGE ON *.* TO 'nononick_admin'@'sarv.shetabanhost.com' IDENTIFIED BY PASSWORD '*7A7BED42179AA489B652310D6ABCB2FDA492EE87';
GRANT ALL PRIVILEGES ON `nononick\_sun\_panel\_db`.* TO 'nononick_admin'@'sarv.shetabanhost.com';
