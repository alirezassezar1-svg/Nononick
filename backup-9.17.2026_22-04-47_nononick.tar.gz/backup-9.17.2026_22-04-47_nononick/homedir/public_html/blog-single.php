<?php
/**
 * Nononik — صفحه‌ی اختصاصی هر مقاله (برای ایندکس شدن جدا در گوگل)
 * آدرس: blog-single.php?slug=چرا-وب-سایت
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$slug = trim($_GET['slug'] ?? '');
if ($slug === '') {
    http_response_code(404);
    $pageTitle = 'مقاله پیدا نشد | Nononik';
    require_once __DIR__ . '/includes/site-header.php';
    echo '<section class="section"><div class="wrap"><p class="empty-note">مقاله‌ی موردنظر پیدا نشد.</p></div></section>';
    require_once __DIR__ . '/includes/site-footer.php';
    exit;
}

$stmt = db()->prepare("SELECT * FROM articles WHERE slug = ? AND status = 'published' LIMIT 1");
$stmt->execute([$slug]);
$article = $stmt->fetch();

if (!$article) {
    http_response_code(404);
    $pageTitle = 'مقاله پیدا نشد | Nononik';
    require_once __DIR__ . '/includes/site-header.php';
    echo '<section class="section"><div class="wrap"><p class="empty-note">مقاله‌ی موردنظر پیدا نشد یا هنوز منتشر نشده.</p><a href="blog.php" class="btn btn-outline btn-sm" style="width:auto">بازگشت به مقالات</a></div></section>';
    require_once __DIR__ . '/includes/site-footer.php';
    exit;
}

// گالری و فایل‌های پیوست همین مقاله
$gallery = db()->prepare('SELECT * FROM article_images WHERE article_id = ? ORDER BY sort_order, id');
$gallery->execute([$article['id']]);
$gallery = $gallery->fetchAll();

$assets = db()->prepare("SELECT * FROM media_assets WHERE module = 'article' AND item_id = ? ORDER BY created_at");
$assets->execute([$article['id']]);
$assets = $assets->fetchAll();

$plainExcerpt = mb_substr(strip_tags($article['content'] ?? ''), 0, 155);

// --- SEO/meta که قبل از include site-header.php ست می‌شن ---
$pageTitle        = $article['title'] . ' | Nononik';
$pageDescription  = $plainExcerpt !== '' ? $plainExcerpt . '…' : 'مقاله‌ی ' . $article['title'] . ' از آژانس Nononik.';
$currentPage      = 'blog.php'; // برای هایلایت درست منوی «مقالات»
$siteDomainForSchema = 'https://nononick.ir';
$canonicalUrl     = $siteDomainForSchema . '/blog-single.php?slug=' . rawurlencode($article['slug']);
$ogImageUrl       = $article['image'] ? ($siteDomainForSchema . '/' . ltrim(str_replace($siteDomainForSchema, '', image_url($article['image'], 'articles')), '/')) : null;

$extraSchemaGraph = [[
    '@type'            => 'Article',
    'headline'         => $article['title'],
    'description'      => $pageDescription,
    'author'           => ['@type' => 'Person', 'name' => $article['author'] ?: 'Nononik'],
    'datePublished'    => date('c', strtotime($article['created_at'])),
    'dateModified'     => date('c', strtotime($article['created_at'])),
    'mainEntityOfPage' => $canonicalUrl,
    'image'            => $ogImageUrl ?: ($siteDomainForSchema . '/assets/images/site/og-cover.png'),
    'publisher'        => ['@type' => 'Organization', 'name' => 'Nononik'],
]];

require_once __DIR__ . '/includes/site-header.php';
?>
<section class="hero page-head" style="padding:70px 0 40px;">
  <div class="wrap">
    <span class="hero-badge stagger-item"><i class="fa-solid fa-newspaper"></i> مقاله</span>
    <h1 class="stagger-item"><?= e($article['title']) ?></h1>
    <p class="stagger-item"><i class="fa-regular fa-user"></i> <?= e($article['author'] ?? 'Admin') ?> &middot; <?= time_ago($article['created_at']) ?></p>
  </div>
</section>

<section class="section" style="padding-top:10px;">
  <div class="wrap" style="max-width:820px;">
    <?php if ($article['image']): ?>
    <img loading="lazy" decoding="async" src="<?= e(image_url($article['image'], 'articles')) ?>" alt="<?= e($article['title']) ?>" style="width:100%;border-radius:var(--radius-md);margin-bottom:26px;">
    <?php endif; ?>

    <article class="article-body" style="line-height:2;font-size:15.5px;white-space:pre-line;">
      <?= nl2br(e($article['content'])) ?>
    </article>

    <?php if ($gallery): ?>
    <div class="grid grid-3" style="margin-top:30px;">
      <?php foreach ($gallery as $g): ?>
      <img loading="lazy" decoding="async" src="<?= e(image_url($g['image'], 'articles')) ?>" alt="<?= e($article['title']) ?> — تصویر گالری" style="border-radius:var(--radius-sm);">
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($assets): ?>
    <div class="card glass" style="margin-top:30px;padding:18px;">
      <h3 style="margin-bottom:12px;font-size:15px;">فایل‌های پیوست</h3>
      <?php foreach ($assets as $a): $embeddable = in_array($a['ext'], ['html', 'htm', 'svg'], true); ?>
        <?php if ($embeddable): ?>
        <div style="margin-bottom:16px;">
          <p style="font-size:13px;color:var(--text-2);margin-bottom:8px;"><i class="fa-solid fa-code"></i> <?= e($a['original_name'] ?: $a['file_name']) ?></p>
          <iframe src="asset-embed.php?id=<?= (int) $a['id'] ?>" sandbox="allow-scripts" loading="lazy"
                  style="width:100%;height:480px;border:1px solid var(--color-border,#333);border-radius:var(--radius-sm);background:#fff;"></iframe>
        </div>
        <?php else: ?>
        <a href="<?= e(asset_url($a['file_name'], 'articles')) ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm" style="width:auto;display:inline-flex;margin:0 6px 6px 0;">
          <i class="fa-solid <?= e(asset_icon($a['ext'])) ?>"></i> <?= e($a['original_name'] ?: $a['file_name']) ?>
        </a>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div style="margin-top:36px;">
      <a href="blog.php" class="btn btn-outline btn-sm" style="width:auto"><i class="fa-solid fa-arrow-right"></i> بازگشت به مقالات</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
