/**
 * Sun Panel — Command Palette (Raycast-style)
 * Ctrl+K / Cmd+K to open, fuzzy search all commands and resources
 */

class CommandPalette {
  constructor() {
    this.isOpen = false;
    this.selectedIndex = 0;
    this.searchQuery = '';
    this.commands = [];
    this.resources = [];
    this.filteredResults = [];
    this.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    this.init();
  }

  /**
   * Initialize command palette
   */
  init() {
    this.createDOM();
    this.registerKeyBindings();
    this.loadCommands();
    this.setupEventListeners();
  }

  /**
   * Create command palette DOM elements
   */
  createDOM() {
    const html = `
      <div class="command-palette-overlay" id="commandPaletteOverlay"></div>
      <div class="command-palette" id="commandPalette">
        <div class="command-palette-input-wrapper">
          <i class="fa-solid fa-magnifying-glass command-palette-icon"></i>
          <input
            type="text"
            class="command-palette-input"
            id="commandPaletteInput"
            placeholder="جستجو دستورات، صفحات و منابع..."
            autocomplete="off"
          >
          <span class="command-palette-shortcut">
            <span class="command-key">ESC</span>
            برای بستن
          </span>
        </div>
        <div class="command-palette-results" id="commandPaletteResults"></div>
        <div class="command-palette-hints">
          <div class="command-palette-hint">
            <span class="command-palette-hint-key">↑↓</span>
            <span>ناوبری</span>
          </div>
          <div class="command-palette-hint">
            <span class="command-palette-hint-key">⏎</span>
            <span>انتخاب</span>
          </div>
          <div class="command-palette-hint">
            <span class="command-palette-hint-key">ESC</span>
            <span>بستن</span>
          </div>
        </div>
      </div>
    `;

    const container = document.createElement('div');
    container.innerHTML = html;
    document.body.appendChild(container);

    this.overlay = document.getElementById('commandPaletteOverlay');
    this.palette = document.getElementById('commandPalette');
    this.input = document.getElementById('commandPaletteInput');
    this.resultsContainer = document.getElementById('commandPaletteResults');
  }

  /**
   * Register keyboard shortcuts
   */
  registerKeyBindings() {
    document.addEventListener('keydown', (e) => {
      // Ctrl+K or Cmd+K to open
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        this.toggle();
      }

      // Only handle shortcuts when palette is open
      if (!this.isOpen) return;

      switch (e.key) {
        case 'Escape':
          e.preventDefault();
          this.close();
          break;

        case 'ArrowUp':
          e.preventDefault();
          this.selectPrevious();
          break;

        case 'ArrowDown':
          e.preventDefault();
          this.selectNext();
          break;

        case 'Enter':
          e.preventDefault();
          this.executeSelected();
          break;

        default:
          break;
      }
    });
  }

  /**
   * Load available commands
   */
  loadCommands() {
    // Navigation commands
    this.commands.push({
      id: 'dashboard',
      title: 'داشبورد',
      subtitle: 'برو به صفحه ریشه',
      icon: 'fa-chart-line',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'index.php'
    });

    this.commands.push({
      id: 'projects',
      title: 'پروژه‌ها',
      subtitle: 'مدیریت پروژه‌ها',
      icon: 'fa-folder',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'projects.php'
    });

    this.commands.push({
      id: 'users',
      title: 'کاربران',
      subtitle: 'مدیریت کاربران سایت',
      icon: 'fa-users',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'users.php'
    });

    this.commands.push({
      id: 'admins',
      title: 'ادمین‌ها',
      subtitle: 'مدیریت ادمین‌های پنل',
      icon: 'fa-shield',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'admins.php'
    });

    this.commands.push({
      id: 'tasks',
      title: 'وظایف',
      subtitle: 'مدیریت و ترک‌کردن وظایف',
      icon: 'fa-tasks',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'tasks.php'
    });

    this.commands.push({
      id: 'messages',
      title: 'پیام‌ها',
      subtitle: 'مسایل تماس ارسال شده',
      icon: 'fa-envelope',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'messages.php'
    });

    this.commands.push({
      id: 'settings',
      title: 'تنظیمات',
      subtitle: 'تنظیمات سایت و امنیتی',
      icon: 'fa-cog',
      group: 'ناوبری',
      action: () => window.location.href = BASE_URL + 'settings.php'
    });

    // Action commands
    this.commands.push({
      id: 'toggle-theme',
      title: 'تعویض تم',
      subtitle: 'روشن/تاریک را تبدیل کنید',
      icon: 'fa-moon',
      group: 'عمل',
      action: () => this.toggleTheme()
    });

    this.commands.push({
      id: 'logout',
      title: 'خروج',
      subtitle: 'برای خروج از سیستم',
      icon: 'fa-sign-out-alt',
      group: 'عمل',
      action: () => window.location.href = BASE_URL + 'logout.php',
      badge: 'خطرناک'
    });

    // Help commands
    this.commands.push({
      id: 'keyboard-shortcuts',
      title: 'میانبرهای صفحه کلید',
      subtitle: 'نمایش همه میانبرها',
      icon: 'fa-keyboard',
      group: 'راهنما',
      action: () => this.showKeyboardShortcuts()
    });

    this.commands.push({
      id: 'search-global',
      title: 'جستجوی جهانی',
      subtitle: 'جستجو در تمام محتوا',
      icon: 'fa-search',
      group: 'راهنما',
      action: () => this.focusGlobalSearch()
    });
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Close on overlay click
    this.overlay.addEventListener('click', () => this.close());

    // Search input
    this.input.addEventListener('input', (e) => {
      this.searchQuery = e.target.value;
      this.filter();
      this.render();
    });

    // Click on result
    this.resultsContainer.addEventListener('click', (e) => {
      const item = e.target.closest('.command-palette-item');
      if (item) {
        const index = Array.from(this.resultsContainer.querySelectorAll('.command-palette-item')).indexOf(item);
        this.selectedIndex = index;
        this.executeSelected();
      }
    });

    // Hover effect
    this.resultsContainer.addEventListener('mouseover', (e) => {
      const item = e.target.closest('.command-palette-item');
      if (item) {
        const items = Array.from(this.resultsContainer.querySelectorAll('.command-palette-item'));
        this.selectedIndex = items.indexOf(item);
        this.updateSelection();
      }
    });
  }

  /**
   * Toggle command palette
   */
  toggle() {
    this.isOpen ? this.close() : this.open();
  }

  /**
   * Open command palette
   */
  open() {
    this.isOpen = true;
    this.selectedIndex = 0;
    this.searchQuery = '';

    // Add active class with animation
    if (!this.prefersReducedMotion) {
      if (typeof gsap !== 'undefined') {
        gsap.to(this.overlay, { opacity: 1, duration: 0.3 });
        gsap.fromTo(this.palette, { opacity: 0, scale: 0.95 }, { opacity: 1, scale: 1, duration: 0.4 });
      }
    }

    this.overlay.classList.add('active');
    this.palette.classList.add('active');
    this.input.value = '';
    this.input.focus();

    this.filter();
    this.render();
  }

  /**
   * Close command palette
   */
  close() {
    if (!this.isOpen) return;

    this.isOpen = false;
    this.palette.classList.add('closing');

    setTimeout(() => {
      this.overlay.classList.remove('active');
      this.palette.classList.remove('active', 'closing');
    }, this.prefersReducedMotion ? 0 : 300);
  }

  /**
   * Fuzzy search filter
   */
  filter() {
    if (!this.searchQuery.trim()) {
      this.filteredResults = this.commands;
      return;
    }

    const query = this.searchQuery.toLowerCase();
    this.filteredResults = this.commands.filter((cmd) => {
      const titleScore = this.fuzzyMatch(cmd.title.toLowerCase(), query);
      const subtitleScore = this.fuzzyMatch(cmd.subtitle?.toLowerCase() || '', query);
      return titleScore > 0 || subtitleScore > 0;
    });

    // Sort by match score
    this.filteredResults.sort((a, b) => {
      const aScore = Math.max(
        this.fuzzyMatch(a.title.toLowerCase(), query),
        this.fuzzyMatch(a.subtitle?.toLowerCase() || '', query)
      );
      const bScore = Math.max(
        this.fuzzyMatch(b.title.toLowerCase(), query),
        this.fuzzyMatch(b.subtitle?.toLowerCase() || '', query)
      );
      return bScore - aScore;
    });
  }

  /**
   * Fuzzy match scoring
   */
  fuzzyMatch(text, query) {
    const matches = [];
    let queryIdx = 0;
    let score = 0;

    for (let i = 0; i < text.length && queryIdx < query.length; i++) {
      if (text[i] === query[queryIdx]) {
        score += (query.length - queryIdx) * 10;
        matches.push(i);
        queryIdx++;
      }
    }

    if (queryIdx !== query.length) return 0;

    return score;
  }

  /**
   * Select previous item
   */
  selectPrevious() {
    this.selectedIndex = Math.max(0, this.selectedIndex - 1);
    this.updateSelection();
  }

  /**
   * Select next item
   */
  selectNext() {
    this.selectedIndex = Math.min(this.filteredResults.length - 1, this.selectedIndex + 1);
    this.updateSelection();
  }

  /**
   * Update selection UI
   */
  updateSelection() {
    const items = this.resultsContainer.querySelectorAll('.command-palette-item');
    items.forEach((item, idx) => {
      item.classList.toggle('active', idx === this.selectedIndex);
    });

    // Scroll into view
    const activeItem = items[this.selectedIndex];
    if (activeItem) {
      activeItem.scrollIntoView({ block: 'nearest' });
    }
  }

  /**
   * Execute selected command
   */
  executeSelected() {
    const selected = this.filteredResults[this.selectedIndex];
    if (selected && selected.action) {
      this.close();
      setTimeout(() => selected.action(), this.prefersReducedMotion ? 0 : 300);
    }
  }

  /**
   * Render results
   */
  render() {
    this.resultsContainer.innerHTML = '';

    if (this.filteredResults.length === 0) {
      this.resultsContainer.innerHTML = `
        <div class="command-palette-empty">
          <div class="command-palette-empty-icon">🔍</div>
          <div class="command-palette-empty-title">نتیجه‌ای یافت نشد</div>
          <div class="command-palette-empty-description">
            "$ {this.searchQuery}" را برای سایر نتایج امتحان کنید
          </div>
        </div>
      `;
      return;
    }

    // Group results
    const grouped = {};
    this.filteredResults.forEach((cmd) => {
      if (!grouped[cmd.group]) {
        grouped[cmd.group] = [];
      }
      grouped[cmd.group].push(cmd);
    });

    // Render groups
    Object.entries(grouped).forEach(([group, cmds]) => {
      const groupEl = document.createElement('div');
      groupEl.className = 'command-palette-group';

      const titleEl = document.createElement('div');
      titleEl.className = 'command-palette-group-title';
      titleEl.textContent = group;
      groupEl.appendChild(titleEl);

      cmds.forEach((cmd, idx) => {
        const isSelected = this.filteredResults.indexOf(cmd) === this.selectedIndex;
        const itemEl = document.createElement('div');
        itemEl.className = 'command-palette-item' + (isSelected ? ' active' : '');

        itemEl.innerHTML = `
          <div class="command-palette-item-icon">
            <i class="fa-solid ${cmd.icon}"></i>
          </div>
          <div class="command-palette-item-content">
            <div class="command-palette-item-title">${cmd.title}</div>
            <div class="command-palette-item-subtitle">${cmd.subtitle || ''}</div>
          </div>
          ${cmd.badge ? `<div class="command-palette-item-badge">${cmd.badge}</div>` : ''}
        `;

        groupEl.appendChild(itemEl);
      });

      this.resultsContainer.appendChild(groupEl);
    });
  }

  /**
   * Toggle light/dark theme
   */
  toggleTheme() {
    const current = localStorage.getItem('sunpanel-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    localStorage.setItem('sunpanel-theme', next);
    document.documentElement.setAttribute('data-theme', next);

    // Show toast
    if (window.motionSystem) {
      window.motionSystem.showToast(
        next === 'dark' ? '🌙 تم تاریک فعال شد' : '☀️ تم روشن فعال شد',
        'success'
      );
    }
  }

  /**
   * Show keyboard shortcuts help
   */
  showKeyboardShortcuts() {
    // This would open a modal with shortcuts
    console.log('Showing keyboard shortcuts');
  }

  /**
   * Focus global search
   */
  focusGlobalSearch() {
    this.close();
    const searchInput = document.querySelector('#globalSearchInput');
    if (searchInput) {
      searchInput.focus();
    }
  }
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.commandPalette = new CommandPalette();
});
