/**
 * Sun Panel — main.js
 * GSAP + ScrollTrigger cinematic 3D scroll animations
 * + general UI interactivity (modals, dropdowns, sidebar toggle)
 */

document.addEventListener('DOMContentLoaded', () => {

  /* ============================================================
     GSAP 3D SCROLL ANIMATIONS
     چرا تغییر کرد: قبلاً برای هر ردیف/کارت یک ScrollTrigger جدا ساخته
     می‌شد (ده‌ها/صدها تریگر روی صفحات با جدول یا لیست بلند)؛ هرکدوم
     موقع اسکرول باید موقعیتش رو جدا محاسبه کنه → روی اسکرول با قرقره‌ی
     موس (که فریم‌های پشت‌سرهم پرتاب می‌کنه) کار رشته‌ی اصلی سنگین می‌شد
     و صفحه/نشانگر جا می‌موند. با ScrollTrigger.batch همه‌ی موارد مشابه
     زیر یک شنونده‌ی اسکرولِ مشترک جمع می‌شن.
     ============================================================ */
  if (window.gsap && window.ScrollTrigger) {
    gsap.registerPlugin(ScrollTrigger);

    // Give the page real perspective for the 3D tilt to read clearly.
    // چرا تغییر کرد: قبلاً هر Tween یک transformPerspective جدا (900/1200/800/700)
    // برای خودش تعریف می‌کرد. چون این مقدار جزو state ترنسفرم المنته، وقتی انیمیشن
    // ورودیِ اسکرول (perspective 1200) هنوز تمام نشده و کاربر موس رو روی کارت
    // می‌بره (که perspective 700 می‌خواد)، GSAP این دو Tween رو روی هم overwrite
    // می‌کنه و عمق سه‌بعدی ناگهان عوض می‌شه → همون پرش دیده‌شده. الان یک
    // perspective ثابت روی خودِ کارت‌ها ست می‌شه و دیگه هیچ Tweenی مقدارش رو عوض
    // نمی‌کنه، فقط rotateX/rotateY تغییر می‌کنن.
    var CARD_PERSPECTIVE = 1000;
    if (document.querySelector('.content')) {
      gsap.set('.content', { transformStyle: 'preserve-3d' });
    }
    gsap.set('.stat-card, .card, .table-card, .service-tile, .project-tile', {
      transformPerspective: CARD_PERSPECTIVE,
      transformOrigin: 'center center'
    });

    function revealBatch(selector, fromVars, toVars, start) {
      var els = gsap.utils.toArray(selector);
      if (!els.length) return;
      gsap.set(els, fromVars);
      ScrollTrigger.batch(els, {
        start: start || 'top 92%',
        onEnter: function (batch) {
          gsap.to(batch, Object.assign({}, toVars, {
            stagger: 0.06,
            onStart: function () { batch.forEach(function (el) { el.style.willChange = 'transform, opacity'; }); },
            onComplete: function () { batch.forEach(function (el) { el.style.willChange = 'auto'; }); }
          }));
        },
        onLeaveBack: function (batch) {
          batch.forEach(function (el) { delete el.dataset.entered; });
          gsap.to(batch, Object.assign({}, fromVars, { duration: 0.35 }));
        }
      });
    }

    // Entrance: stat cards fly in with rotateX
    // چرا "entered" اضافه شد: تا انیمیشن ورودیِ یک کارت تمام نشده، افکت تیلتِ
    // هاور روی همون کارت غیرفعاله (پایین‌تر چک می‌شه) تا دو Tween هم‌زمان روی
    // rotateX/rotateY یک المنت رقابت نکنن.
    revealBatch('.stat-card',
      { opacity: 0, y: 70, rotateX: -55 },
      { opacity: 1, y: 0, rotateX: 0, duration: 1, ease: 'power4.out',
        onComplete: function () { this.targets().forEach(function (el) { el.dataset.entered = '1'; }); } }
    );

    // Big cards (welcome banner, chart, table, side cards) — deep 3D swing
    revealBatch('.card, .table-card',
      { opacity: 0, rotateX: 30, y: 90 },
      { opacity: 1, rotateX: 0, y: 0, duration: 1.1, ease: 'expo.out',
        onComplete: function () { this.targets().forEach(function (el) { el.dataset.entered = '1'; }); } },
      'top 90%'
    );

    // Service tiles — staggered cube-like reveal
    revealBatch('.service-tile, .project-tile',
      { opacity: 0, rotateY: -90 },
      { opacity: 1, rotateY: 0, duration: .9, ease: 'back.out(1.6)',
        onComplete: function () { this.targets().forEach(function (el) { el.dataset.entered = '1'; }); } },
      'top 94%'
    );

    // Table rows
    revealBatch('table.data-table tbody tr',
      { opacity: 0, x: 60, rotateX: -20, transformPerspective: 700 },
      { opacity: 1, x: 0, rotateX: 0, duration: .7, ease: 'power3.out' },
      'top 96%'
    );

    // Activity strip / message / event rows
    revealBatch('.activity-item, .message-item, .event-row, .tasks-list li',
      { opacity: 0, y: 40, rotateX: -35, transformPerspective: 800 },
      { opacity: 1, y: 0, rotateX: 0, duration: .8, ease: 'power3.out' },
      'top 96%'
    );

    // Welcome banner floating orbs / laptop — parallax on scroll
    gsap.utils.toArray('.welcome-card .visual').forEach((el) => {
      gsap.to(el, {
        rotateY: 18, rotateX: -10, y: -20,
        scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: 1.2 }
      });
    });

    // Page head cinematic entrance
    if (document.querySelector('.page-head')) {
      gsap.fromTo('.page-head', { opacity: 0, y: -30 }, { opacity: 1, y: 0, duration: .8, ease: 'power3.out' });
    }

    // Subtle continuous perspective drift on hover for any 3D card
    // چرا throttle شد: قبلاً روی هر پیکسل حرکت موس یک gsap.to جدید ساخته می‌شد؛
    // با requestAnimationFrame فقط یک‌بار در هر فریم اجرا می‌شه.
    document.querySelectorAll('.stat-card, .card, .service-tile, .project-tile').forEach(card => {
      let rafId = null, pendingEvent = null;
      card.addEventListener('mousemove', (e) => {
        // چرا: تا وقتی انیمیشن ورودیِ اسکرول همین کارت تمام نشده (data-entered
        // ست نشده)، تیلتِ هاور رو اجرا نمی‌کنیم؛ وگرنه دو Tween روی rotateX/Y
        // رقابت می‌کنن و کارت می‌پره.
        if (card.dataset.entered !== '1') return;
        pendingEvent = e;
        if (rafId) return;
        rafId = requestAnimationFrame(() => {
          const r = card.getBoundingClientRect();
          const x = (pendingEvent.clientX - r.left) / r.width - 0.5;
          const y = (pendingEvent.clientY - r.top) / r.height - 0.5;
          gsap.to(card, { rotateY: x * 10, rotateX: -y * 10, duration: .4, ease: 'power2.out', overwrite: 'auto' });
          rafId = null;
        });
      });
      card.addEventListener('mouseleave', () => {
        if (card.dataset.entered !== '1') return;
        gsap.to(card, { rotateY: 0, rotateX: 0, duration: .6, ease: 'power3.out', overwrite: 'auto' });
      });
    });
  }

  /* ============================================================
     UI: sidebar toggle (mobile)
     ============================================================ */
  const sidebarToggle = document.querySelector('[data-sidebar-toggle]');
  const sidebar = document.querySelector('.sidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  /* ============================================================
     UI: admin dropdown
     ============================================================ */
  const adminPill = document.querySelector('[data-admin-toggle]');
  const adminDropdown = document.querySelector('.admin-dropdown');
  if (adminPill && adminDropdown) {
    adminPill.addEventListener('click', (e) => {
      e.stopPropagation();
      adminDropdown.classList.toggle('show');
    });
    document.addEventListener('click', () => adminDropdown.classList.remove('show'));
  }

  /* ============================================================
     UI: modal open / close (data-modal-target / data-modal-close)
     ============================================================ */
  document.querySelectorAll('[data-modal-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.querySelector(btn.getAttribute('data-modal-target'));
      if (target) {
        target.classList.add('show');
        gsap.fromTo(target.querySelector('.modal-box'),
          { y: 60, opacity: 0, rotateX: -15 },
          { y: 0, opacity: 1, rotateX: 0, duration: .5, ease: 'power3.out' });
      }
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => btn.closest('.modal-overlay').classList.remove('show'));
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('show'); });
  });

  /* ============================================================
     UI: auto-hide flash alerts
     ============================================================ */
  const alertBox = document.querySelector('.alert');
  if (alertBox) {
    setTimeout(() => {
      gsap.to(alertBox, { opacity: 0, y: -10, duration: .5, onComplete: () => alertBox.remove() });
    }, 4000);
  }

  /* ============================================================
     UI: image preview on upload
     ============================================================ */
  document.querySelectorAll('input[type="file"][data-preview]').forEach(input => {
    input.addEventListener('change', () => {
      const img = document.querySelector(input.getAttribute('data-preview'));
      if (img && input.files[0]) {
        img.src = URL.createObjectURL(input.files[0]);
      }
    });
  });

  /* ============================================================
     UI: task toggle (AJAX)
     ============================================================ */
  document.querySelectorAll('.task-check').forEach(box => {
    box.addEventListener('click', () => {
      const id = box.getAttribute('data-id');
      const li = box.closest('li');
      fetch('tasks.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=toggle&id=${encodeURIComponent(id)}&csrf_token=${encodeURIComponent(window.CSRF_TOKEN || '')}`
      }).then(r => r.json()).then(res => {
        if (res.success) {
          box.classList.toggle('done');
          box.innerHTML = box.classList.contains('done') ? '<i class="fa-solid fa-check"></i>' : '';
          li.classList.toggle('done');
        }
      });
    });
  });

  /* ============================================================
     THEME: Dark / Light toggle (persisted in localStorage)
     ============================================================ */
  (function themeToggle() {
    const root = document.documentElement;
    const buttons = [document.getElementById('themeToggle'), document.getElementById('themeToggleSidebar')].filter(Boolean);

    function apply(theme) {
      root.setAttribute('data-theme', theme);
      localStorage.setItem('sunpanel-theme', theme);
      buttons.forEach(btn => {
        const icon = btn.querySelector('i');
        if (icon) icon.className = theme === 'light' ? 'fa-solid fa-sun' : 'fa-solid fa-circle-half-stroke';
      });
    }

    apply(root.getAttribute('data-theme') || 'dark');

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
        apply(next);
      });
    });
  })();

  /* ============================================================
     CUSTOM CURSOR
     ============================================================ */
  (function customCursor() {
    // غیرفعال شده: به‌جای دنبال‌کردن دستی نشانگر با GSAP، از همون نشانگر پیش‌فرض سیستم استفاده می‌کنیم
    return;
  })();

  /* ============================================================
     GLOBAL LIVE SEARCH
     ============================================================ */
  (function globalSearch() {
    const box = document.getElementById('globalSearch');
    const input = document.getElementById('globalSearchInput');
    const results = document.getElementById('globalSearchResults');
    if (!box || !input || !results) return;

    let debounceTimer = null;
    let activeIndex = -1;

    function render(items) {
      if (!items.length) {
        results.innerHTML = '<div class="sr-empty">نتیجه‌ای پیدا نشد</div>';
        return;
      }
      results.innerHTML = items.map((item, i) => `
        <div class="sr-item" data-url="${item.url}?id=${item.id}" data-index="${i}">
          <div>
            <div class="sr-label">${item.label}</div>
            <div class="sr-meta">${item.meta ?? ''}</div>
          </div>
          <span class="sr-type">${item.type}</span>
        </div>
      `).join('');
      activeIndex = -1;
    }

    function open() { results.classList.add('open'); }
    function close() { results.classList.remove('open'); }

    input.addEventListener('input', () => {
      const q = input.value.trim();
      clearTimeout(debounceTimer);
      if (q.length < 2) { close(); return; }

      results.innerHTML = '<div class="sr-loading"><i class="fa-solid fa-spinner fa-spin"></i> در حال جستجو...</div>';
      open();

      debounceTimer = setTimeout(() => {
        fetch(`global-search.php?q=${encodeURIComponent(q)}`)
          .then(r => r.json())
          .then(data => render(data.results || []))
          .catch(() => { results.innerHTML = '<div class="sr-empty">خطا در جستجو</div>'; });
      }, 280);
    });

    results.addEventListener('click', e => {
      const item = e.target.closest('.sr-item');
      if (item) window.location.href = item.getAttribute('data-url');
    });

    input.addEventListener('keydown', e => {
      const items = [...results.querySelectorAll('.sr-item')];
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        activeIndex = Math.min(activeIndex + 1, items.length - 1);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        activeIndex = Math.max(activeIndex - 1, 0);
      } else if (e.key === 'Enter' && activeIndex >= 0 && items[activeIndex]) {
        window.location.href = items[activeIndex].getAttribute('data-url');
        return;
      } else if (e.key === 'Escape') {
        close(); input.blur(); return;
      } else {
        return;
      }
      items.forEach((it, i) => it.classList.toggle('active', i === activeIndex));
      items[activeIndex]?.scrollIntoView({ block: 'nearest' });
    });

    document.addEventListener('click', e => { if (!box.contains(e.target)) close(); });

    // Ctrl+K / Cmd+K shortcut
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        input.focus();
      }
    });
  })();

  /* ============================================================
     CINEMATIC PAGE TRANSITIONS (GSAP)
     ============================================================ */
  (function pageTransitions() {
    const overlay = document.getElementById('pageTransition');
    if (!overlay || !window.gsap) return;

    // Entrance: fade the overlay away to reveal the page
    gsap.set(overlay, { opacity: 1 });
    gsap.to(overlay, { opacity: 0, duration: 0.6, ease: 'power2.out', onComplete: () => overlay.style.pointerEvents = 'none' });
    if (document.querySelector('.main')) {
      gsap.from('.main', { opacity: 0, y: 16, duration: 0.5, ease: 'power2.out' });
    }

    // Exit: cover the page before navigating to an internal link
    document.querySelectorAll('a[href]').forEach(link => {
      const url = link.getAttribute('href');
      if (!url || url.startsWith('#') || url.startsWith('http') || link.target === '_blank' || link.hasAttribute('data-no-transition')) return;

      link.addEventListener('click', e => {
        e.preventDefault();
        overlay.style.pointerEvents = 'auto';
        gsap.to(overlay, {
          opacity: 1, duration: 0.45, ease: 'power2.in',
          onComplete: () => { window.location.href = url; }
        });
      });
    });
  })();

  /* ============================================================
     TOAST NOTIFICATIONS — window.showToast(message, type)
     ============================================================ */
  window.showToast = function (message, type = 'info', duration = 3500) {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i><span>${message}</span>`;
    container.appendChild(toast);

    if (window.gsap) {
      gsap.to(toast, { opacity: 1, y: 0, duration: 0.35, ease: 'back.out(1.7)' });
      setTimeout(() => {
        gsap.to(toast, { opacity: 0, x: -30, duration: 0.3, onComplete: () => toast.remove() });
      }, duration);
    } else {
      toast.style.opacity = 1;
      setTimeout(() => toast.remove(), duration);
    }
  };

  /* ============================================================
     PARALLAX: subtle mouse-based glow orb movement (Visual System)
     ============================================================ */
  (function orbParallax() {
    if (!window.gsap) return;
    const orbs = document.querySelectorAll('.orb');
    if (!orbs.length) return;
    window.addEventListener('mousemove', e => {
      const x = (e.clientX / window.innerWidth - 0.5) * 24;
      const y = (e.clientY / window.innerHeight - 0.5) * 24;
      orbs.forEach((orb, i) => {
        gsap.to(orb, { x: x * (i + 1) * 0.6, y: y * (i + 1) * 0.6, duration: 0.6, ease: 'power2.out' });
      });
    });
  })();

});
