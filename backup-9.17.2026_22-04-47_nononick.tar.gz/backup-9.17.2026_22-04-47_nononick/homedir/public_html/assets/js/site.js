// Nononik — Public site: mobile nav toggle
// چرا: تم/کرسر سفارشی/page-transition دیگر اینجا نیست — همه‌ی این‌ها را main.js
// مشترک با پنل ادمین/کاربر مدیریت می‌کند تا هیچ منطقی دوبار نوشته نشود.
(function () {
  const toggle = document.getElementById('mobileNavToggle');
  const links = document.getElementById('siteLinks');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    links.classList.toggle('open');
  });

  links.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => links.classList.remove('open'));
  });
})();
