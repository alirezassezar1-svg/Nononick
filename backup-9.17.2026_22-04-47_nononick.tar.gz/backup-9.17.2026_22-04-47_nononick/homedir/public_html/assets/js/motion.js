/**
 * Sun Panel — Advanced Motion System with GSAP
 * Micro-interactions, page transitions, scroll animations, 3D effects
 */

class MotionSystem {
  constructor() {
    this.tl = null;
    this.scrollTriggers = [];
    this.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (!this.prefersReducedMotion && typeof gsap === 'undefined') {
      console.warn('GSAP not loaded. Motion System running in fallback mode.');
    }
    
    this.init();
  }

  /**
   * Initialize motion system
   */
  init() {
    if (this.prefersReducedMotion) return;

    this.registerGSAPDefaults();
    this.setupPageTransitions();
    this.setupMicroInteractions();
    this.setupScrollAnimations();
    this.setupScrollTriggers();
  }

  /**
   * Set GSAP defaults for consistency
   */
  registerGSAPDefaults() {
    if (typeof gsap === 'undefined') return;

    gsap.config({ nullTargetAction: 'ignore' });
    gsap.registerPlugin(ScrollTrigger);
    gsap.set('body', { perspective: 1600 });
  }

  /**
   * Smooth page transitions
   */
  setupPageTransitions() {
    if (typeof gsap === 'undefined') return;

    // Page entrance animation
    const pageEnter = () => {
      if (document.querySelector('.page-content')) {
        gsap.fromTo('.page-content', 
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' }
        );
      }

      // Stagger children
      gsap.fromTo('.stagger-item',
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          stagger: 0.08,
          ease: 'power2.out'
        }
      );
    };

    // Run on page load
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', pageEnter);
    } else {
      pageEnter();
    }
  }

  /**
   * Micro-interactions on buttons, cards, and inputs
   */
  setupMicroInteractions() {
    if (typeof gsap === 'undefined') return;

    // Button hover: glow effect
    document.querySelectorAll('button, .btn').forEach(btn => {
      btn.addEventListener('mouseenter', () => {
        gsap.to(btn, { boxShadow: 'var(--shadow-glow-lg)', duration: 0.3, ease: 'power2.out' });
      });

      btn.addEventListener('mouseleave', () => {
        gsap.to(btn, { boxShadow: 'var(--shadow-glow)', duration: 0.3, ease: 'power2.out' });
      });

      btn.addEventListener('click', () => {
        gsap.to(btn, { scale: 0.95, duration: 0.1, yoyo: true, repeat: 1 });
      });
    });

    // Card hover: elevation and glow
    document.querySelectorAll('.card, .glass-card').forEach(card => {
      card.addEventListener('mouseenter', () => {
        gsap.to(card, {
          y: -4,
          boxShadow: 'var(--shadow-glow-lg)',
          duration: 0.4,
          ease: 'power2.out'
        });
      });

      card.addEventListener('mouseleave', () => {
        gsap.to(card, {
          y: 0,
          boxShadow: 'var(--shadow-glow)',
          duration: 0.4,
          ease: 'power2.out'
        });
      });
    });

    // Input focus: bottom border animation
    document.querySelectorAll('input, textarea, select').forEach(input => {
      input.addEventListener('focus', () => {
        gsap.to(input, {
          boxShadow: 'var(--focus-ring-accent)',
          duration: 0.3,
          ease: 'power2.out'
        });
      });

      input.addEventListener('blur', () => {
        gsap.to(input, {
          boxShadow: '0 0 0 0 rgba(139,92,246,0)',
          duration: 0.3,
          ease: 'power2.out'
        });
      });
    });

    // Form validation animations
    this.setupFormValidationAnimations();
  }

  /**
   * Form validation error animations
   */
  setupFormValidationAnimations() {
    if (typeof gsap === 'undefined') return;

    document.addEventListener('invalid', (e) => {
      const input = e.target;
      gsap.to(input, { x: -5, duration: 0.1, repeat: 5, yoyo: true });
      gsap.to(input, { borderColor: 'var(--color-danger)', duration: 0.3 });
    }, true);

    document.addEventListener('change', (e) => {
      if (e.target.matches('input, textarea, select')) {
        const input = e.target;
        if (input.validity.valid) {
          gsap.to(input, { borderColor: 'var(--color-success)', duration: 0.3 });
        }
      }
    });
  }

  /**
   * Scroll-linked animations (parallax, fade, etc.)
   */
  setupScrollAnimations() {
    if (typeof gsap === 'undefined') return;

    // Parallax effect on hero sections
    document.querySelectorAll('.parallax-content').forEach(elem => {
      gsap.to(elem, {
        scrollTrigger: {
          trigger: elem,
          start: 'top center',
          end: 'bottom center',
          scrub: 0.5,
          markers: false
        },
        y: -50,
        opacity: 0.8,
        ease: 'none'
      });
    });

    // Fade in on scroll
    document.querySelectorAll('.fade-on-scroll').forEach(elem => {
      gsap.fromTo(elem,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          scrollTrigger: {
            trigger: elem,
            start: 'top 80%',
            end: 'top 50%',
            scrub: false,
            markers: false
          },
          duration: 0.8,
          ease: 'power2.out'
        }
      );
    });

    // Rotate on scroll
    document.querySelectorAll('.rotate-on-scroll').forEach(elem => {
      gsap.to(elem, {
        scrollTrigger: {
          trigger: elem,
          start: 'top center',
          end: 'bottom center',
          scrub: 1,
          markers: false
        },
        rotationY: 360,
        ease: 'none'
      });
    });
  }

  /**
   * Advanced ScrollTrigger animations
   */
  setupScrollTriggers() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

    // Sticky header animation
    const header = document.querySelector('header, .topbar');
    if (header) {
      ScrollTrigger.create({
        trigger: 'body',
        start: 'top center',
        end: 'bottom center',
        onUpdate: (self) => {
          if (self.getVelocity() < -300) {
            gsap.to(header, { y: -100, overwrite: 'auto', duration: 0.2 });
          } else if (self.getVelocity() > 300) {
            gsap.to(header, { y: 0, overwrite: 'auto', duration: 0.2 });
          }
        }
      });
    }
  }

  /**
   * Animate element list with stagger
   */
  staggerAnimate(selector, options = {}) {
    if (typeof gsap === 'undefined') return;

    const defaults = {
      from: { opacity: 0, y: 20 },
      to: { opacity: 1, y: 0 },
      stagger: 0.1,
      duration: 0.5,
      ease: 'power2.out'
    };

    const config = { ...defaults, ...options };

    gsap.fromTo(
      selector,
      config.from,
      {
        ...config.to,
        stagger: config.stagger,
        duration: config.duration,
        ease: config.ease
      }
    );
  }

  /**
   * Flip animation (position change)
   */
  flipAnimate(element, duration = 0.6) {
    if (typeof Flip === 'undefined') return;

    const state = Flip.getState(element);
    element.style.transform = '';
    Flip.from(state, {
      duration: duration,
      ease: 'back.out',
      absolute: true
    });
  }

  /**
   * Magnetic button effect
   */
  magneticButton(button) {
    if (typeof gsap === 'undefined') return;

    button.addEventListener('mousemove', (e) => {
      const rect = button.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const distX = (e.clientX - centerX) * 0.3;
      const distY = (e.clientY - centerY) * 0.3;

      gsap.to(button, {
        x: distX,
        y: distY,
        duration: 0.3,
        overwrite: 'auto'
      });
    });

    button.addEventListener('mouseleave', () => {
      gsap.to(button, {
        x: 0,
        y: 0,
        duration: 0.4,
        ease: 'elastic.out(1, 0.3)',
        overwrite: 'auto'
      });
    });
  }

  /**
   * Animate numbers incrementally (for stats/KPIs)
   */
  animateNumber(element, start, end, duration = 2) {
    if (typeof gsap === 'undefined') return;

    const obj = { value: start };
    gsap.to(obj, {
      value: end,
      duration: duration,
      ease: 'power2.out',
      onUpdate: () => {
        element.textContent = Math.round(obj.value).toLocaleString();
      }
    });
  }

  /**
   * Create notification toast with animation
   */
  showToast(message, type = 'info', duration = 3000) {
    if (typeof gsap === 'undefined') return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div class="toast-icon"></div>
      <div class="toast-message">${message}</div>
      <button class="toast-close">&times;</button>
    `;

    document.body.appendChild(toast);

    // Animate in
    gsap.fromTo(toast,
      { opacity: 0, x: 400 },
      { opacity: 1, x: 0, duration: 0.4, ease: 'back.out' }
    );

    // Auto-close
    const autoCloseTimeout = setTimeout(() => {
      gsap.to(toast, {
        opacity: 0,
        x: 400,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => toast.remove()
      });
    }, duration);

    // Manual close button
    toast.querySelector('.toast-close').addEventListener('click', () => {
      clearTimeout(autoCloseTimeout);
      gsap.to(toast, {
        opacity: 0,
        x: 400,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => toast.remove()
      });
    });

    return toast;
  }

  /**
   * Modal open/close animations
   */
  openModal(modalSelector) {
    if (typeof gsap === 'undefined') return;

    const modal = document.querySelector(modalSelector);
    const overlay = modal?.parentElement;

    if (!modal) return;

    // Animate overlay fade in
    gsap.to(overlay, {
      opacity: 1,
      duration: 0.3,
      ease: 'power2.out'
    });

    // Animate modal scale in
    gsap.fromTo(modal,
      { opacity: 0, scale: 0.95 },
      { opacity: 1, scale: 1, duration: 0.4, ease: 'back.out' }
    );
  }

  closeModal(modalSelector) {
    if (typeof gsap === 'undefined') return;

    const modal = document.querySelector(modalSelector);
    const overlay = modal?.parentElement;

    if (!modal) return;

    // Animate modal scale out
    gsap.to(modal,
      {
        opacity: 0,
        scale: 0.95,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => {
          modal.style.display = 'none';
        }
      }
    );

    // Animate overlay fade out
    gsap.to(overlay, {
      opacity: 0,
      duration: 0.3,
      ease: 'power2.in'
    });
  }

  /**
   * Timeline for complex sequences
   */
  createTimeline(options = {}) {
    if (typeof gsap === 'undefined') return null;

    return gsap.timeline(options);
  }

  /**
   * Cleanup ScrollTriggers on page leave
   */
  dispose() {
    if (typeof ScrollTrigger !== 'undefined') {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    }
  }
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.motionSystem = new MotionSystem();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
  if (window.motionSystem) {
    window.motionSystem.dispose();
  }
});

// ============ UTILITY FUNCTIONS ============

/**
 * Quick animation helper
 */
function animate(selector, from, to, duration = 0.5) {
  if (typeof gsap === 'undefined') return;

  gsap.fromTo(selector, from, {
    ...to,
    duration: duration,
    ease: 'power2.out'
  });
}

/**
 * Quick timeline helper
 */
function createSequence() {
  if (typeof gsap === 'undefined') return null;
  return gsap.timeline();
}
