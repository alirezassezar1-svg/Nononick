/**
 * Nononik — Live Text Editor
 * فقط برای ادمین لاگین‌شده لود می‌شه (نگاه کن به site-footer.php).
 * روی هر عنصر با data-editable، حالت contenteditable رو با یک دکمه‌ی شناور
 * روشن/خاموش می‌کنه و روی blur هر عنصر، متن رو با AJAX ذخیره می‌کنه.
 */
(function () {
  var toggleBtn = document.getElementById('liveEditToggle');
  var toast = document.getElementById('liveEditToast');
  if (!toggleBtn) return;

  var csrfToken = document.body.getAttribute('data-csrf') || '';
  var editing = false;
  var toastTimer = null;

  function showToast(text) {
    if (!toast) return;
    toast.textContent = text;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.hidden = true; }, 2200);
  }

  function setEditing(state) {
    editing = state;
    document.body.classList.toggle('live-editing', state);
    toggleBtn.classList.toggle('active', state);
    toggleBtn.querySelector('span').textContent = state ? 'پایان ویرایش' : 'ویرایش زنده';
    document.querySelectorAll('.live-editable').forEach(function (el) {
      el.contentEditable = state ? 'true' : 'false';
    });
    if (state) showToast('حالت ویرایش فعال شد — روی هر متن کلیک کن و تغییرش بده');
  }

  toggleBtn.addEventListener('click', function () { setEditing(!editing); });

  function saveBlock(el) {
    var key = el.getAttribute('data-editable');
    var value = (el.innerText || '').trim();
    el.classList.remove('save-error', 'saved-flash');

    var body = 'key=' + encodeURIComponent(key) +
      '&value=' + encodeURIComponent(value) +
      '&csrf_token=' + encodeURIComponent(csrfToken);

    fetch('ajax/save-content.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res && res.ok) {
          el.classList.add('saved-flash');
          showToast('ذخیره شد');
          setTimeout(function () { el.classList.remove('saved-flash'); }, 900);
        } else {
          el.classList.add('save-error');
          showToast('ذخیره نشد — دوباره امتحان کن');
        }
      })
      .catch(function () {
        el.classList.add('save-error');
        showToast('خطا در اتصال — دوباره امتحان کن');
      });
  }

  document.querySelectorAll('.live-editable').forEach(function (el) {
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        el.blur();
      }
    });
    el.addEventListener('blur', function () {
      if (!editing) return;
      saveBlock(el);
    });
  });

  // --- لینک‌های اجتماعی فوتر (مستقل از حالت «ویرایش زنده» متن، همیشه در دسترس ادمینه) ---
  document.querySelectorAll('.footer-social-edit').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var key = btn.getAttribute('data-social-key');
      var link = document.querySelector('[data-social-link="' + key + '"]');
      var current = link && !link.classList.contains('is-empty') ? link.getAttribute('href') : '';
      var url = window.prompt('آدرس لینک رو وارد کن (خالی بذار و تایید کن تا حذف بشه):', current || '');
      if (url === null) return; // انصراف

      var body = 'key=' + encodeURIComponent(key) +
        '&value=' + encodeURIComponent(url.trim()) +
        '&csrf_token=' + encodeURIComponent(csrfToken);

      fetch('ajax/save-content.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && res.ok && link) {
            var saved = res.value || '';
            link.href = saved || '#';
            link.classList.toggle('is-empty', saved === '');
            showToast(saved ? 'لینک ذخیره شد' : 'لینک حذف شد');
          } else {
            showToast('ذخیره نشد — دوباره امتحان کن');
          }
        })
        .catch(function () { showToast('خطا در اتصال — دوباره امتحان کن'); });
    });
  });
})();
