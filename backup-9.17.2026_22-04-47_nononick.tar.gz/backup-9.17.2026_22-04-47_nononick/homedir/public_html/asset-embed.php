<?php
/**
 * Nononik — Safe asset embed endpoint
 *
 * چرا این فایل لازم بود: uploads/{subDir}/assets/.htaccess همه‌ی فایل‌های
 * html/htm/svg رو force-download می‌کنه (که امنه ولی قابل نمایش نیست). این
 * فایل تنها راه رسمی برای *نمایش* اون فایل‌هاست: محتوا رو خودش از دیسک
 * می‌خونه و با هدرهای امنیتی سفت‌وسخت serve می‌کنه. این صفحه هرگز نباید
 * مستقیم توی تب اصلی مرورگر باز بشه؛ همیشه باید داخل:
 *
 *   <iframe src="/asset-embed.php?id=123" sandbox="allow-scripts"></iframe>
 *
 * (بدون allow-same-origin) قرار بگیره، چون sandbox بدون allow-same-origin
 * باعث می‌شه اسکریپت داخل فایل به کوکی/localStorage سایت اصلی دسترسی نداشته
 * باشه — حتی اگه فایل آپلودی مشکوک باشه، بلاست‌ردیوسش محدود به همون iframe
 * می‌مونه.
 */

require_once __DIR__ . '/config/database.php'; // فقط db() و ثابت‌های UPLOAD_DIR/UPLOAD_URL، بدون هیچ HTML لایوتی

$id = (int) ($_GET['id'] ?? 0);
if (!$id) {
    http_response_code(404);
    exit('Not found');
}

$stmt = db()->prepare('SELECT * FROM media_assets WHERE id = ?');
$stmt->execute([$id]);
$asset = $stmt->fetch();

if (!$asset || !in_array($asset['ext'], ['html', 'htm', 'svg'], true)) {
    http_response_code(404);
    exit('Not found');
}

$path = UPLOAD_DIR . $asset['module'] . '/assets/' . $asset['file_name'];
if (!is_file($path)) {
    http_response_code(404);
    exit('Not found');
}

// هدرهای امنیتی: هیچ منبع خارجی، هیچ frame تودرتو، فقط داخل iframeِ همین سایت
header('Content-Security-Policy: default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src * data:; media-src *; font-src *; frame-ancestors \'self\'; frame-src \'none\'');
header('X-Content-Type-Options: nosniff');
header('Content-Type: ' . ($asset['ext'] === 'svg' ? 'image/svg+xml' : 'text/html') . '; charset=utf-8');
readfile($path);
