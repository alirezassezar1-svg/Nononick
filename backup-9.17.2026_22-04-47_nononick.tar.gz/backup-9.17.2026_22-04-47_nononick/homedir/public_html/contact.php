<?php
$pageTitle = 'تماس با ما | Nononik';
$pageDescription = 'برای مشاوره‌ی رایگان و شروع پروژه‌ی وب‌سایت با آژانس Nononik در تماس باشید.';
require_once __DIR__ . '/includes/site-header.php';

$success = false;
$error   = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        $error = 'خطای امنیتی، لطفاً دوباره تلاش کنید.';
    } else {
        $name    = trim($_POST['name'] ?? '');
        $email   = trim($_POST['email'] ?? '');
        $phone   = to_english_digits(trim($_POST['phone'] ?? ''));
        $subject = trim($_POST['subject'] ?? '');
        $msg     = trim($_POST['message'] ?? '');

        if ($name === '' || $email === '' || $msg === '') {
            $error = 'نام، ایمیل و متن پیام الزامی است.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'ایمیل واردشده معتبر نیست.';
        } else {
            $stmt = db()->prepare('INSERT INTO messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$name, $email, $phone ?: null, $subject, $msg]);
            $success = true;

            // چرا: این فرم هم برای «تماس با ما» و هم برای دکمه‌ی «درخواست مشاوره رایگان» استفاده می‌شود؛
            // بنابراین ثبت هر پیام، یک پیامک اطلاع‌رسانی برای مدیر سایت ارسال می‌کند.
            if (sms_enabled()) {
                $adminPhone = setting('sms_admin_number', '');
                if ($adminPhone !== '') {
                    $subjectLabel = $subject !== '' ? $subject : 'مشاوره رایگان';
                    send_sms($adminPhone, "پیام جدید سایت Nononik\nموضوع: {$subjectLabel}\nنام: {$name}\nتماس: " . ($phone ?: $email));
                }
                // در صورت وارد کردن شماره تماس توسط کاربر، پیامک تاییدیه برایش ارسال می‌شود
                if ($phone !== '') {
                    send_sms($phone, 'پیام شما با موفقیت برای تیم Nononik ثبت شد؛ به‌زودی با شما تماس می‌گیریم.');
                }
            }
        }
    }
}
?>
<section class="hero page-head" style="padding:80px 0 40px;">
  <div class="hero-orb" style="width:200px;height:200px;background:radial-gradient(circle,rgba(139,92,246,0.48),transparent 70%);top:-30px;right:10%;"></div>
  <div class="wrap">
    <span class="hero-badge stagger-item"><i class="fa-solid fa-message"></i> تماس با ما</span>
    <h1 class="stagger-item">سوال دارید یا می‌خواهید پروژه‌ای شروع کنیم؟</h1>
    <p class="stagger-item">فرم زیر را پر کنید، پیامتان مستقیم به دست تیم ما می‌رسد.</p>
  </div>
</section>

<section class="section" style="padding-top:10px;">
  <div class="wrap">
    <form class="card glass contact-form stagger-item" method="post" action="contact.php" style="padding:32px;">
      <?php if ($success): ?>
        <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> پیام شما با موفقیت ارسال شد. به‌زودی با شما تماس می‌گیریم.</div>
      <?php elseif ($error): ?>
        <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

      <div class="form-group">
        <label for="name">نام و نام خانوادگی</label>
        <input type="text" id="name" name="name" class="form-control" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="email">ایمیل</label>
        <input type="email" id="email" name="email" class="form-control" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="phone">شماره تماس (برای پیامک تاییدیه و تماس سریع‌تر)</label>
        <input type="tel" id="phone" name="phone" class="form-control" placeholder="09xxxxxxxxx" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="subject">موضوع</label>
        <input type="text" id="subject" name="subject" class="form-control" value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="message">متن پیام</label>
        <textarea id="message" name="message" class="form-control" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;border:none;cursor:pointer;"><i class="fa-solid fa-paper-plane"></i> ارسال پیام</button>
    </form>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
