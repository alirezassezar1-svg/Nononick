  </div>
</div>

<footer class="site-footer glass">
  <div class="wrap footer-grid">
    <div>
      <a href="index.php" class="site-logo" style="margin-bottom:14px;">
        <div class="logo-cube" aria-hidden="true">
          <div class="logo-cube-inner">
            <div class="face front"></div>
            <div class="face back"></div>
            <div class="face right"></div>
            <div class="face left"></div>
            <div class="face top"></div>
            <div class="face bottom"></div>
          </div>
        </div>
        <span>Nononik</span>
      </a>
      <p class="footer-about"><?php editable('footer_about', 'آژانس طراحی وب‌سایت Nononik — طراحی سایت، پنل مدیریت اختصاصی و سئوی فنی.'); ?></p>
      <div class="footer-social">
        <?php
        $socialLinks = [
          'instagram' => ['fa-brands fa-instagram', 'اینستاگرام'],
          'linkedin'  => ['fa-brands fa-linkedin', 'لینکدین'],
          'youtube'   => ['fa-brands fa-youtube', 'یوتیوب'],
          'x'         => ['fa-brands fa-x-twitter', 'ایکس (توییتر)'],
          'telegram'  => ['fa-brands fa-telegram', 'تلگرام'],
        ];
        $isAdminFooter = !empty($_SESSION['admin_id']);
        foreach ($socialLinks as $skey => $meta):
          $sUrl = page_content('social_' . $skey, '');
          if ($sUrl === '' && !$isAdminFooter) continue; // برای بازدیدکننده، لینک‌های خالی اصلاً نمایش داده نمی‌شن
        ?>
        <span class="footer-social-item">
          <a href="<?= htmlspecialchars($sUrl ?: '#', ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer"
             class="btn-icon footer-social-link<?= $sUrl === '' ? ' is-empty' : '' ?>" title="<?= htmlspecialchars($meta[1], ENT_QUOTES, 'UTF-8') ?>"
             data-social-link="social_<?= $skey ?>">
            <i class="<?= $meta[0] ?>"></i>
          </a>
          <?php if ($isAdminFooter): ?>
          <button type="button" class="footer-social-edit" data-social-key="social_<?= $skey ?>" title="ویرایش آدرس <?= htmlspecialchars($meta[1], ENT_QUOTES, 'UTF-8') ?>">
            <i class="fa-solid fa-pen"></i>
          </button>
          <?php endif; ?>
        </span>
        <?php endforeach; ?>
      </div>
    </div>
    <div>
      <h4>لینک‌های سریع</h4>
      <a href="index.php">خانه</a>
      <a href="services.php">خدمات</a>
      <a href="portfolio.php">نمونه‌کارها</a>
      <a href="blog.php">مقالات</a>
      <a href="client/login.php">ورود پنل کاربری</a>
      <a href="client/demo.php">پیش‌نمایش پنل کاربری</a>
    </div>
    <div>
      <h4>تماس با ما</h4>
      <p><i class="fa-solid fa-envelope"></i> <?php editable('footer_contact_email', 'info@nononik.example'); ?></p>
      <p><i class="fa-solid fa-phone"></i> <a href="tel:<?= e(contact_phone_tel()) ?>" style="color:inherit;"><?php editable('footer_contact_phone', '۰۲۱-۰۰۰۰۰۰۰'); ?></a></p>
    </div>
  </div>
  <div class="wrap footer-bottom">
    <span>© <?= date('Y') ?> Nononik. تمامی حقوق محفوظ است.</span>
  </div>
</footer>

<script>window.CSRF_TOKEN = "<?= csrf_token() ?>";</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/motion.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script src="<?= BASE_URL ?>assets/js/site.js"></script>
<?php if (!empty($_SESSION['admin_id'])): ?>
<script src="<?= BASE_URL ?>assets/js/live-editor.js"></script>
<?php endif; ?>
</body>
</html>
