<?php
/**
 * Nononik - Helper functions
 */

function e(?string $str): string
{
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_check(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        set_flash('error', 'خطای امنیتی، لطفاً دوباره تلاش کنید.');
        redirect($_SERVER['HTTP_REFERER'] ?? BASE_URL);
    }
}

/**
 * Upload an image file, returns stored filename (relative) or null.
 * چرا: علاوه بر پسوند، نوع واقعی فایل با getimagesize() بررسی می‌شود تا فایل‌های
 * غیرتصویری با پسوند جعلی (مثل .php.jpg) رد شوند؛ نام فایل همیشه با uniqid تولید
 * می‌شود تا از Path Traversal یا اجرای اسکریپت از طریق نام فایل کاربر جلوگیری شود.
 */
function upload_image(array $file, string $subDir, ?string $oldFile = null): ?string
{
    if (empty($file['name']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return $oldFile;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return $oldFile;
    }

    $allowedExt = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $allowedMime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        return $oldFile;
    }
    if ($file['size'] > 5 * 1024 * 1024) { // 5MB
        return $oldFile;
    }

    // بررسی نوع واقعی فایل (نه فقط پسوند اعلام‌شده توسط کاربر)
    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false || !in_array($imageInfo['mime'], $allowedMime, true)) {
        security_log('upload_rejected', "invalid file type for {$subDir}, claimed ext={$ext}");
        return $oldFile;
    }

    $targetDir = UPLOAD_DIR . $subDir . '/';
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $filename = uniqid($subDir . '_', true) . '.' . $ext;
    if (move_uploaded_file($file['tmp_name'], $targetDir . $filename)) {
        // remove old file
        if ($oldFile && is_file($targetDir . $oldFile)) {
            @unlink($targetDir . $oldFile);
        }
        // چرا: تبدیل خودکار هر عکس آپلودی (در همه‌ی بخش‌ها: نمونه‌کار، مقاله، گالری، آواتار، لوگو...)
        // به فرمت WebP برای کاهش حجم فایل و افزایش سرعت لود سایت. اگر تبدیل ممکن نبود
        // (مثلاً پسوند gif متحرک یا نبود پشتیبانی WebP روی سرور) فایل اصلی بدون تغییر باقی می‌ماند.
        $webpFilename = convert_image_to_webp($targetDir . $filename, $imageInfo['mime']);
        return $webpFilename ?: $filename;
    }
    return $oldFile;
}

/**
 * Convert an already-saved image file to WebP in-place and remove the original.
 * چرا: gif (به‌خاطر احتمال انیمیشن) و webp (که از قبل webp است) تبدیل نمی‌شوند.
 * در صورت نبود پشتیبانی GD/WebP روی سرور، بی‌صدا null برمی‌گرداند و فایل اصلی حفظ می‌شود.
 */
function convert_image_to_webp(string $filePath, string $mime): ?string
{
    if (!function_exists('imagewebp') || !is_file($filePath)) {
        return null;
    }

    switch ($mime) {
        case 'image/jpeg':
            $image = @imagecreatefromjpeg($filePath);
            break;
        case 'image/png':
            $image = @imagecreatefrompng($filePath);
            if ($image) {
                imagepalettetotruecolor($image);
                imagealphablending($image, true);
                imagesavealpha($image, true);
            }
            break;
        default:
            // gif (احتمال انیمیشن) و webp (از قبل webp) دست‌نخورده باقی می‌مانند
            return null;
    }

    if (!$image) {
        return null;
    }

    $webpPath = preg_replace('/\.[a-zA-Z0-9]+$/', '.webp', $filePath);
    $ok = imagewebp($image, $webpPath, 82);
    imagedestroy($image);

    if ($ok && is_file($webpPath)) {
        if ($webpPath !== $filePath) {
            @unlink($filePath);
        }
        return basename($webpPath);
    }
    return null;
}

/**
 * Upload any number of extra gallery images for one item (portfolio/article).
 * چرا: از همان اعتبارسنجی upload_image() (پسوند واقعی، mime، حجم، نام امن با uniqid)
 * برای هر فایل به‌صورت جدا استفاده می‌کند تا امنیت یکسان با تصویر شاخص حفظ شود.
 * فایل‌های نامعتبر بی‌صدا نادیده گرفته می‌شوند و بقیه‌ی فایل‌های معتبر آپلود می‌شوند.
 */
function upload_gallery_images(array $files, string $subDir): array
{
    $saved = [];
    if (empty($files['name']) || !is_array($files['name'])) {
        return $saved;
    }
    $count = count($files['name']);
    for ($i = 0; $i < $count; $i++) {
        if (($files['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE || $files['name'][$i] === '') {
            continue;
        }
        $single = [
            'name'     => $files['name'][$i],
            'type'     => $files['type'][$i] ?? '',
            'tmp_name' => $files['tmp_name'][$i] ?? '',
            'error'    => $files['error'][$i] ?? UPLOAD_ERR_NO_FILE,
            'size'     => $files['size'][$i] ?? 0,
        ];
        $filename = upload_image($single, $subDir, null);
        // upload_image() برای ورودی نامعتبر همان oldFile (اینجا null) را برمی‌گرداند
        if ($filename) {
            $saved[] = $filename;
        }
    }
    return $saved;
}

function image_url(?string $file, string $subDir): string
{
    if (!$file) {
        return BASE_URL . 'assets/img/placeholder.svg';
    }
    return UPLOAD_URL . $subDir . '/' . $file;
}

/**
 * آپلود فایل‌های غیر تصویری (خروجی ابزارهای هوش مصنوعی، مدل سه‌بعدی و...)
 * برای پیوست به نمونه‌کار یا مقاله. جدا از upload_image() چون این فایل‌ها
 * getimagesize ندارن و allow-list کاملاً متفاوتی لازم دارن.
 *
 * چرا هر پسوند مجاز شد یا نشد:
 * - glb/gltf/pdf/zip/mp4/webm/json : فایل‌های باینری/داده‌ای، مرورگر خودش
 *   کدی داخلشون اجرا نمی‌کنه، بنابراین با سرو مستقیم از uploads/ (که php روش
 *   غیرفعاله) امن هستن.
 * - html/htm/svg : می‌تونن جاوااسکریپت داشته باشن. آپلودشون مجازه (چون خروجی
 *   ابزار AI معمولاً html هست) ولی uploads/{subDir}/assets/.htaccess این
 *   پسوندها رو force-download می‌کنه تا مرورگر مستقیم اجراشون نکنه؛ برای
 *   نمایش‌شون باید از asset_embed_url() داخل iframe با sandbox استفاده کنی.
 */
function upload_asset_file(array $file, string $subDir): ?array
{
    if (empty($file['name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowedExt = ['html', 'htm', 'svg', 'glb', 'gltf', 'pdf', 'zip', 'mp4', 'webm', 'json'];
    $maxSize    = 30 * 1024 * 1024; // 30MB (مدل‌های سه‌بعدی حجیم‌ترن)

    $originalName = $file['name'];
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowedExt, true)) {
        security_log('asset_upload_rejected', "extension not allowed: {$ext} ({$originalName})");
        return null;
    }
    if ($file['size'] > $maxSize) {
        security_log('asset_upload_rejected', "file too large: {$originalName} ({$file['size']} bytes)");
        return null;
    }

    // بررسی نوع واقعی فایل با finfo (نه فقط پسوندی که کاربر ادعا کرده)
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $realMime = $finfo ? finfo_file($finfo, $file['tmp_name']) : null;
    if ($finfo) finfo_close($finfo);

    $mimeAllowList = [
        'html' => ['text/html', 'text/plain'],
        'htm'  => ['text/html', 'text/plain'],
        'svg'  => ['image/svg+xml', 'text/plain', 'text/xml', 'application/xml'],
        'glb'  => ['model/gltf-binary', 'application/octet-stream'],
        'gltf' => ['model/gltf+json', 'application/json', 'text/plain'],
        'pdf'  => ['application/pdf'],
        'zip'  => ['application/zip', 'application/x-zip-compressed'],
        'mp4'  => ['video/mp4'],
        'webm' => ['video/webm'],
        'json' => ['application/json', 'text/plain'],
    ];
    if ($realMime && isset($mimeAllowList[$ext]) && !in_array($realMime, $mimeAllowList[$ext], true)) {
        security_log('asset_upload_rejected', "mime mismatch for {$originalName}: claimed {$ext}, detected {$realMime}");
        return null;
    }

    $targetDir = UPLOAD_DIR . $subDir . '/assets/';
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    // .htaccess اختصاصی این پوشه: html/htm/svg همیشه force-download می‌شن تا
    // مرورگر مستقیم اجراشون نکنه (حتی با وجود قفل php در .htaccess والد)
    $assetHtaccess = $targetDir . '.htaccess';
    if (!is_file($assetHtaccess)) {
        file_put_contents($assetHtaccess,
            "<IfModule mod_headers.c>\n" .
            "  <FilesMatch \"\\.(html|htm|svg)$\">\n" .
            "    Header set Content-Disposition attachment\n" .
            "    ForceType application/octet-stream\n" .
            "  </FilesMatch>\n" .
            "</IfModule>\n"
        );
    }

    // نام فایل کاملاً سرور-ساخته؛ اسم اصلی کاربر هیچ‌جا داخل مسیر فایل استفاده نمی‌شه
    $filename = uniqid($subDir . '_asset_', true) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $targetDir . $filename)) {
        return null;
    }

    return [
        'file_name'     => $filename,
        'original_name' => mb_substr($originalName, 0, 255),
        'ext'           => $ext,
        'mime_type'     => $realMime ?: '',
        'size_bytes'    => (int) $file['size'],
    ];
}

function asset_url(string $file, string $subDir): string
{
    return UPLOAD_URL . $subDir . '/assets/' . $file;
}

function asset_icon(string $ext): string
{
    return match ($ext) {
        'html', 'htm' => 'fa-code',
        'svg'         => 'fa-bezier-curve',
        'glb', 'gltf' => 'fa-cube',
        'pdf'         => 'fa-file-pdf',
        'zip'         => 'fa-file-zipper',
        'mp4', 'webm' => 'fa-file-video',
        'json'        => 'fa-file-code',
        default       => 'fa-file',
    };
}

function time_ago(string $datetime): string
{
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'چند لحظه پیش';
    if ($diff < 3600) return floor($diff / 60) . ' دقیقه پیش';
    if ($diff < 86400) return floor($diff / 3600) . ' ساعت پیش';
    if ($diff < 2592000) return floor($diff / 86400) . ' روز پیش';
    return date('Y/m/d', strtotime($datetime));
}

function status_label(string $status): string
{
    return match ($status) {
        'in_progress' => 'در حال اجرا',
        'completed'   => 'تکمیل شده',
        'pending'     => 'در انتظار',
        'active'      => 'فعال',
        'inactive'    => 'غیرفعال',
        'draft'       => 'پیش‌نویس',
        'published'   => 'منتشر شده',
        default       => $status,
    };
}

function paginate(int $totalRows, int $perPage, int $currentPage): array
{
    $totalPages = max(1, (int) ceil($totalRows / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset = ($currentPage - 1) * $perPage;
    return [$totalPages, $currentPage, $offset];
}

/**
 * تبدیل ارقام فارسی/عربی به انگلیسی — برای ساخت لینک tel: و ارسال به وب‌سرویس پیامک
 */
function to_english_digits(string $str): string
{
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic  = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabic, $english, str_replace($persian, $english, $str));
}

/**
 * شماره تماس ثبت‌شده در بخش «ویرایش زنده» فوتر را برای استفاده در لینک tel: آماده می‌کند.
 */
function contact_phone_tel(): string
{
    $raw = to_english_digits(page_content('footer_contact_phone', ''));
    return preg_replace('/[^0-9+]/', '', $raw);
}

/**
 * Layer 6 — ارسال پیامک (SMS)
 * چرا: برای بخش‌های «مشاوره رایگان» و «تماس با ما»، بعد از ثبت پیام، هم به مدیر سایت
 * (اطلاع از پیام جدید) و هم در صورت وجود شماره‌ی کاربر (تاییدیه) پیامک ارسال می‌شود.
 * تنظیمات وب‌سرویس (کد API، شماره فرستنده، شماره مدیر) از پنل ادمین → تنظیمات → پیامک خوانده می‌شود.
 * در صورت خطا یا نبود تنظیمات، false برمی‌گردد و هرگز باعث توقف ثبت فرم نمی‌شود.
 */
function sms_enabled(): bool
{
    if (setting('sms_enabled', '0') !== '1') {
        return false;
    }
    $provider = setting('sms_provider', 'kavenegar');
    if ($provider === 'melipayamak') {
        return setting('sms_username', '') !== '' && setting('sms_password', '') !== '';
    }
    return setting('sms_api_key', '') !== '';
}

function send_sms(string $to, string $message): bool
{
    $to = to_english_digits($to);
    if (!sms_enabled() || $to === '') {
        return false;
    }

    $provider = setting('sms_provider', 'kavenegar');
    $apiKey   = setting('sms_api_key', '');
    $sender   = setting('sms_sender_number', '');

    try {
        if ($provider === 'melipayamak') {
            $url = 'https://rest.payamak-panel.com/api/SendSMS/SendSMS';
            $payload = [
                'username' => setting('sms_username', ''),
                'password' => setting('sms_password', ''),
                'to'       => $to,
                'from'     => $sender,
                'text'     => $message,
                'isflash'  => false,
            ];
        } else { // kavenegar (پیش‌فرض)
            $url = 'https://api.kavenegar.com/v1/' . rawurlencode($apiKey) . '/sms/send.json';
            $payload = [
                'receptor' => $to,
                'sender'   => $sender,
                'message'  => $message,
            ];
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($response === false || $httpCode >= 400) {
            security_log('sms_failed', "provider={$provider} to={$to} http={$httpCode} err={$curlErr}");
            return false;
        }
        return true;
    } catch (Throwable $e) {
        security_log('sms_failed', "provider={$provider} to={$to} exception=" . $e->getMessage());
        return false;
    }
}

/**
 * Layer 3 — Settings helpers (key/value store)
 * چرا: تمرکز تنظیمات سایت (SEO، لوگو، اطلاعات تماس) در یک نقطه، قابل ویرایش از settings.php
 */
function all_settings(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $rows = db()->query('SELECT `key`, `value` FROM settings')->fetchAll();
        foreach ($rows as $row) {
            $cache[$row['key']] = $row['value'];
        }
    }
    return $cache;
}

function setting(string $key, string $default = ''): string
{
    $all = all_settings();
    return $all[$key] ?? $default;
}

function set_setting(string $key, string $value): void
{
    $stmt = db()->prepare('INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)');
    $stmt->execute([$key, $value]);
}

/**
 * Layer 5 — ویرایشگر متن زنده (Live Text Editor)
 * چرا: متن‌های ثابت صفحات عمومی سایت (هدر، پاراگراف‌ها) که تا الان مستقیم
 * داخل فایل PHP هاردکد شده بودن رو به یک جدول key/value منتقل می‌کنیم تا
 * ادمین بتونه مستقیم روی خود سایت (بدون رفتن به پنل) ویرایششون کنه.
 */
function page_content(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $rows = db()->query('SELECT block_key, content FROM page_content')->fetchAll();
            foreach ($rows as $row) {
                $cache[$row['block_key']] = $row['content'];
            }
        } catch (Throwable $e) {
            // جدول page_content هنوز ساخته نشده (مثلاً قبل از اجرای migration) — از مقدار پیش‌فرض استفاده می‌شود
            $cache = [];
        }
    }
    $value = $cache[$key] ?? $default;
    return $value !== '' ? $value : $default;
}

function editable(string $key, string $default = ''): void
{
    $value = htmlspecialchars(page_content($key, $default), ENT_QUOTES, 'UTF-8');
    $isAdmin = !empty($_SESSION['admin_id']);
    $attr = $isAdmin ? ' class="live-editable" data-editable="' . htmlspecialchars($key, ENT_QUOTES, 'UTF-8') . '"' : '';
    echo '<span' . $attr . '>' . $value . '</span>';
}

/**
 * Layer 4 — RBAC helpers
 * چرا: تمرکز منطق دسترسی در یک نقطه؛ نقش «مدیر کل» (super-admin) به‌صورت
 * bypass کامل عمل می‌کند و نیازی به رکورد در role_permissions ندارد.
 */
function current_admin_permissions(): array
{
    static $cache = null;
    if ($cache !== null) return $cache;
    if (empty($_SESSION['admin_id'])) return $cache = [];

    $adminId = $_SESSION['admin_id'];

    $superStmt = db()->prepare("
        SELECT COUNT(*) FROM admin_roles ar
        JOIN roles r ON r.id = ar.role_id
        WHERE ar.admin_id = ? AND r.slug = 'super-admin'
    ");
    $superStmt->execute([$adminId]);
    if ($superStmt->fetchColumn() > 0) {
        return $cache = ['*'];
    }

    $stmt = db()->prepare("
        SELECT DISTINCT p.slug FROM admin_roles ar
        JOIN role_permissions rp ON rp.role_id = ar.role_id
        JOIN permissions p ON p.id = rp.permission_id
        WHERE ar.admin_id = ?
    ");
    $stmt->execute([$adminId]);
    return $cache = array_column($stmt->fetchAll(), 'slug');
}

function can(string $permission): bool
{
    $perms = current_admin_permissions();
    return in_array('*', $perms, true) || in_array($permission, $perms, true);
}

function canAny(array $permissions): bool
{
    foreach ($permissions as $p) {
        if (can($p)) return true;
    }
    return false;
}

/**
 * چرا: محافظت سمت سرور از هر صفحه/اکشن؛ اگر دسترسی نبود صفحه ۴۰۳ نمایش داده می‌شود.
 */
function require_permission(string $permission): void
{
    if (!can($permission)) {
        http_response_code(403);
        require __DIR__ . '/../403.php';
        exit;
    }
}
