<?php
/**
 * Nononik — Public Website Header (Premium Glass Edition)
 * چرا: از همان Design System پنل ادمین/کاربر استفاده می‌شود (design-tokens, theme,
 * motion, components) تا بازدیدکننده از همان لحظه‌ی ورود، همان حس بصری پریمیوم
 * بنفش/سه‌بعدی/شیشه‌ای برند Nononik را تجربه کند — بدون نیاز به لاگین.
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle       = $pageTitle ?? 'Nononik — آژانس طراحی وب‌سایت';
$pageDescription = $pageDescription ?? 'آژانس طراحی وب‌سایت Nononik؛ طراحی سایت حرفه‌ای، پنل مدیریت اختصاصی و سئوی فنی.';
$currentPage     = $currentPage ?? basename($_SERVER['SCRIPT_NAME']);

// چرا: TODO — قبل از دیپلوی روی هاست واقعی، این مقدار را با دامنه‌ی نهایی جایگزین کنید
$siteDomain   = 'https://nononick.ir';
$canonicalUrl = $canonicalUrl ?? ($siteDomain . '/' . ($currentPage === 'index.php' ? '' : $currentPage));
$ogImageUrl   = $ogImageUrl ?? ($siteDomain . '/assets/images/site/og-cover.png');
$logoImageUrl = $siteDomain . '/assets/images/site/logo-dark.jpg';
// چرا: صفحات تک‌مقاله/تک‌نمونه‌کار می‌تونن قبل از include یک $extraSchemaGraph
// (آرایه‌ی آماده برای @graph جیسون-ال‌دی، مثلاً نوع Article) ست کنن تا اینجا
// به Organization/WebSite پیش‌فرض اضافه بشه — بدون تکرار کد ساخت schema.
$extraSchemaGraph = $extraSchemaGraph ?? [];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDescription) ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= htmlspecialchars($canonicalUrl) ?>">
<link rel="alternate" hreflang="fa-ir" href="<?= htmlspecialchars($canonicalUrl) ?>">
<?php $faviconV = @filemtime(__DIR__ . '/../assets/images/site/favicon.ico') ?: time(); ?>
<link rel="icon" href="<?= BASE_URL ?>assets/images/site/favicon.ico?v=<?= $faviconV ?>" sizes="any">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>assets/images/site/favicon-16x16.png?v=<?= $faviconV ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/images/site/favicon-32x32.png?v=<?= $faviconV ?>">
<link rel="icon" type="image/png" sizes="48x48" href="<?= BASE_URL ?>assets/images/site/favicon-48x48.png?v=<?= $faviconV ?>">
<link rel="icon" type="image/png" sizes="96x96" href="<?= BASE_URL ?>assets/images/site/favicon-96x96.png?v=<?= $faviconV ?>">
<link rel="icon" type="image/png" sizes="192x192" href="<?= BASE_URL ?>assets/images/site/favicon-192x192.png?v=<?= $faviconV ?>">
<link rel="icon" type="image/png" sizes="512x512" href="<?= BASE_URL ?>assets/images/site/favicon-512x512.png?v=<?= $faviconV ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>assets/images/site/apple-touch-icon.png?v=<?= $faviconV ?>">
<link rel="manifest" href="<?= BASE_URL ?>assets/images/site/site.webmanifest">

<!-- Open Graph -->
<meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>">
<meta property="og:description" content="<?= htmlspecialchars($pageDescription) ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="<?= htmlspecialchars($canonicalUrl) ?>">
<meta property="og:image" content="<?= htmlspecialchars($ogImageUrl) ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:locale" content="fa_IR">
<meta property="og:site_name" content="Nononik">

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= htmlspecialchars($pageTitle) ?>">
<meta name="twitter:description" content="<?= htmlspecialchars($pageDescription) ?>">
<meta name="twitter:image" content="<?= htmlspecialchars($ogImageUrl) ?>">

<script type="application/ld+json">
<?php
$schemaGraph = [
    [
        '@type' => 'Organization',
        'name' => 'Nononik',
        'url' => $siteDomain . '/site/index.php',
        'logo' => $logoImageUrl,
        'description' => 'آژانس طراحی وب‌سایت Nononik — طراحی سایت حرفه‌ای، پنل مدیریت اختصاصی و سئوی فنی.',
    ],
    [
        '@type' => 'WebSite',
        'name' => 'Nononik',
        'url' => $siteDomain . '/site/index.php',
        'inLanguage' => 'fa-IR',
    ],
];
$schemaGraph = array_merge($schemaGraph, $extraSchemaGraph);
echo json_encode(['@context' => 'https://schema.org', '@graph' => $schemaGraph], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
?>
</script>

<!-- چرا: اعمال تم قبل از رندر CSS، جلوگیری از فلش تم اشتباه (FOUC) — همان مکانیزم پنل ادمین/کاربر -->
<script>
(function () {
  var saved = localStorage.getItem('sunpanel-theme');
  var theme = saved || 'dark';
  document.documentElement.setAttribute('data-theme', theme);
})();
</script>

<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" media="all">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/peyda-font@v3.0.1/dist/font-face.css" rel="stylesheet" media="all">
<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>

<!-- Design System (همان کتابخانه‌ی پنل ادمین/کاربر) -->
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/design-tokens.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/theme.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/motion.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/components.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/text-3d.css">
<style>
:root{
  --text-3d-blue-1: <?= e(setting('text3d_blue1', '#c4b5fd')) ?>;
  --text-3d-blue-2: <?= e(setting('text3d_blue2', '#60a5fa')) ?>;
  --text-3d-pink-1: <?= e(setting('text3d_pink1', '#f0abfc')) ?>;
  --text-3d-pink-2: <?= e(setting('text3d_pink2', '#c084fc')) ?>;
}
</style>
<!-- استایل‌های اختصاصی سایت عمومی (هدر/فوتر/هیرو/گرید نمونه‌کار) -->
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/site.css">
</head>
<body<?= !empty($_SESSION['admin_id']) ? ' data-csrf="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '"' : '' ?>>
<div class="mesh-bg"></div>
<div class="custom-cursor" id="customCursor"></div>
<div class="page-transition" id="pageTransition"></div>
<div class="toast-container" id="toastContainer"></div>

<header class="site-header glass">
  <div class="wrap site-nav">
    <a href="index.php" class="site-logo">
      <div class="logo-cube" aria-hidden="true">
        <div class="logo-cube-inner">
          <div class="face front"></div>
          <div class="face back"></div>
          <div class="face right"></div>
          <div class="face left"></div>
          <div class="face top"></div>
          <div class="face bottom"></div>
        </div>
      </div>
      <span>Nononik</span>
    </a>
    <nav class="site-links" id="siteLinks">
      <a href="index.php" class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">خانه</a>
      <a href="services.php" class="<?= $currentPage === 'services.php' ? 'active' : '' ?>">خدمات</a>
      <a href="portfolio.php" class="<?= $currentPage === 'portfolio.php' ? 'active' : '' ?>">نمونه‌کارها</a>
      <a href="blog.php" class="<?= $currentPage === 'blog.php' ? 'active' : '' ?>">مقالات</a>
      <a href="contact.php" class="<?= $currentPage === 'contact.php' ? 'active' : '' ?>">تماس با ما</a>
    </nav>
    <div class="site-nav-actions">
      <?php $headerPhoneTel = contact_phone_tel(); ?>
      <?php if ($headerPhoneTel !== ''): ?>
      <a href="tel:<?= e($headerPhoneTel) ?>" class="btn-icon phone-cta-3d" title="تماس تلفنی مستقیم" aria-label="تماس با ما">
        <i class="fa-solid fa-phone"></i>
      </a>
      <?php endif; ?>
      <button id="themeToggle" class="btn-icon" title="تغییر حالت تاریک/روشن" aria-label="تغییر تم">
        <i class="fa-solid fa-circle-half-stroke"></i>
      </button>
      <a href="client/login.php" class="btn-outline" title="ورود مشتریان به پنل کاربری"><i class="fa-solid fa-right-to-bracket"></i> پنل کاربری</a>
      <a href="contact.php" class="btn btn-primary" style="width:auto;">مشاوره رایگان</a>
      <button class="btn-icon" id="mobileNavToggle" aria-label="منو"><i class="fa-solid fa-bars"></i></button>
    </div>
  </div>
</header>

<?php if (!empty($_SESSION['admin_id'])): ?>
<button id="liveEditToggle" class="live-edit-toggle" type="button" title="ویرایش زنده متن‌های این صفحه">
  <i class="fa-solid fa-pen-to-square"></i> <span>ویرایش زنده</span>
</button>
<div id="liveEditToast" class="live-edit-toast" hidden></div>
<?php endif; ?>

<!-- چرا: کلاس‌های .main/.content مثل چارچوب پنل ادمین اضافه شدن تا انیمیشن‌های
     GSAP (main.js) که به این کلاس‌ها گره خوردن، دقیقاً مثل پنل ادمین روی سایت
     عمومی هم واقعاً اجرا بشن (نه فقط ساکت بشن). لایوت بصری‌شون توی site.css
     خنثی شده تا چیدمان صفحه دست‌نخورده بمونه. -->
<div class="main">
  <div class="content">
