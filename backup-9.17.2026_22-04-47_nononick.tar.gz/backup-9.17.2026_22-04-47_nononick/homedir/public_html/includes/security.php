<?php
/**
 * Nononik — Layer 5: Security Hardening
 * چرا: تمرکز منطق امنیتی (هدرها، Rate Limit، لاگ) در یک فایل مستقل و قابل استفاده مجدد.
 */

/**
 * هدرهای امنیتی پایه — روی هر درخواست (از auth.php) اعمال می‌شود.
 */
function apply_security_headers(): void
{
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
    // چرا: پرمیشن‌های مرورگر غیرضروری (دوربین/میکروفون/موقعیت) در یک پنل ادمین غیرفعال می‌شوند
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

/**
 * لاگ ساده‌ی رخدادهای امنیتی (تلاش ناموفق لاگین، خطاهای بحرانی و ...)
 * چرا: فایل متنی ساده، بدون وابستگی به کتابخانه خارجی؛ برای Production می‌توان به
 * سرویس لاگ مرکزی (ELK/Sentry) مهاجرت کرد.
 */
function security_log(string $type, string $message): void
{
    $dir = __DIR__ . '/../logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
        @file_put_contents($dir . '/.htaccess', "Require all denied\n");
    }
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $line = sprintf("[%s] [%s] ip=%s %s\n", date('Y-m-d H:i:s'), strtoupper($type), $ip, $message);
    @file_put_contents($dir . '/security.log', $line, FILE_APPEND | LOCK_EX);
}

/**
 * Rate limiting لاگین — حداکثر ۵ تلاش ناموفق در ۱۵ دقیقه به‌ازای IP + نام‌کاربری.
 * از جدول login_attempts استفاده می‌کند (Layer 5 migration).
 */
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_WINDOW_MINUTES = 15;

function login_is_rate_limited(string $username): bool
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = db()->prepare("
        SELECT COUNT(*) FROM login_attempts
        WHERE (ip_address = ? OR username = ?)
        AND success = 0
        AND attempted_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
    ");
    $stmt->execute([$ip, $username, LOGIN_WINDOW_MINUTES]);
    return (int) $stmt->fetchColumn() >= LOGIN_MAX_ATTEMPTS;
}

function login_record_attempt(string $username, bool $success): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = db()->prepare('INSERT INTO login_attempts (ip_address, username, success) VALUES (?, ?, ?)');
    $stmt->execute([$ip, $username, $success ? 1 : 0]);

    if (!$success) {
        security_log('login_failed', "username={$username}");
    }
}

/**
 * چرا: پاکسازی رکوردهای قدیمی‌تر از پنجره‌ی زمانی، جلوگیری از رشد بی‌حد جدول.
 * فراخوانی سبک و تصادفی (۲٪ احتمال) در هر لاگین برای جلوگیری از overhead دائمی.
 */
function login_attempts_cleanup(): void
{
    if (random_int(1, 100) <= 2) {
        db()->prepare('DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 1 DAY)')->execute();
    }
}
