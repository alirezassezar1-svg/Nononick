<?php
/**
 * Nononik — صفحه‌ی اختصاصی هر نمونه‌کار (برای ایندکس شدن جدا در گوگل)
 * آدرس: portfolio-single.php?slug=طراحی-سایت-فروشگاه-طلا-و-جواهر
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$slug = trim($_GET['slug'] ?? '');
$item = null;
if ($slug !== '') {
    $stmt = db()->prepare('SELECT * FROM portfolio WHERE slug = ? LIMIT 1');
    $stmt->execute([$slug]);
    $item = $stmt->fetch();
}

if (!$item) {
    http_response_code(404);
    $pageTitle = 'نمونه‌کار پیدا نشد | Nononik';
    require_once __DIR__ . '/includes/site-header.php';
    echo '<section class="section"><div class="wrap"><p class="empty-note">نمونه‌کار موردنظر پیدا نشد.</p><a href="portfolio.php" class="btn btn-outline btn-sm" style="width:auto">بازگشت به نمونه‌کارها</a></div></section>';
    require_once __DIR__ . '/includes/site-footer.php';
    exit;
}

$gallery = db()->prepare('SELECT * FROM portfolio_images WHERE portfolio_id = ? ORDER BY sort_order, id');
$gallery->execute([$item['id']]);
$gallery = $gallery->fetchAll();

$assets = db()->prepare("SELECT * FROM media_assets WHERE module = 'portfolio' AND item_id = ? ORDER BY created_at");
$assets->execute([$item['id']]);
$assets = $assets->fetchAll();

// --- SEO/meta که قبل از include site-header.php ست می‌شن ---
$pageTitle       = $item['title'] . ' | نمونه‌کار Nononik';
$pageDescription = $item['description'] ? mb_substr(strip_tags($item['description']), 0, 155) . '…' : 'نمونه‌کار ' . $item['title'] . ' از آژانس Nononik.';
$currentPage     = 'portfolio.php';
$siteDomainForSchema = 'https://nononick.ir';
$canonicalUrl    = $siteDomainForSchema . '/portfolio-single.php?slug=' . rawurlencode($item['slug']);
$ogImageUrl      = $item['image'] ? ($siteDomainForSchema . '/' . ltrim(str_replace($siteDomainForSchema, '', image_url($item['image'], 'portfolio')), '/')) : null;

$extraSchemaGraph = [[
    '@type'       => 'CreativeWork',
    'name'        => $item['title'],
    'description' => $pageDescription,
    'about'       => $item['category'] ?: 'طراحی وب‌سایت',
    'url'         => $canonicalUrl,
    'image'       => $ogImageUrl ?: ($siteDomainForSchema . '/assets/images/site/og-cover.png'),
    'creator'     => ['@type' => 'Organization', 'name' => 'Nononik'],
    'dateCreated' => date('c', strtotime($item['created_at'])),
]];

require_once __DIR__ . '/includes/site-header.php';
?>
<section class="hero page-head" style="padding:70px 0 40px;">
  <div class="wrap">
    <span class="hero-badge stagger-item"><i class="fa-solid fa-briefcase"></i> <?= e($item['category'] ?: 'نمونه‌کار') ?></span>
    <h1 class="stagger-item"><?= e($item['title']) ?></h1>
  </div>
</section>

<section class="section" style="padding-top:10px;">
  <div class="wrap" style="max-width:860px;">
    <?php if ($item['image']): ?>
    <img loading="lazy" decoding="async" src="<?= e(image_url($item['image'], 'portfolio')) ?>" alt="<?= e($item['title']) ?>" style="width:100%;border-radius:var(--radius-md);margin-bottom:26px;">
    <?php endif; ?>

    <?php if ($item['description']): ?>
    <p style="line-height:2;font-size:15.5px;white-space:pre-line;"><?= nl2br(e($item['description'])) ?></p>
    <?php endif; ?>

    <?php if ($item['link']): ?>
    <a href="<?= e($item['link']) ?>" target="_blank" rel="noopener" class="btn btn-primary btn-sm" style="width:auto;margin-top:18px;">
      <i class="fa-solid fa-arrow-up-right-from-square"></i> مشاهده‌ی وب‌سایت زنده
    </a>
    <?php endif; ?>

    <?php if ($gallery): ?>
    <div class="grid grid-3" style="margin-top:30px;">
      <?php foreach ($gallery as $g): ?>
      <img loading="lazy" decoding="async" src="<?= e(image_url($g['image'], 'portfolio')) ?>" alt="<?= e($item['title']) ?> — تصویر گالری" style="border-radius:var(--radius-sm);">
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($assets): ?>
    <div class="card glass" style="margin-top:30px;padding:18px;">
      <h3 style="margin-bottom:12px;font-size:15px;">فایل‌های پیوست</h3>
      <?php foreach ($assets as $a): $embeddable = in_array($a['ext'], ['html', 'htm', 'svg'], true); ?>
        <?php if ($embeddable): ?>
        <div style="margin-bottom:16px;">
          <p style="font-size:13px;color:var(--text-2);margin-bottom:8px;"><i class="fa-solid fa-code"></i> <?= e($a['original_name'] ?: $a['file_name']) ?></p>
          <iframe src="asset-embed.php?id=<?= (int) $a['id'] ?>" sandbox="allow-scripts" loading="lazy"
                  style="width:100%;height:480px;border:1px solid var(--color-border,#333);border-radius:var(--radius-sm);background:#fff;"></iframe>
        </div>
        <?php else: ?>
        <a href="<?= e(asset_url($a['file_name'], 'portfolio')) ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm" style="width:auto;display:inline-flex;margin:0 6px 6px 0;">
          <i class="fa-solid <?= e(asset_icon($a['ext'])) ?>"></i> <?= e($a['original_name'] ?: $a['file_name']) ?>
        </a>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div style="margin-top:36px;">
      <a href="portfolio.php" class="btn btn-outline btn-sm" style="width:auto"><i class="fa-solid fa-arrow-right"></i> بازگشت به نمونه‌کارها</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
