<?php
require_once __DIR__ . '/includes/client-auth.php';
require_client_login();

$pageTitle = 'داشبورد من';

$myProjects = db()->prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC');
$myProjects->execute([$client['id']]);
$myProjects = $myProjects->fetchAll();

$totalMyProjects = count($myProjects);
$inProgressCount = count(array_filter($myProjects, fn($p) => $p['status'] === 'in_progress'));
$completedCount  = count(array_filter($myProjects, fn($p) => $p['status'] === 'completed'));
$pendingCount    = count(array_filter($myProjects, fn($p) => $p['status'] === 'pending'));
$avgProgress = $totalMyProjects ? (int) round(array_sum(array_column($myProjects, 'progress')) / $totalMyProjects) : 0;

$unreadCount = db()->prepare("SELECT COUNT(*) FROM client_messages WHERE user_id = ? AND sender = 'admin' AND is_read = 0");
$unreadCount->execute([$client['id']]);
$unreadCount = (int) $unreadCount->fetchColumn();

$recentMessages = db()->prepare('SELECT * FROM client_messages WHERE user_id = ? ORDER BY created_at DESC LIMIT 3');
$recentMessages->execute([$client['id']]);
$recentMessages = $recentMessages->fetchAll();

require __DIR__ . '/includes/client-header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/client-sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/client-topbar.php'; ?>

        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>">
                    <i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?>
                </div>
            <?php endif; ?>

            <div class="page-head">
                <div>
                    <h2>خوش آمدید، <?= e($client['full_name']) ?> 👋</h2>
                    <p class="breadcrumb">پنل کاربری <b>/ نمای کلی</b></p>
                </div>
            </div>

            <!-- STAT CARDS -->
            <div class="stats-grid">
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-folder-open"></i></div>
                    <div>
                        <div class="label">پروژه‌های من</div>
                        <div class="value"><?= $totalMyProjects ?></div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-spinner"></i></div>
                    <div>
                        <div class="label">در حال اجرا</div>
                        <div class="value"><?= $inProgressCount ?></div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-circle-check"></i></div>
                    <div>
                        <div class="label">تکمیل‌شده</div>
                        <div class="value"><?= $completedCount ?></div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-chart-simple"></i></div>
                    <div>
                        <div class="label">میانگین پیشرفت</div>
                        <div class="value"><?= $avgProgress ?>%</div>
                    </div>
                </div>
            </div>

            <!-- WELCOME -->
            <div class="row">
                <div class="welcome-card glass">
                    <div class="txt">
                        <h2>وضعیت پروژه‌های شما</h2>
                        <p>
                            شما در حال حاضر <b><?= $totalMyProjects ?></b> پروژه در پنل دارید و
                            <b><?= $unreadCount ?></b> پیام جدید از تیم Nononik برایتان ارسال شده است.
                        </p>
                        <br>
                        <a href="projects.php" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-folder-open"></i> مشاهده پروژه‌ها</a>
                    </div>
                    <div class="visual">
                        <div class="orb" style="width:70px;height:70px;background:radial-gradient(circle,#8b5cf6,transparent);top:10px;right:10px;"></div>
                        <div class="orb" style="width:100px;height:100px;background:radial-gradient(circle,#3b82f6,transparent);bottom:0;left:10px;"></div>
                        <i class="fa-solid fa-rocket" style="font-size:70px;background:linear-gradient(135deg,#8b5cf6,#3b82f6);-webkit-background-clip:text;background-clip:text;color:transparent;position:absolute;bottom:30px;left:50%;transform:translateX(-50%);"></i>
                    </div>
                </div>

                <div class="card glass">
                    <div class="card-head">
                        <h3>پیام‌های اخیر</h3>
                        <a href="messages.php" class="link">مشاهده همه</a>
                    </div>
                    <?php if ($recentMessages): ?>
                    <ul class="tasks-list">
                        <?php foreach ($recentMessages as $m): ?>
                        <li>
                            <span class="task-check <?= $m['sender'] === 'admin' ? '' : 'done' ?>">
                                <i class="fa-solid <?= $m['sender'] === 'admin' ? 'fa-user-tie' : 'fa-user' ?>"></i>
                            </span>
                            <span><?= e(mb_strimwidth($m['message'], 0, 60, '…')) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                    <div class="empty-state" style="padding:24px 20px;">
                        <i class="fa-regular fa-comments"></i>
                        <h4>هنوز پیامی نیست</h4>
                        <p>هر سوالی درباره پروژه‌تان دارید، از بخش «پیام‌ها» با تیم ما در ارتباط باشید.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- STATUS CHART + RECENT ACTIVITY -->
            <div class="row" style="margin-top:18px;">
                <div class="card glass" style="max-width:320px;">
                    <div class="card-head"><h3>وضعیت پروژه‌ها</h3></div>
                    <?php if ($totalMyProjects): ?>
                    <canvas id="statusChart" height="220"></canvas>
                    <?php else: ?>
                    <div class="empty-state" style="padding:24px 20px;">
                        <i class="fa-solid fa-chart-pie"></i>
                        <h4>هنوز داده‌ای نیست</h4>
                        <p>به‌محض ثبت اولین پروژه، نمودار وضعیت اینجا نمایش داده می‌شود.</p>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card glass" style="flex:1;">
                    <div class="card-head"><h3>فعالیت‌های اخیر</h3></div>
                    <?php if ($recentMessages || $myProjects): ?>
                    <ul class="tasks-list">
                        <?php foreach (array_slice($myProjects, 0, 3) as $p): ?>
                        <li>
                            <span class="task-check <?= $p['status'] === 'completed' ? 'done' : '' ?>">
                                <i class="fa-solid <?= $p['status'] === 'completed' ? 'fa-check' : 'fa-spinner' ?>"></i>
                            </span>
                            <span>پروژه «<?= e($p['title']) ?>» — <?= e(status_label($p['status'])) ?> (<?= (int)$p['progress'] ?>%)</span>
                        </li>
                        <?php endforeach; ?>
                        <?php foreach (array_slice($recentMessages, 0, 2) as $m): ?>
                        <li>
                            <span class="task-check">
                                <i class="fa-solid <?= $m['sender'] === 'admin' ? 'fa-user-tie' : 'fa-user' ?>"></i>
                            </span>
                            <span><?= $m['sender'] === 'admin' ? 'پیام جدید از تیم Nononik' : 'پیام شما ارسال شد' ?> — <?= e(time_ago($m['created_at'])) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                    <div class="empty-state" style="padding:24px 20px;">
                        <i class="fa-regular fa-clock"></i>
                        <h4>هنوز فعالیتی ثبت نشده</h4>
                        <p>فعالیت‌های مربوط به پروژه‌ها و پیام‌هایتان اینجا نمایش داده می‌شود.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- MY PROJECTS -->
            <div class="card glass" style="margin-top:18px;">
                <div class="card-head">
                    <h3>پروژه‌های من</h3>
                    <a href="projects.php" class="link">مشاهده همه</a>
                </div>
                <?php if ($myProjects): ?>
                <div class="projects-grid">
                    <?php foreach (array_slice($myProjects, 0, 4) as $p): ?>
                    <div class="project-tile glass">
                        <img loading="lazy" decoding="async" class="thumb" src="<?= e(image_url($p['image'], 'projects')) ?>" alt="<?= e($p['title']) ?>">
                        <div class="info">
                            <b><?= e($p['title']) ?></b>
                            <small class="<?= $p['status'] === 'completed' ? 'green' : '' ?>"><?= e(status_label($p['status'])) ?> — <?= (int)$p['progress'] ?>%</small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="empty-state" style="padding:32px 20px;">
                    <i class="fa-regular fa-folder-open"></i>
                    <h4>هنوز پروژه‌ای برای شما ثبت نشده</h4>
                    <p>به‌محض شروع پروژه توسط تیم Nononik، اینجا نمایش داده می‌شود.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if ($totalMyProjects): ?>
<script>
// چرا: داده مستقیم از سرور رندر می‌شود (بدون فراخوانی AJAX اضافه) چون حجم داده کاربر تکی کوچک و ثابت در هر بارگذاری صفحه است
new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: ['در حال اجرا', 'تکمیل شده', 'در انتظار'],
        datasets: [{
            data: [<?= $inProgressCount ?>, <?= $completedCount ?>, <?= $pendingCount ?>],
            backgroundColor: ['#8b5cf6', '#22c55e', '#f59e0b'],
            borderWidth: 0
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom', labels: { color: '#8b85a8', font: { family: 'Vazirmatn' } } } },
        cutout: '68%'
    }
});
</script>
<?php endif; ?>
<?php require __DIR__ . '/includes/client-footer.php'; ?>
