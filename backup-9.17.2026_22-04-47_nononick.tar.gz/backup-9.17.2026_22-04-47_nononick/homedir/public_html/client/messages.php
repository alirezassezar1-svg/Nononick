<?php
require_once __DIR__ . '/includes/client-auth.php';
require_client_login();

$pageTitle = 'پیام‌ها با آژانس';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $text = trim($_POST['message'] ?? '');
    if ($text !== '') {
        db()->prepare('INSERT INTO client_messages (user_id, sender, message) VALUES (?, "client", ?)')
            ->execute([$client['id'], $text]);
    }
    redirect('messages.php');
}

// چرا: با باز شدن صفحه، پیام‌های ادمین برای همین کاربر خوانده‌شده علامت می‌خورند (فقط رکوردهای خودش)
db()->prepare("UPDATE client_messages SET is_read = 1 WHERE user_id = ? AND sender = 'admin'")->execute([$client['id']]);

$thread = db()->prepare('SELECT * FROM client_messages WHERE user_id = ? ORDER BY created_at ASC');
$thread->execute([$client['id']]);
$thread = $thread->fetchAll();

require __DIR__ . '/includes/client-header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/client-sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/client-topbar.php'; ?>

        <div class="content">
            <div class="page-head">
                <div>
                    <h2>پیام‌ها با آژانس</h2>
                    <p class="breadcrumb">پنل کاربری <b>/ پیام‌ها</b></p>
                </div>
            </div>

            <div class="card glass" style="display:flex;flex-direction:column;height:min(600px, 70vh);">
                <div style="flex:1;overflow-y:auto;padding:6px 4px;display:flex;flex-direction:column;gap:12px;">
                    <?php if (!$thread): ?>
                    <div class="empty-state" style="padding:32px 20px;">
                        <i class="fa-regular fa-comments"></i>
                        <h4>هنوز گفت‌وگویی شروع نشده</h4>
                        <p>سوال یا درخواستی درباره پروژه‌تان دارید؟ همین پایین پیام خود را بنویسید.</p>
                    </div>
                    <?php else: foreach ($thread as $m): $mine = $m['sender'] === 'client'; ?>
                    <div style="align-self:<?= $mine ? 'flex-start' : 'flex-end' ?>;max-width:75%;">
                        <div style="background:<?= $mine ? 'var(--glass-strong)' : 'linear-gradient(135deg, var(--purple), var(--blue))' ?>;color:<?= $mine ? 'var(--text-0)' : '#fff' ?>;border:1px solid var(--border);border-radius:var(--radius-md);padding:10px 14px;font-size:13.5px;line-height:1.9;">
                            <?= nl2br(e($m['message'])) ?>
                        </div>
                        <small style="display:block;margin-top:4px;color:var(--text-2);font-size:11px;">
                            <?= $mine ? 'شما' : 'تیم Nononik' ?> — <?= e(time_ago($m['created_at'])) ?>
                        </small>
                    </div>
                    <?php endforeach; endif; ?>
                </div>

                <form method="post" style="display:flex;gap:10px;margin-top:14px;border-top:1px solid var(--border);padding-top:14px;">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="text" name="message" class="form-control" placeholder="پیام خود را بنویسید..." required autocomplete="off" style="flex:1;">
                    <button type="submit" class="btn btn-primary" style="width:auto;"><i class="fa-solid fa-paper-plane"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/client-footer.php'; ?>
