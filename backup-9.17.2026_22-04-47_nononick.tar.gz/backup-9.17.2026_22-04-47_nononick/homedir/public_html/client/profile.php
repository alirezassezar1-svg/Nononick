<?php
require_once __DIR__ . '/includes/client-auth.php';
require_client_login();

$pageTitle = 'پروفایل و تنظیمات';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name  = trim($_POST['full_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        if ($name === '') {
            set_flash('error', 'نام نمی‌تواند خالی باشد.');
        } else {
            $avatar = upload_image($_FILES['avatar'] ?? [], 'users', $client['avatar'] ?: null);
            db()->prepare('UPDATE users SET full_name=?, phone=?, avatar=? WHERE id=?')
                ->execute([$name, $phone ?: null, $avatar, $client['id']]);
            set_flash('success', 'پروفایل با موفقیت به‌روزرسانی شد.');
        }
        redirect('profile.php');
    }

    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['new_password_confirm'] ?? '';

        if (!$client['password'] || !password_verify($current, $client['password'])) {
            set_flash('error', 'رمز عبور فعلی صحیح نیست.');
        } elseif (strlen($new) < 8) {
            set_flash('error', 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.');
        } elseif ($new !== $confirm) {
            set_flash('error', 'تکرار رمز عبور جدید یکسان نیست.');
        } else {
            db()->prepare('UPDATE users SET password=? WHERE id=?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), $client['id']]);
            set_flash('success', 'رمز عبور با موفقیت تغییر کرد.');
        }
        redirect('profile.php');
    }
}

require __DIR__ . '/includes/client-header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/client-sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/client-topbar.php'; ?>

        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>">
                    <i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?>
                </div>
            <?php endif; ?>

            <div class="page-head">
                <div>
                    <h2>پروفایل و تنظیمات</h2>
                    <p class="breadcrumb">پنل کاربری <b>/ پروفایل</b></p>
                </div>
            </div>

            <div class="row">
                <div class="card glass" style="flex:1;">
                    <div class="card-head"><h3>اطلاعات پروفایل</h3></div>
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="action" value="update_profile">
                        <div style="text-align:center;margin-bottom:16px;">
                            <img class="avatar" style="width:84px;height:84px;" src="<?= e(image_url($client['avatar'] ?? null, 'users')) ?>" alt="avatar">
                        </div>
                        <div class="form-group">
                            <label>تصویر پروفایل</label>
                            <input type="file" name="avatar" class="form-control" accept="image/*">
                        </div>
                        <div class="form-group">
                            <label>نام و نام خانوادگی</label>
                            <input type="text" name="full_name" class="form-control" required value="<?= e($client['full_name']) ?>">
                        </div>
                        <div class="form-group">
                            <label>ایمیل</label>
                            <input type="email" class="form-control" value="<?= e($client['email']) ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>شماره تماس</label>
                            <input type="text" name="phone" class="form-control" value="<?= e($client['phone'] ?? '') ?>">
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره تغییرات</button>
                    </form>
                </div>

                <div class="card glass" style="flex:1;">
                    <div class="card-head"><h3>تغییر رمز عبور</h3></div>
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="action" value="change_password">
                        <div class="form-group">
                            <label>رمز عبور فعلی</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>رمز عبور جدید</label>
                            <input type="password" name="new_password" class="form-control" required minlength="8">
                        </div>
                        <div class="form-group">
                            <label>تکرار رمز عبور جدید</label>
                            <input type="password" name="new_password_confirm" class="form-control" required minlength="8">
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-key"></i> تغییر رمز عبور</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/client-footer.php'; ?>
