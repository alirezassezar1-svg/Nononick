<?php
/**
 * @var string $pageTitle
 * @var string|null $metaDescription
 * چرا: از همان Design System پنل ادمین (design-tokens/theme/motion/components) استفاده می‌کند
 * تا پنل کاربر دقیقاً همان ظاهر شیشه‌ای/نئون پنل ادمین را داشته باشد.
 */
$siteTitle = setting('site_title', 'Nononik');
$siteDesc  = $metaDescription ?? setting('site_description', 'پنل مدیریت هوشمند Nononik');
$siteLogo  = setting('site_logo', '') ?: (BASE_URL . 'assets/img/placeholder.svg');
$ogImage   = setting('og_image', '') ?: $siteLogo;

$currentScript = basename($_SERVER['SCRIPT_NAME']);
$publicSeoPages = ['login.php', 'register.php'];
$isPublicSeoPage = in_array($currentScript, $publicSeoPages, true);

// چرا: صفحات ورود/ثبت‌نام مسیر عمومی سایت‌اند و می‌توانند در گوگل ایندکس شوند (جست‌وجوی برند مثل «ورود پنل کاربری Nononik»)،
// اما بقیه‌ی صفحات پنل کاربر خصوصی و پشت لاگین هستند و نباید ایندکس شوند.
$robotsContent = $isPublicSeoPage ? 'index, follow' : 'noindex, nofollow';
$canonicalUrl = rtrim(BASE_URL, '/') . '/client/' . $currentScript;
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'پنل کاربری') ?> | <?= e($siteTitle) ?></title>

<meta name="robots" content="<?= e($robotsContent) ?>">
<meta name="description" content="<?= e($siteDesc) ?>">
<link rel="canonical" href="<?= e($canonicalUrl) ?>">

<!-- Open Graph -->
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($pageTitle ?? 'پنل کاربری') ?> | <?= e($siteTitle) ?>">
<meta property="og:description" content="<?= e($siteDesc) ?>">
<meta property="og:image" content="<?= e($ogImage) ?>">
<meta property="og:url" content="<?= e($canonicalUrl) ?>">
<meta property="og:locale" content="fa_IR">

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($siteTitle) ?>">
<meta name="twitter:description" content="<?= e($siteDesc) ?>">

<?php if ($isPublicSeoPage): ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": <?= json_encode($pageTitle ?? 'پنل کاربری', JSON_UNESCAPED_UNICODE) ?>,
  "description": <?= json_encode($siteDesc, JSON_UNESCAPED_UNICODE) ?>,
  "isPartOf": {
    "@type": "WebSite",
    "name": <?= json_encode($siteTitle, JSON_UNESCAPED_UNICODE) ?>
  }
}
</script>
<?php endif; ?>

<!-- چرا: اعمال تم قبل از رندر CSS، جلوگیری از فلش تم اشتباه (FOUC) -->
<script>
(function () {
  var saved = localStorage.getItem('sunpanel-theme');
  var theme = saved || 'dark';
  document.documentElement.setAttribute('data-theme', theme);
})();
</script>

<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" media="all">
<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>

<!-- Design System (همان فایل‌های پنل ادمین) -->
<link rel="icon" href="<?= BASE_URL ?>assets/images/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>assets/images/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="48x48" href="<?= BASE_URL ?>assets/images/favicon-48x48.png">
<link rel="icon" type="image/png" sizes="192x192" href="<?= BASE_URL ?>assets/images/favicon-192x192.png">
<link rel="icon" type="image/png" sizes="512x512" href="<?= BASE_URL ?>assets/images/favicon-512x512.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>assets/images/apple-touch-icon.png">
<link rel="manifest" href="<?= BASE_URL ?>assets/images/site.webmanifest">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/design-tokens.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/theme.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/motion.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/components.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/text-3d.css">
<style>
:root{
  --text-3d-blue-1: <?= e(setting('text3d_blue1', '#c4b5fd')) ?>;
  --text-3d-blue-2: <?= e(setting('text3d_blue2', '#60a5fa')) ?>;
  --text-3d-pink-1: <?= e(setting('text3d_pink1', '#f0abfc')) ?>;
  --text-3d-pink-2: <?= e(setting('text3d_pink2', '#c084fc')) ?>;
}
</style>
</head>
<body>
<!-- چرا: پاریتی کامل بصری با پنل ادمین — همان لایه‌های Visual System -->
<div class="mesh-bg"></div>
<div class="custom-cursor" id="customCursor"></div>
<div class="page-transition" id="pageTransition"></div>
<div class="toast-container" id="toastContainer"></div>
