<?php
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$unreadClientMessages = db()->prepare("SELECT COUNT(*) FROM client_messages WHERE user_id = ? AND sender = 'admin' AND is_read = 0");
$unreadClientMessages->execute([$client['id']]);
$unreadClientMessages = (int) $unreadClientMessages->fetchColumn();

function client_nav_active(string $page, string $current): string {
    return $page === $current ? 'active' : '';
}
?>
<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="logo-cube" aria-hidden="true">
          <div class="logo-cube-inner">
            <div class="face front"></div>
            <div class="face back"></div>
            <div class="face right"></div>
            <div class="face left"></div>
            <div class="face top"></div>
            <div class="face bottom"></div>
          </div>
        </div>
    </div>

    <div class="profile-card">
        <img class="avatar" src="<?= e(image_url($client['avatar'] ?? null, 'users')) ?>" alt="avatar">
        <h4><?= e($client['full_name'] ?? 'مشتری') ?></h4>
        <p><?= e($client['role'] ?? 'مشتری') ?></p>
        <span class="badge-pro"><i class="fa-solid fa-user-check"></i> پنل کاربری</span>
    </div>

    <nav class="nav-menu">
        <a href="index.php" class="<?= client_nav_active('index.php', $currentPage) ?>"><i class="fa-solid fa-table-cells-large"></i> داشبورد</a>
        <a href="projects.php" class="<?= client_nav_active('projects.php', $currentPage) ?>"><i class="fa-solid fa-folder-open"></i> پروژه‌های من</a>
        <a href="messages.php" class="<?= client_nav_active('messages.php', $currentPage) ?>">
            <i class="fa-solid fa-envelope"></i> پیام‌ها با آژانس
            <?php if ($unreadClientMessages > 0): ?><span class="count"><?= $unreadClientMessages ?></span><?php endif; ?>
        </a>
        <a href="profile.php" class="<?= client_nav_active('profile.php', $currentPage) ?>"><i class="fa-solid fa-user-gear"></i> پروفایل و تنظیمات</a>
        <a href="<?= BASE_URL ?>site/index.php"><i class="fa-solid fa-arrow-up-right-from-square"></i> بازگشت به سایت</a>
    </nav>

    <div class="sidebar-bottom">
        <button class="btn-icon" id="themeToggleSidebar" title="حالت روشن/تاریک"><i class="fa-solid fa-circle-half-stroke"></i></button>
        <button class="btn-icon" data-sidebar-toggle title="منو"><i class="fa-solid fa-bars"></i></button>
        <a class="btn-icon" href="logout.php" title="خروج"><i class="fa-solid fa-power-off"></i></a>
    </div>
</aside>
