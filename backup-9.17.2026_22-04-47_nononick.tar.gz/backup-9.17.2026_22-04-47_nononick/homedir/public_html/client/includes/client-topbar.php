<?php $unreadClientMessages = $unreadClientMessages ?? 0; ?>
<header class="topbar">
    <button class="btn-icon" data-sidebar-toggle style="display:none" id="mobileToggle"><i class="fa-solid fa-bars"></i></button>
    <div class="search-box" style="visibility:hidden"></div>
    <div class="topbar-actions">
        <button class="icon-btn" id="themeToggle" title="حالت روشن/تاریک">
            <i class="fa-solid fa-circle-half-stroke"></i>
        </button>
        <a href="messages.php" class="icon-btn" title="پیام‌ها">
            <i class="fa-regular fa-envelope"></i>
            <?php if ($unreadClientMessages > 0): ?><span class="dot"><?= (int)$unreadClientMessages ?></span><?php endif; ?>
        </a>
        <div class="lang-pill"><i class="fa-solid fa-globe"></i> FA</div>
        <div class="admin-pill" data-admin-toggle>
            <img src="<?= e(image_url($client['avatar'] ?? null, 'users')) ?>" alt="avatar">
            <div>
                <div class="name"><?= e($client['full_name'] ?? 'مشتری') ?></div>
                <div class="role"><?= e($client['role'] ?? 'مشتری') ?></div>
            </div>
            <i class="fa-solid fa-chevron-down" style="font-size:11px;color:var(--text-2)"></i>
            <div class="admin-dropdown">
                <a href="profile.php"><i class="fa-regular fa-user"></i> پروفایل</a>
                <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> خروج</a>
            </div>
        </div>
    </div>
</header>
