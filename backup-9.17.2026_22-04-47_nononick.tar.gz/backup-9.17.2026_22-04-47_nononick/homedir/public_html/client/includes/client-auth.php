<?php
/**
 * Nononik — Client Panel Bootstrap
 * چرا: کاملاً مستقل از سشن ادمین (admin_id) عمل می‌کند تا یک نفر بتواند هم‌زمان
 * در پنل ادمین و پنل کاربر لاگین باشد بدون تداخل، و یک مشتری هرگز به صفحات ادمین دسترسی نداشته باشد.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/security.php';

apply_security_headers();

// ---- Auth guard ----
$currentScript = basename($_SERVER['SCRIPT_NAME']);
$publicPages = ['login.php', 'register.php'];

if (!in_array($currentScript, $publicPages, true)) {
    if (empty($_SESSION['client_id'])) {
        redirect('login.php');
    }
}

$client = null;
if (!empty($_SESSION['client_id'])) {
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ? AND status = "active"');
    $stmt->execute([$_SESSION['client_id']]);
    $client = $stmt->fetch();
    if (!$client) {
        session_destroy();
        redirect('login.php');
    }
}

/**
 * چرا: هر کوئری در صفحات پنل کاربر باید با user_id فیلتر شود تا مشتری فقط
 * داده‌ی خودش را ببیند (IDOR Prevention) — این تابع صرفاً یک محافظ خواندنی سریع است.
 */
function require_client_login(): array
{
    global $client;
    if (!$client) {
        redirect('login.php');
    }
    return $client;
}
