<?php
require_once __DIR__ . '/includes/client-auth.php';
require_client_login();

$pageTitle = 'پروژه‌های من';

$myProjects = db()->prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC');
$myProjects->execute([$client['id']]);
$myProjects = $myProjects->fetchAll();

require __DIR__ . '/includes/client-header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/client-sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/client-topbar.php'; ?>

        <div class="content">
            <div class="page-head">
                <div>
                    <h2>پروژه‌های من</h2>
                    <p class="breadcrumb">پنل کاربری <b>/ پروژه‌ها</b></p>
                </div>
                <span style="font-size:12.5px;color:var(--text-2)"><?= count($myProjects) ?> پروژه</span>
            </div>

            <?php if ($myProjects): ?>
            <div class="table-card glass">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>تصویر</th><th>عنوان پروژه</th><th>وضعیت</th><th>پیشرفت</th><th>تاریخ شروع</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($myProjects as $p): ?>
                        <tr>
                            <td><img loading="lazy" decoding="async" class="row-thumb" src="<?= e(image_url($p['image'], 'projects')) ?>" alt="<?= e($p['title']) ?>"></td>
                            <td>
                                <b><?= e($p['title']) ?></b>
                                <?php if ($p['description']): ?><br><small style="color:var(--text-2)"><?= e(mb_strimwidth($p['description'], 0, 70, '…')) ?></small><?php endif; ?>
                            </td>
                            <td><span class="badge badge-<?= e($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
                            <td style="min-width:120px;">
                                <div class="progress-bar"><span style="width:<?= (int)$p['progress'] ?>%"></span></div>
                                <small style="color:var(--text-2)"><?= (int)$p['progress'] ?>%</small>
                            </td>
                            <td><?= $p['started_at'] ? e(date('Y/m/d', strtotime($p['started_at']))) : '—' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state" style="padding:48px 20px;">
                <i class="fa-regular fa-folder-open"></i>
                <h4>هنوز پروژه‌ای برای شما ثبت نشده</h4>
                <p>به‌محض شروع پروژه توسط تیم Nononik، جزئیات و پیشرفت آن اینجا نمایش داده می‌شود. سوالی دارید؟ از بخش «پیام‌ها» با ما در ارتباط باشید.</p>
                <a href="messages.php" class="btn btn-primary" style="width:auto;margin-top:12px;"><i class="fa-solid fa-envelope"></i> ارسال پیام</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/client-footer.php'; ?>
