<?php
require_once __DIR__ . '/includes/client-auth.php';

if (!empty($_SESSION['client_id'])) {
    redirect('index.php');
}

$error = null;
$old = ['full_name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $fullName = trim($_POST['full_name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['password_confirm'] ?? '';
    $old = compact('fullName', 'email', 'phone') + ['full_name' => $fullName];

    if ($fullName === '' || $email === '' || $password === '') {
        $error = 'نام، ایمیل و رمز عبور الزامی است.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'ایمیل معتبر نیست.';
    } elseif (strlen($password) < 8) {
        $error = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
    } elseif ($password !== $confirm) {
        $error = 'تکرار رمز عبور با رمز عبور یکسان نیست.';
    } else {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'این ایمیل قبلاً در سامانه ثبت شده است.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            db()->prepare('INSERT INTO users (full_name, email, password, phone, role, status) VALUES (?,?,?,?,?,?)')
                ->execute([$fullName, $email, $hash, $phone ?: null, 'مشتری', 'active']);
            $newId = (int) db()->lastInsertId();

            session_regenerate_id(true);
            $_SESSION['client_id'] = $newId;
            db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$newId]);
            security_log('client_register', "email={$email}");
            redirect('index.php');
        }
    }
}

$pageTitle = 'ثبت‌نام در پنل کاربری';
$metaDescription = 'ثبت‌نام مشتریان جدید در پنل کاربری Nononik — همین حالا حساب بسازید و پیشرفت پروژه‌ی سایت خود را آنلاین دنبال کنید.';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> | Nononik</title>
<meta name="robots" content="noindex, follow">
<meta name="description" content="<?= e($metaDescription) ?>">
<link rel="canonical" href="<?= e(rtrim(BASE_URL, '/')) ?>/client/register.php">
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($pageTitle) ?> | Nononik">
<meta property="og:description" content="<?= e($metaDescription) ?>">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>assets/images/logo-mark.svg">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-card glass">
        <div class="logo">
            <svg viewBox="0 0 64 64" width="34" height="34" fill="#fff" aria-hidden="true">
                <polygon points="15,15 28,15 28,32 12,49 12,32"/>
                <polygon points="32,15 44,15 52,49 40,49 22,20"/>
                <polygon points="56,13 46,32 46,49 57,49 57,32"/>
            </svg>
        </div>
        <h1>ثبت‌نام در پنل کاربری</h1>
        <p>Nononik Client Panel — چند ثانیه تا شروع</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" novalidate>
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <div class="form-group">
                <label>نام و نام خانوادگی</label>
                <input type="text" name="full_name" class="form-control" required value="<?= e($old['full_name']) ?>">
            </div>
            <div class="form-group">
                <label>ایمیل</label>
                <input type="email" name="email" class="form-control" placeholder="you@example.com" required value="<?= e($old['email']) ?>">
            </div>
            <div class="form-group">
                <label>شماره تماس (اختیاری)</label>
                <input type="text" name="phone" class="form-control" value="<?= e($old['phone']) ?>">
            </div>
            <div class="form-group">
                <label>رمز عبور</label>
                <input type="password" name="password" class="form-control" placeholder="حداقل ۸ کاراکتر" required minlength="8">
            </div>
            <div class="form-group">
                <label>تکرار رمز عبور</label>
                <input type="password" name="password_confirm" class="form-control" required minlength="8">
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user-plus"></i> ثبت‌نام</button>
        </form>

        <div class="demo-hint">
            قبلاً ثبت‌نام کرده‌اید؟ <a href="login.php">ورود</a>
        </div>
    </div>
</div>
</body>
</html>
