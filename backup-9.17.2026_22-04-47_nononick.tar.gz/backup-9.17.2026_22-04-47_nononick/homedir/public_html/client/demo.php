<?php
/**
 * Nononik — Client Panel Public Demo
 * چرا: این صفحه کاملاً عمومی و بدون لاگین است تا بازدیدکنندگان سایت قبل از ثبت‌نام،
 * حس‌وحال پنل کاربری را ببینند — دقیقاً مثل صفحات دمو/نمایشی محصولات اپل.
 * تمام داده‌های این صفحه ساختگی (Hardcoded) هستند و هیچ کوئری‌ای به جدول users/projects/client_messages
 * با شناسه‌ی کاربر واقعی زده نمی‌شود، پس هیچ اطلاعات واقعی مشتری هرگز از این مسیر قابل‌دسترسی نیست.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/security.php';

apply_security_headers();

// چرا: شیء $client ساختگی صرفاً برای سازگاری با include‌های header/sidebar/topbar موجود است — id=0 هرگز به یک کاربر واقعی اشاره نمی‌کند
$client = [
    'id'        => 0,
    'full_name' => 'کاربر نمایشی',
    'email'     => 'demo@nononik.com',
    'avatar'    => null,
    'role'      => 'مشتری (نسخه نمایشی)',
];

// داده‌های کاملاً ساختگی برای نمایش UI — هیچ ارتباطی با دیتابیس واقعی ندارند
$demoProjects = [
    ['title' => 'فروشگاه آنلاین پوشاک', 'status' => 'in_progress', 'progress' => 65],
    ['title' => 'اپلیکیشن رزرو نوبت', 'status' => 'completed', 'progress' => 100],
    ['title' => 'ری‌دیزاین وب‌سایت شرکتی', 'status' => 'pending', 'progress' => 10],
];
$totalMyProjects = count($demoProjects);
$inProgressCount = 1;
$completedCount  = 1;
$pendingCount    = 1;
$avgProgress     = 58;
$unreadCount     = 2;

$demoMessages = [
    ['sender' => 'admin',  'message' => 'سلام! طراحی اولیه صفحه اصلی آماده شد، لطفاً بررسی کنید.', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
    ['sender' => 'client', 'message' => 'عالیه، فقط رنگ دکمه‌ها رو هماهنگ با لوگو کنید.',            'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
];

$pageTitle = 'پیش‌نمایش پنل کاربری';
$metaDescription = 'پیش‌نمایش عمومی پنل کاربری Nononik — بدون نیاز به ثبت‌نام، ببینید مشتریان ما چطور پیشرفت پروژه و گفتگو با تیم را دنبال می‌کنند.';

require __DIR__ . '/includes/client-header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/client-sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/client-topbar.php'; ?>

        <div class="content">
            <div class="alert alert-success" style="align-items:center;">
                <i class="fa-solid fa-eye"></i>
                این یک <b>نسخه نمایشی</b> با داده‌ی ساختگی است — برای دیدن پروژه‌های واقعی خودتان
                <a href="register.php" style="text-decoration:underline;font-weight:700;">ثبت‌نام کنید</a>
                یا اگر قبلاً حساب دارید <a href="login.php" style="text-decoration:underline;font-weight:700;">وارد شوید</a>.
            </div>

            <div class="page-head">
                <div>
                    <h2>خوش آمدید، کاربر نمایشی 👋</h2>
                    <p class="breadcrumb">پنل کاربری <b>/ پیش‌نمایش عمومی</b></p>
                </div>
            </div>

            <!-- STAT CARDS -->
            <div class="stats-grid">
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-folder-open"></i></div>
                    <div>
                        <div class="label">پروژه‌های من</div>
                        <div class="value"><?= $totalMyProjects ?></div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-spinner"></i></div>
                    <div>
                        <div class="label">در حال اجرا</div>
                        <div class="value"><?= $inProgressCount ?></div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-circle-check"></i></div>
                    <div>
                        <div class="label">تکمیل‌شده</div>
                        <div class="value"><?= $completedCount ?></div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-chart-simple"></i></div>
                    <div>
                        <div class="label">میانگین پیشرفت</div>
                        <div class="value"><?= $avgProgress ?>%</div>
                    </div>
                </div>
            </div>

            <!-- WELCOME + MESSAGES -->
            <div class="row">
                <div class="welcome-card glass">
                    <div class="txt">
                        <h2>وضعیت پروژه‌های شما</h2>
                        <p>
                            شما در حال حاضر <b><?= $totalMyProjects ?></b> پروژه در پنل دارید و
                            <b><?= $unreadCount ?></b> پیام جدید از تیم Nononik برایتان ارسال شده است.
                        </p>
                        <br>
                        <a href="register.php" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-user-plus"></i> همین حالا ثبت‌نام کنید</a>
                    </div>
                    <div class="visual">
                        <div class="orb" style="width:70px;height:70px;background:radial-gradient(circle,#8b5cf6,transparent);top:10px;right:10px;"></div>
                        <div class="orb" style="width:100px;height:100px;background:radial-gradient(circle,#3b82f6,transparent);bottom:0;left:10px;"></div>
                        <i class="fa-solid fa-rocket" style="font-size:70px;background:linear-gradient(135deg,#8b5cf6,#3b82f6);-webkit-background-clip:text;background-clip:text;color:transparent;position:absolute;bottom:30px;left:50%;transform:translateX(-50%);"></i>
                    </div>
                </div>

                <div class="card glass">
                    <div class="card-head">
                        <h3>پیام‌های اخیر (نمونه)</h3>
                    </div>
                    <ul class="tasks-list">
                        <?php foreach ($demoMessages as $m): ?>
                        <li>
                            <span class="task-check <?= $m['sender'] === 'admin' ? '' : 'done' ?>">
                                <i class="fa-solid <?= $m['sender'] === 'admin' ? 'fa-user-tie' : 'fa-user' ?>"></i>
                            </span>
                            <span><?= e(mb_strimwidth($m['message'], 0, 60, '…')) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- STATUS CHART -->
            <div class="row" style="margin-top:18px;">
                <div class="card glass" style="max-width:320px;">
                    <div class="card-head"><h3>وضعیت پروژه‌ها (نمونه)</h3></div>
                    <canvas id="statusChart" height="220"></canvas>
                </div>
                <div class="card glass" style="flex:1;">
                    <div class="card-head"><h3>پروژه‌های نمونه</h3></div>
                    <div class="projects-grid">
                        <?php foreach ($demoProjects as $p): ?>
                        <div class="project-tile glass">
                            <div class="thumb" style="display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,rgba(139,92,246,.25),rgba(59,130,246,.25));">
                                <i class="fa-solid fa-image" style="font-size:22px;color:var(--text-2)"></i>
                            </div>
                            <div class="info">
                                <b><?= e($p['title']) ?></b>
                                <small class="<?= $p['status'] === 'completed' ? 'green' : '' ?>"><?= e(status_label($p['status'])) ?> — <?= (int)$p['progress'] ?>%</small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="card glass" style="margin-top:18px;text-align:center;padding:32px 20px;">
                <i class="fa-solid fa-circle-check" style="font-size:28px;color:var(--purple);margin-bottom:10px;"></i>
                <h3 style="margin-bottom:8px;">این فقط یک نمونه بود</h3>
                <p style="color:var(--text-2);margin-bottom:16px;">با ثبت‌نام رایگان، پیشرفت پروژه واقعی خودتان را آنلاین دنبال کنید و مستقیم با تیم ما در ارتباط باشید.</p>
                <a href="register.php" class="btn btn-primary" style="width:auto;display:inline-flex;"><i class="fa-solid fa-user-plus"></i> ساخت حساب کاربری رایگان</a>
            </div>
        </div>
    </div>
</div>

<script>
new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: ['در حال اجرا', 'تکمیل شده', 'در انتظار'],
        datasets: [{
            data: [<?= $inProgressCount ?>, <?= $completedCount ?>, <?= $pendingCount ?>],
            backgroundColor: ['#8b5cf6', '#22c55e', '#f59e0b'],
            borderWidth: 0
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom', labels: { color: '#8b85a8', font: { family: 'Vazirmatn' } } } },
        cutout: '68%'
    }
});
</script>
<?php require __DIR__ . '/includes/client-footer.php'; ?>
