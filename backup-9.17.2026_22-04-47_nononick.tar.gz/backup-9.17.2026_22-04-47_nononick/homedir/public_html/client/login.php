<?php
require_once __DIR__ . '/includes/client-auth.php';

if (!empty($_SESSION['client_id'])) {
    redirect('index.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'لطفاً ایمیل و رمز عبور را وارد کنید.';
    } elseif (login_is_rate_limited($email)) {
        // چرا: محدودسازی Brute-force مشترک با پنل ادمین — همان جدول login_attempts
        $error = 'به‌دلیل تلاش‌های ناموفق زیاد، حساب موقتاً قفل شده است. لطفاً ۱۵ دقیقه دیگر تلاش کنید.';
        security_log('client_login_blocked', "email={$email}");
    } else {
        $stmt = db()->prepare('SELECT * FROM users WHERE email = ? AND status = "active" LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && $user['password'] && password_verify($password, $user['password'])) {
            login_record_attempt($email, true);
            login_attempts_cleanup();
            session_regenerate_id(true);
            $_SESSION['client_id'] = $user['id'];
            db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$user['id']]);
            redirect('index.php');
        } else {
            login_record_attempt($email, false);
            $error = 'ایمیل یا رمز عبور اشتباه است.';
        }
    }
}

$pageTitle = 'ورود به پنل کاربری';
$metaDescription = 'ورود مشتریان به پنل کاربری Nononik — پیگیری آنلاین پیشرفت پروژه، گفتگو مستقیم با تیم و مدیریت حساب کاربری.';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> | Nononik</title>
<meta name="robots" content="noindex, follow">
<meta name="description" content="<?= e($metaDescription) ?>">
<link rel="canonical" href="<?= e(rtrim(BASE_URL, '/')) ?>/client/login.php">
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($pageTitle) ?> | Nononik">
<meta property="og:description" content="<?= e($metaDescription) ?>">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="icon" href="<?= BASE_URL ?>assets/images/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="192x192" href="<?= BASE_URL ?>assets/images/favicon-192x192.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>assets/images/apple-touch-icon.png">
<link rel="manifest" href="<?= BASE_URL ?>assets/images/site.webmanifest">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-card glass">
        <div class="logo">
            <img src="<?= BASE_URL ?>assets/images/logo-mark-white-128.png" width="34" height="34" alt="Nononik" style="width:34px;height:34px;object-fit:contain;">
        </div>
        <h1>ورود به پنل کاربری</h1>
        <p>Nononik Client Panel — پیگیری پروژه شما</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($flash = get_flash()): ?>
            <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <form method="post" novalidate>
            <div class="form-group">
                <label>ایمیل</label>
                <input type="email" name="email" class="form-control" placeholder="you@example.com" required value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>رمز عبور</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-right-to-bracket"></i> ورود</button>
        </form>

        <div class="demo-hint">
            حساب ندارید؟ <a href="register.php">ثبت‌نام کنید</a> &nbsp;|&nbsp; <a href="demo.php">مشاهده پیش‌نمایش بدون ثبت‌نام</a>
        </div>
        <div class="demo-hint">
            کاربر آزمایشی: <b>ali@example.com</b> &nbsp; | &nbsp; رمز عبور: <b>Client@123</b>
        </div>
    </div>
</div>
</body>
</html>
