<?php
require_once __DIR__ . '/includes/client-auth.php';
unset($_SESSION['client_id']);
session_regenerate_id(true);
redirect('login.php');
