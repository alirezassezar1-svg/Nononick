<?php
$pageTitle = 'خدمات ما | Nononik';
$pageDescription = 'خدمات آژانس طراحی وب Nononik: طراحی سایت، پنل مدیریت اختصاصی، سئوی فنی و پشتیبانی.';
require_once __DIR__ . '/includes/site-header.php';

$services = db()->query('SELECT * FROM services ORDER BY sort_order ASC')->fetchAll();
?>
<section class="hero page-head" style="padding:80px 0 50px;">
  <div class="hero-orb" style="width:220px;height:220px;background:radial-gradient(circle,rgba(139,92,246,0.48),transparent 70%);top:-40px;left:10%;"></div>
  <div class="wrap">
    <span class="hero-badge stagger-item"><i class="fa-solid fa-layer-group"></i> خدمات ما</span>
    <h1 class="stagger-item">هر آنچه برای حضور آنلاین حرفه‌ای لازم دارید</h1>
    <p class="stagger-item">از طراحی سایت تا پنل مدیریت و سئوی فنی — یک تیم، یک مسیر یکپارچه.</p>
  </div>
</section>

<section class="section" style="padding-top:20px;">
  <div class="wrap">
    <div class="grid grid-3">
      <?php if ($services): foreach ($services as $s): ?>
      <div class="card glass service-card stagger-item">
        <div class="ic"><i class="<?= htmlspecialchars($s['icon'] ?: 'fa-solid fa-globe') ?>"></i></div>
        <h3><?= htmlspecialchars($s['title']) ?></h3>
        <p><?= htmlspecialchars($s['description'] ?? '') ?></p>
      </div>
      <?php endforeach; else: ?>
      <!-- TODO: از پنل ادمین → «خدمات» می‌تونید خدمات واقعی خودتون رو ثبت کنید تا اینجا نمایش داده بشه -->
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-globe"></i></div><h3>طراحی وب‌سایت اختصاصی</h3><p>طراحی و توسعه‌ی وب‌سایت‌های حرفه‌ای، ریسپانسیو و سریع، متناسب با هویت برند شما</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-gauge"></i></div><h3>پنل مدیریت اختصاصی</h3><p>ساخت داشبورد و پنل مدیریت متناسب با فرآیندهای کسب‌وکار شما</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-cart-shopping"></i></div><h3>فروشگاه آنلاین</h3><p>راه‌اندازی فروشگاه اینترنتی حرفه‌ای با درگاه پرداخت امن و مدیریت سفارش</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-magnifying-glass-chart"></i></div><h3>سئو و بهینه‌سازی</h3><p>افزایش رتبه در گوگل با سئوی فنی، محتوایی و لینک‌سازی هدفمند</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-palette"></i></div><h3>برندینگ و هویت بصری</h3><p>طراحی لوگو، پالت رنگ و راهنمای برند برای تمایز از رقبا</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-pen-ruler"></i></div><h3>طراحی UI/UX</h3><p>تجربه کاربری روان و رابط کاربری مدرن برای افزایش نرخ تبدیل</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-mobile-screen-button"></i></div><h3>توسعه اپلیکیشن موبایل</h3><p>طراحی و توسعه اپلیکیشن iOS و اندروید متصل به همان پنل مدیریت</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-hashtag"></i></div><h3>مدیریت شبکه‌های اجتماعی</h3><p>تولید محتوای بصری و مدیریت حرفه‌ای اینستاگرام و سایر پلتفرم‌ها</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-bullhorn"></i></div><h3>تبلیغات دیجیتال</h3><p>کمپین‌های گوگل ادز و شبکه‌های اجتماعی با تحلیل بازگشت سرمایه</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-pen-nib"></i></div><h3>تولید محتوا</h3><p>نگارش محتوای سئو-محور برای وبلاگ، صفحات فرود و شبکه‌های اجتماعی</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-shield-halved"></i></div><h3>امنیت و نگهداری</h3><p>بک‌آپ منظم، بروزرسانی، مانیتورینگ و محافظت سایت در برابر تهدیدات</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-headset"></i></div><h3>پشتیبانی فنی ۲۴/۷</h3><p>پشتیبانی مستمر و پاسخگویی سریع پس از تحویل پروژه</p></div>
      <?php endif; ?>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="cta-band">
      <h2>می‌خواهید پروژه‌تان را شروع کنیم؟</h2>
      <a href="contact.php" class="btn btn-primary" style="width:auto;">درخواست مشاوره رایگان</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
