<?php
$pageTitle = 'Nononik | آژانس طراحی وب‌سایت';
$pageDescription = 'آژانس طراحی وب‌سایت Nononik؛ طراحی سایت حرفه‌ای، پنل مدیریت اختصاصی، سئوی فنی و پشتیبانی کامل کسب‌وکار شما.';
require_once __DIR__ . '/includes/site-header.php';

$services  = db()->query('SELECT * FROM services ORDER BY sort_order ASC LIMIT 3')->fetchAll();
$portfolio = db()->query('SELECT * FROM portfolio ORDER BY created_at DESC LIMIT 3')->fetchAll();
$articles  = db()->query("SELECT * FROM articles WHERE status = 'published' ORDER BY created_at DESC LIMIT 3")->fetchAll();

// چرا: نمایش همه‌ی عکس‌های آپلودشده (تصویر شاخص + گالری) نمونه‌کارها و مقاله‌ها در صفحه اصلی
$galleryImages = db()->query("
    (SELECT p.image AS image, p.title AS title, p.created_at AS created_at, 'portfolio' AS src, 'نمونه‌کار' AS label FROM portfolio p WHERE p.image IS NOT NULL)
    UNION ALL
    (SELECT pi.image AS image, p.title AS title, pi.created_at AS created_at, 'portfolio' AS src, 'نمونه‌کار' AS label FROM portfolio_images pi JOIN portfolio p ON p.id = pi.portfolio_id)
    UNION ALL
    (SELECT a.image AS image, a.title AS title, a.created_at AS created_at, 'articles' AS src, 'مقاله' AS label FROM articles a WHERE a.image IS NOT NULL AND a.status = 'published')
    UNION ALL
    (SELECT ai.image AS image, a.title AS title, ai.created_at AS created_at, 'articles' AS src, 'مقاله' AS label FROM article_images ai JOIN articles a ON a.id = ai.article_id WHERE a.status = 'published')
    ORDER BY created_at DESC LIMIT 16
")->fetchAll();

$events    = db()->prepare('SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 6');
$events->execute();
$events    = $events->fetchAll();

// داده‌های کادر تقویم واقعی — دقیقاً همون منطقِ ویجت تقویمِ داشبورد پنل ادمین
$eventDates     = array_column($events, 'event_date');
$dow            = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
$daysInMonth    = (int) date('t');
$today          = (int) date('j');
$firstDayOfWeek = (int) date('N', strtotime(date('Y-m-01')));
?>

<section class="hero page-head">
  <div class="hero-orb" style="width:260px;height:260px;background:radial-gradient(circle,rgba(139,92,246,0.53),transparent 70%);top:-60px;right:5%;"></div>
  <div class="hero-orb" style="width:220px;height:220px;background:radial-gradient(circle,rgba(59,130,246,0.48),transparent 70%);bottom:-40px;left:8%;"></div>
  <div class="wrap">
    <h1 class="stagger-item"><?php editable('home_hero_title', 'ما برای کسب‌وکار شما رشد طراحی می‌کنیم'); ?></h1>
    <p class="stagger-item"><?php editable('home_hero_subtitle', 'از طراحی وب‌سایت اختصاصی تا سئو، برندینگ و توسعه؛ هر آنچه برای رشد دیجیتال نیاز دارید، یک‌جا.'); ?></p>
    <div class="hero-actions stagger-item">
      <a href="contact.php" class="btn btn-primary" style="width:auto;"><i class="fa-solid fa-comments"></i> درخواست مشاوره رایگان</a>
      <a href="portfolio.php" class="btn btn-outline" style="width:auto;">مشاهده نمونه‌کارها</a>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head">
      <h2><?php editable('home_services_title', 'خدمات ما'); ?></h2>
      <p><?php editable('home_services_subtitle', 'چیزهایی که واقعاً برای رشد آنلاین کسب‌وکار شما لازم است'); ?></p>
    </div>
    <div class="grid grid-3">
      <?php if ($services): foreach ($services as $s): ?>
      <div class="card glass service-card stagger-item">
        <div class="ic"><i class="<?= htmlspecialchars($s['icon'] ?: 'fa-solid fa-globe') ?>"></i></div>
        <h3><?= htmlspecialchars($s['title']) ?></h3>
        <p><?= htmlspecialchars($s['description'] ?? '') ?></p>
      </div>
      <?php endforeach; else: ?>
      <!-- TODO: هنوز خدمتی توی پنل ادمین ثبت نشده — از بخش «خدمات» پنل ادمین اضافه کنید -->
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-globe"></i></div><h3>طراحی سایت</h3><p>طراحی و توسعه‌ی وب‌سایت‌های حرفه‌ای و ریسپانسیو</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-gauge"></i></div><h3>پنل مدیریت اختصاصی</h3><p>ساخت داشبورد و پنل مدیریت متناسب با نیاز کسب‌وکار</p></div>
      <div class="card glass service-card stagger-item"><div class="ic"><i class="fa-solid fa-magnifying-glass-chart"></i></div><h3>سئوی فنی</h3><p>بهینه‌سازی سایت برای رتبه‌ی بهتر در گوگل</p></div>
      <?php endif; ?>
    </div>
    <div class="stagger-item" style="text-align:center; margin-top:32px;">
      <a href="services.php" class="btn btn-outline" style="width:auto;">مشاهده همه خدمات</a>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head">
      <h2><?php editable('home_portfolio_title', 'نمونه‌کارهای اخیر'); ?></h2>
      <p><?php editable('home_portfolio_subtitle', 'گوشه‌ای از پروژه‌هایی که برای مشتریانمان ساختیم'); ?></p>
    </div>
    <div class="grid grid-3">
      <?php if ($portfolio): foreach ($portfolio as $p): ?>
      <div class="card glass tile-card stagger-item">
        <img loading="lazy" decoding="async" src="<?= htmlspecialchars(image_url($p['image'] ?? null, 'portfolio')) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
        <div class="tile-body">
          <?php if (!empty($p['category'])): ?><span class="tag-pill"><?= htmlspecialchars($p['category']) ?></span><?php endif; ?>
          <h3><?= htmlspecialchars($p['title']) ?></h3>
        </div>
      </div>
      <?php endforeach; else: ?>
      <p class="empty-note">به‌زودی نمونه‌کارها اینجا نمایش داده می‌شوند — از پنل ادمین اضافه کنید.</p>
      <?php endif; ?>
    </div>
    <div class="stagger-item" style="text-align:center; margin-top:32px;">
      <a href="portfolio.php" class="btn btn-outline" style="width:auto;">مشاهده همه نمونه‌کارها</a>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head">
      <h2><?php editable('home_articles_title', 'آخرین مقالات'); ?></h2>
      <p><?php editable('home_articles_subtitle', 'نکته‌ها و راهنماهای تیم Nononik درباره‌ی وب و رشد آنلاین'); ?></p>
    </div>
    <div class="grid grid-3">
      <?php if ($articles): foreach ($articles as $a): ?>
      <div class="card glass tile-card stagger-item">
        <img loading="lazy" decoding="async" src="<?= htmlspecialchars(image_url($a['image'] ?? null, 'articles')) ?>" alt="<?= htmlspecialchars($a['title']) ?>">
        <div class="tile-body">
          <div class="meta"><i class="fa-regular fa-user"></i> <?= htmlspecialchars($a['author'] ?? 'Admin') ?> &middot; <?= time_ago($a['created_at']) ?></div>
          <h3><?= htmlspecialchars($a['title']) ?></h3>
          <p><?= htmlspecialchars(mb_substr(strip_tags($a['content'] ?? ''), 0, 110)) ?>…</p>
        </div>
      </div>
      <?php endforeach; else: ?>
      <p class="empty-note">هنوز مقاله‌ای منتشر نشده — از پنل ادمین اضافه کنید.</p>
      <?php endif; ?>
    </div>
    <div class="stagger-item" style="text-align:center; margin-top:32px;">
      <a href="blog.php" class="btn btn-outline" style="width:auto;">مشاهده همه مقالات</a>
    </div>
  </div>
</section>

<?php if ($galleryImages): ?>
<section class="section">
  <div class="wrap">
    <div class="section-head">
      <h2><?php editable('home_gallery_title', 'همه‌ی عکس‌های نمونه‌کارها و مقالات'); ?></h2>
      <p><?php editable('home_gallery_subtitle', 'مجموعه‌ای از تصاویر آپلودشده در بخش نمونه‌کارها و مقالات'); ?></p>
    </div>
    <div class="home-gallery-grid">
      <?php foreach ($galleryImages as $g): $gUrl = image_url($g['image'], $g['src']); ?>
      <a href="<?= htmlspecialchars($gUrl) ?>" class="home-gallery-item stagger-item" data-lightbox data-title="<?= htmlspecialchars($g['title']) ?>">
        <img loading="lazy" decoding="async" src="<?= htmlspecialchars($gUrl) ?>" alt="<?= htmlspecialchars($g['title']) ?>">
        <span class="home-gallery-tag"><?= htmlspecialchars($g['label']) ?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<div class="home-lightbox" id="homeLightbox" hidden>
  <button type="button" class="home-lightbox-close" id="homeLightboxClose" aria-label="بستن"><i class="fa-solid fa-xmark"></i></button>
  <img id="homeLightboxImg" src="" alt="">
  <span class="home-lightbox-title" id="homeLightboxTitle"></span>
</div>
<style>
.home-gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;}
.home-gallery-item{position:relative;display:block;border-radius:14px;overflow:hidden;aspect-ratio:1/1;}
.home-gallery-item img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .35s ease;}
.home-gallery-item:hover img{transform:scale(1.06);}
.home-gallery-tag{position:absolute;bottom:8px;inset-inline-start:8px;background:rgba(0,0,0,.55);color:#fff;font-size:11px;padding:3px 9px;border-radius:999px;}
.home-lightbox{position:fixed;inset:0;background:rgba(8,6,20,.9);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;}
.home-lightbox[hidden]{display:none;}
.home-lightbox img{max-width:min(90vw,900px);max-height:80vh;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.5);}
.home-lightbox-title{color:#fff;font-size:14px;}
.home-lightbox-close{position:absolute;top:20px;left:20px;background:rgba(255,255,255,.12);border:none;color:#fff;width:42px;height:42px;border-radius:50%;font-size:18px;cursor:pointer;}
</style>
<script>
(function () {
  var lb = document.getElementById('homeLightbox');
  if (!lb) return;
  var img = document.getElementById('homeLightboxImg');
  var title = document.getElementById('homeLightboxTitle');
  document.querySelectorAll('[data-lightbox]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      img.src = a.getAttribute('href');
      title.textContent = a.getAttribute('data-title') || '';
      lb.hidden = false;
    });
  });
  document.getElementById('homeLightboxClose').addEventListener('click', function () { lb.hidden = true; });
  lb.addEventListener('click', function (e) { if (e.target === lb) lb.hidden = true; });
})();
</script>
<?php endif; ?>

<section class="section">
  <div class="wrap">
    <div class="section-head">
      <h2>رویدادها و تقویم</h2>
      <p>رویدادهای پیش‌رو و برنامه‌های تیم Nononic را اینجا دنبال کنید</p>
    </div>
    <div class="grid cal-layout" style="max-width:900px; margin:0 auto;">

      <!-- کادر خودِ تقویم (همون ویجت تقویم پنل ادمین) -->
      <div class="card glass">
        <div class="card-head">
          <h3>تقویم</h3>
          <span style="font-size:12px;color:var(--text-2)"><?= date('F Y') ?></span>
        </div>
        <div class="mini-cal-grid">
          <?php foreach ($dow as $d): ?><span class="dow"><?= $d ?></span><?php endforeach; ?>
          <?php
          $offset = $firstDayOfWeek % 7;
          for ($i = 0; $i < $offset; $i++) echo '<span></span>';
          for ($d = 1; $d <= $daysInMonth; $d++):
              $dateStr = date('Y-m-') . str_pad((string) $d, 2, '0', STR_PAD_LEFT);
              $hasEvent = in_array($dateStr, $eventDates, true);
              $cls = ($d === $today ? 'today ' : '') . ($hasEvent ? 'has-event' : '');
          ?>
          <div class="day <?= $cls ?>"><?= $d ?></div>
          <?php endfor; ?>
        </div>
      </div>

      <!-- لیست رویدادهای پیش‌رو -->
      <div class="card glass events-list" style="padding:20px;">
        <?php if ($events): foreach ($events as $ev): ?>
        <div class="event-row glass">
          <div class="date-box" style="background:<?= htmlspecialchars($ev['color']) ?>">
            <span style="font-size:17px;"><?= date('d', strtotime($ev['event_date'])) ?></span>
            <span style="font-size:10px;opacity:.85;"><?= date('M', strtotime($ev['event_date'])) ?></span>
          </div>
          <div style="flex:1">
            <b style="font-size:14px;"><?= htmlspecialchars($ev['title']) ?></b>
            <p style="font-size:12.5px;color:var(--text-2);margin-top:4px;">
              <?= htmlspecialchars($ev['event_date']) ?><?= $ev['event_time'] ? ' — ' . htmlspecialchars($ev['event_time']) : '' ?>
              <?php if ($ev['description']): ?> · <?= htmlspecialchars($ev['description']) ?><?php endif; ?>
            </p>
          </div>
        </div>
        <?php endforeach; else: ?>
        <p class="empty-note">رویداد پیش‌روی ثبت‌شده‌ای وجود ندارد.</p>
        <?php endif; ?>
      </div>

    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="cta-band">
      <h2>آماده‌اید کسب‌وکارتان را آنلاین کنید؟</h2>
      <a href="contact.php" class="btn btn-primary" style="width:auto;">شروع همکاری</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
