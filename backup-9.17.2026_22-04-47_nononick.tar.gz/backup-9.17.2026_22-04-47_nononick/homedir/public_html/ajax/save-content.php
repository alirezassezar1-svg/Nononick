<?php
/**
 * Nononik — Live Text Editor: Save Endpoint
 * چرا: فقط ادمین لاگین‌شده (همون سشن پنل مدیریت) اجازه‌ی ذخیره داره؛
 * ورودی حتماً باید CSRF token معتبر داشته باشه و متن قبل از ذخیره
 * strip_tags می‌شه تا این ویرایشگر صرفاً «متن» رو تغییر بده، نه HTML/اسکریپت دلخواه.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/security.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

apply_security_headers();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['admin_id'])) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method_not_allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
    http_response_code(419);
    echo json_encode(['ok' => false, 'error' => 'csrf'], JSON_UNESCAPED_UNICODE);
    exit;
}

$key = trim((string) ($_POST['key'] ?? ''));
if ($key === '' || !preg_match('/^[a-z0-9_\-]{1,100}$/i', $key)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'invalid_key'], JSON_UNESCAPED_UNICODE);
    exit;
}

// فقط متن خام؛ هیچ تگ HTML/اسکریپتی مجاز نیست
$value = strip_tags((string) ($_POST['value'] ?? ''));
$value = trim(preg_replace('/\s+/u', ' ', $value));
$value = mb_substr($value, 0, 2000);

try {
    $stmt = db()->prepare(
        'INSERT INTO page_content (block_key, content) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE content = VALUES(content), updated_at = NOW()'
    );
    $stmt->execute([$key, $value]);
    security_log('page_content_save', "key={$key}");
    echo json_encode(['ok' => true, 'value' => $value], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'db_error'], JSON_UNESCAPED_UNICODE);
}
