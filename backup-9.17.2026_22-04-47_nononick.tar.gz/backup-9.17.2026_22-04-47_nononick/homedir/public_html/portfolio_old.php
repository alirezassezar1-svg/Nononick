<?php
$pageTitle = 'نمونه‌کارها | Nononik';
$pageDescription = 'نمونه پروژه‌های طراحی وب انجام‌شده توسط آژانس Nononik.';
require_once __DIR__ . '/includes/site-header.php';

$portfolio = db()->query('SELECT * FROM portfolio ORDER BY created_at DESC')->fetchAll();
?>
<section class="hero page-head" style="padding:80px 0 50px;">
  <div class="hero-orb" style="width:220px;height:220px;background:radial-gradient(circle,rgba(59,130,246,0.48),transparent 70%);top:-40px;right:10%;"></div>
  <div class="wrap">
    <span class="hero-badge stagger-item"><i class="fa-solid fa-briefcase"></i> نمونه‌کارها</span>
    <h1 class="stagger-item">گوشه‌ای از پروژه‌هایی که ساختیم</h1>
    <p class="stagger-item">نمونه‌ای از همکاری ما با کسب‌وکارهای مختلف — از فروشگاه آنلاین تا پنل‌های اختصاصی.</p>
  </div>
</section>

<section class="section" style="padding-top:20px;">
  <div class="wrap">
    <div class="grid grid-3">
      <?php if ($portfolio): foreach ($portfolio as $p): ?>
      <div class="card glass tile-card stagger-item">
        <img loading="lazy" decoding="async" src="<?= htmlspecialchars(image_url($p['image'] ?? null, 'portfolio')) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
        <div class="tile-body">
          <?php if (!empty($p['category'])): ?><span class="tag-pill"><?= htmlspecialchars($p['category']) ?></span><?php endif; ?>
          <h3><?= htmlspecialchars($p['title']) ?></h3>
          <?php if (!empty($p['description'])): ?><p><?= htmlspecialchars($p['description']) ?></p><?php endif; ?>
          <?php if (!empty($p['link'])): ?>
          <a href="<?= htmlspecialchars($p['link']) ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm" style="width:auto;display:inline-flex;margin-top:14px;">
            مشاهده پروژه <i class="fa-solid fa-arrow-up-left"></i>
          </a>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; else: ?>
      <!-- TODO: از پنل ادمین → «نمونه‌کارها» پروژه‌های واقعی رو اضافه کنید -->
      <p class="empty-note">هنوز نمونه‌کاری ثبت نشده — از پنل ادمین اضافه کنید.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
