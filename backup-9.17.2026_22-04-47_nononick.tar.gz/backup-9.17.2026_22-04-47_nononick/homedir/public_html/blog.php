<?php
$pageTitle = 'مقالات | Nononik';
$pageDescription = 'مقالات و راهنماهای آژانس طراحی وب Nononik درباره‌ی وب، طراحی و سئو.';
require_once __DIR__ . '/includes/site-header.php';

$articles = db()->query("SELECT * FROM articles WHERE status = 'published' ORDER BY created_at DESC")->fetchAll();
?>
<section class="hero page-head" style="padding:80px 0 50px;">
  <div class="hero-orb" style="width:220px;height:220px;background:radial-gradient(circle,rgba(236,72,153,0.40),transparent 70%);top:-30px;left:8%;"></div>
  <div class="wrap">
    <span class="hero-badge stagger-item"><i class="fa-solid fa-newspaper"></i> مقالات</span>
    <h1 class="stagger-item">نکته‌ها و راهنماهایی درباره‌ی وب و رشد آنلاین</h1>
    <p class="stagger-item">تجربه‌ی تیم Nononik در طراحی، توسعه و سئوی وب‌سایت — به زبان ساده.</p>
  </div>
</section>

<section class="section" style="padding-top:20px;">
  <div class="wrap">
    <div class="grid grid-3">
      <?php if ($articles): foreach ($articles as $a): ?>
      <a href="blog-single.php?slug=<?= urlencode($a['slug']) ?>" class="card glass tile-card stagger-item" style="display:block;text-decoration:none;color:inherit;">
        <img loading="lazy" decoding="async" src="<?= htmlspecialchars(image_url($a['image'] ?? null, 'articles')) ?>" alt="<?= htmlspecialchars($a['title']) ?>">
        <div class="tile-body">
          <div class="meta"><i class="fa-regular fa-user"></i> <?= htmlspecialchars($a['author'] ?? 'Admin') ?> &middot; <?= time_ago($a['created_at']) ?></div>
          <h3><?= htmlspecialchars($a['title']) ?></h3>
          <p><?= htmlspecialchars(mb_substr(strip_tags($a['content'] ?? ''), 0, 110)) ?>…</p>
        </div>
      </a>
      <?php endforeach; else: ?>
      <!-- TODO: از پنل ادمین → «مقالات» یه مقاله بنویسید و منتشرش کنید تا اینجا نمایش داده بشه -->
      <p class="empty-note">هنوز مقاله‌ای منتشر نشده — از پنل ادمین اضافه کنید.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/site-footer.php'; ?>
