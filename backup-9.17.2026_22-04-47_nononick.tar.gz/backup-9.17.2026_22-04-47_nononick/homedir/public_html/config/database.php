<?php
/**
 * Nononik
 * Database connection (PDO / MySQL)
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'nononick_sun_panel_db');
define('DB_USER', 'nononick_admin');
define('DB_PASS', 'alireza2787541374110$');
define('DB_CHARSET', 'utf8mb4');

define('BASE_URL', '/'); // change if the app lives in a different sub-folder
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . 'uploads/');

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die('خطا در اتصال به پایگاه داده: ' . htmlspecialchars($e->getMessage()));
        }
    }
    return $pdo;
}
