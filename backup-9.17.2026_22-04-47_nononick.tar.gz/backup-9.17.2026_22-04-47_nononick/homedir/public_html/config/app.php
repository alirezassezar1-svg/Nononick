<?php
/**
 * Nononik — Application Configuration
 * Core settings and initialization
 */

// ============ ENVIRONMENT ============

define('APP_NAME', 'Nononik');
define('APP_VERSION', '2.0.0');
define('APP_ENV', getenv('APP_ENV') ?: 'production');
define('APP_DEBUG', APP_ENV === 'development');

// ============ ERROR HANDLING ============

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Custom error handler
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) {
        return false;
    }

    // Log error
    error_log("[{$errno}] {$errstr} in {$errfile}:{$errline}", 0);

    if (APP_DEBUG) {
        echo "<pre style='color:red;'>Error: {$errstr} in {$errfile}:{$errline}</pre>";
    }

    return true;
});

// Custom exception handler
set_exception_handler(function (Throwable $exception) {
    error_log($exception);

    if (APP_DEBUG) {
        echo "<pre style='color:red;'>" . $exception . "</pre>";
    } else {
        echo "<p>An error occurred. Please try again later.</p>";
    }
});

// ============ SESSION ============

// Session configuration
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.cookie_secure', !APP_DEBUG); // HTTPS only in production

session_start();

// Regenerate session ID periodically
if (!isset($_SESSION['_last_regenerate'])) {
    $_SESSION['_last_regenerate'] = time();
} elseif (time() - $_SESSION['_last_regenerate'] > 3600) { // Hourly
    session_regenerate_id(true);
    $_SESSION['_last_regenerate'] = time();
}

// ============ SECURITY HEADERS ============

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Content Security Policy
$csp = "default-src 'self'; "
     . "script-src 'self' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; "
     . "style-src 'self' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net 'unsafe-inline'; "
     . "img-src 'self' data: https:; "
     . "font-src 'self' https://cdn.jsdelivr.net data:; "
     . "connect-src 'self'; "
     . "frame-ancestors 'none'; ";

header("Content-Security-Policy: {$csp}");

// ============ PATHS ============

define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('LOGS_PATH', ROOT_PATH . '/logs');

// ============ URL ============

$base_url = getenv('BASE_URL');
if (!$base_url) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script_path = dirname($_SERVER['SCRIPT_NAME']);
    $base_url = "{$scheme}://{$host}{$script_path}/";
}

define('BASE_URL', $base_url);

// ============ CORS & AJAX ============

header('Access-Control-Allow-Credentials: true');

// Allow AJAX from same origin
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_HOST']);
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token');

    // Handle preflight
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

// ============ TIMEZONE ============

date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'Asia/Tehran');

// ============ LOCALE ============

setlocale(LC_ALL, 'fa_IR.UTF-8', 'fa_IR', 'fa', 'C.UTF-8');
