<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('admins.view');
$pageTitle = 'مدیران';

$allRoles = db()->query('SELECT * FROM roles ORDER BY id ASC')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        require_permission('admins.manage');
        $id = (int) ($_POST['id'] ?? 0);
        $fullName = trim($_POST['full_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $roleIds = array_map('intval', $_POST['roles'] ?? []);

        if ($fullName === '' || $username === '' || $email === '') {
            set_flash('error', 'نام، نام‌کاربری و ایمیل الزامی است.');
            redirect('admins.php');
        }

        $oldAvatar = null;
        if ($id) {
            $stmt = db()->prepare('SELECT avatar FROM admins WHERE id = ?');
            $stmt->execute([$id]);
            $oldAvatar = $stmt->fetchColumn();
        }
        $avatar = upload_image($_FILES['avatar'] ?? [], 'users', $oldAvatar ?: null);

        if ($id) {
            if ($password !== '') {
                $stmt = db()->prepare('UPDATE admins SET full_name=?, username=?, email=?, avatar=?, password=? WHERE id=?');
                $stmt->execute([$fullName, $username, $email, $avatar, password_hash($password, PASSWORD_BCRYPT), $id]);
            } else {
                $stmt = db()->prepare('UPDATE admins SET full_name=?, username=?, email=?, avatar=? WHERE id=?');
                $stmt->execute([$fullName, $username, $email, $avatar, $id]);
            }
        } else {
            if ($password === '') {
                set_flash('error', 'برای مدیر جدید، رمز عبور الزامی است.');
                redirect('admins.php');
            }
            $stmt = db()->prepare('INSERT INTO admins (full_name, username, email, password, avatar) VALUES (?,?,?,?,?)');
            $stmt->execute([$fullName, $username, $email, password_hash($password, PASSWORD_BCRYPT), $avatar]);
            $id = (int) db()->lastInsertId();
        }

        // به‌روزرسانی نقش‌ها
        db()->prepare('DELETE FROM admin_roles WHERE admin_id = ?')->execute([$id]);
        if ($roleIds) {
            $ins = db()->prepare('INSERT INTO admin_roles (admin_id, role_id) VALUES (?, ?)');
            foreach ($roleIds as $rid) $ins->execute([$id, $rid]);
        }

        set_flash('success', 'اطلاعات مدیر ذخیره شد.');
        redirect('admins.php');
    }

    if ($action === 'delete') {
        require_permission('admins.manage');
        $id = (int) ($_POST['id'] ?? 0);
        // چرا: جلوگیری از حذف حساب خودِ کاربر جاری (خطر قفل‌شدن دسترسی)
        if ($id === (int) $_SESSION['admin_id']) {
            set_flash('error', 'نمی‌توانید حساب خودتان را حذف کنید.');
            redirect('admins.php');
        }
        db()->prepare('DELETE FROM admins WHERE id = ?')->execute([$id]);
        set_flash('success', 'مدیر حذف شد.');
        redirect('admins.php');
    }
}

$admins = db()->query('SELECT * FROM admins ORDER BY id ASC')->fetchAll();
$adminRolesMap = [];
$rows = db()->query('SELECT admin_id, role_id FROM admin_roles')->fetchAll();
foreach ($rows as $r) { $adminRolesMap[$r['admin_id']][] = (int) $r['role_id']; }

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>

        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>مدیریت مدیران</h2><p class="breadcrumb">داشبورد <b>/ مدیران</b></p></div>
                <?php if (can('admins.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openAdminModal()"><i class="fa-solid fa-plus"></i> مدیر جدید</button>
                <?php endif; ?>
            </div>

            <div class="table-card glass">
                <table class="data-table">
                    <thead><tr><th>مدیر</th><th>نام‌کاربری</th><th>ایمیل</th><th>نقش‌ها</th><th>آخرین ورود</th><th>عملیات</th></tr></thead>
                    <tbody>
                        <?php foreach ($admins as $a):
                            $rIds = $adminRolesMap[$a['id']] ?? [];
                            $rNames = array_map(fn($r) => $r['name'], array_filter($allRoles, fn($r) => in_array((int)$r['id'], $rIds, true)));
                        ?>
                        <tr>
                            <td style="display:flex;align-items:center;gap:10px;">
                                <img loading="lazy" decoding="async" class="row-thumb" style="border-radius:50%" src="<?= e(image_url($a['avatar'], 'users')) ?>" alt="">
                                <b><?= e($a['full_name']) ?></b>
                            </td>
                            <td><?= e($a['username']) ?></td>
                            <td><?= e($a['email']) ?></td>
                            <td><?= $rNames ? e(implode('، ', $rNames)) : '<span style="color:var(--text-2)">بدون نقش</span>' ?></td>
                            <td><?= $a['last_login'] ? time_ago($a['last_login']) : '—' ?></td>
                            <td class="actions-cell">
                                <?php if (can('admins.manage')): ?>
                                <button class="btn-icon btn-sm" onclick='openAdminModal(<?= json_encode($a, JSON_UNESCAPED_UNICODE) ?>, <?= json_encode($rIds) ?>)'><i class="fa-solid fa-pen"></i></button>
                                <?php if ((int)$a['id'] !== (int)$_SESSION['admin_id']): ?>
                                <form method="post" onsubmit="return confirm('این مدیر حذف شود؟')">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                    <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if (can('admins.manage')): ?>
<div class="modal-overlay" id="aModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="amTitle">مدیر جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="am_id">
            <div class="form-group">
                <label>تصویر پروفایل</label>
                <img id="am_preview" class="current-image" style="border-radius:50%" src="<?= e(image_url(null, 'users')) ?>">
                <input type="file" name="avatar" class="form-control" accept="image/*" data-preview="#am_preview">
            </div>
            <div class="form-row">
                <div class="form-group"><label>نام کامل</label><input type="text" name="full_name" id="am_name" class="form-control" required></div>
                <div class="form-group"><label>نام‌کاربری</label><input type="text" name="username" id="am_username" class="form-control" required></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>ایمیل</label><input type="email" name="email" id="am_email" class="form-control" required></div>
                <div class="form-group"><label>رمز عبور <small style="color:var(--text-2)">(برای ویرایش، خالی بگذارید تا تغییر نکند)</small></label><input type="password" name="password" id="am_password" class="form-control"></div>
            </div>
            <div class="form-group">
                <label>نقش‌ها</label>
                <div class="checkbox-grid">
                    <?php foreach ($allRoles as $r): ?>
                    <label class="checkbox-pill">
                        <input type="checkbox" name="roles[]" value="<?= $r['id'] ?>" class="am-role-check">
                        <?= e($r['name']) ?>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAdminModal(data, roleIds) {
    document.getElementById('aModal').classList.add('show');
    document.querySelectorAll('.am-role-check').forEach(cb => cb.checked = false);
    if (data) {
        amTitle.textContent = 'ویرایش مدیر';
        am_id.value = data.id; am_name.value = data.full_name; am_username.value = data.username;
        am_email.value = data.email; am_password.value = '';
        am_preview.src = data.avatar ? '<?= UPLOAD_URL ?>users/' + data.avatar : '<?= e(image_url(null, "users")) ?>';
        (roleIds || []).forEach(id => {
            const cb = document.querySelector(`.am-role-check[value="${id}"]`);
            if (cb) cb.checked = true;
        });
    } else {
        amTitle.textContent = 'مدیر جدید';
        document.querySelector('#aModal form').reset();
        am_id.value = '';
        am_preview.src = '<?= e(image_url(null, "users")) ?>';
    }
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
