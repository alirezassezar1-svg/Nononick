<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('articles.view');
$pageTitle = 'مقالات';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // حذف AJAX یک تصویر گالری (بدون رفرش کل صفحه، همان الگوی tasks.php)
    if ($action === 'delete_image') {
        header('Content-Type: application/json');
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '') || !can('articles.edit')) {
            echo json_encode(['success' => false]);
            exit;
        }
        $imgId = (int) ($_POST['image_id'] ?? 0);
        $stmt = db()->prepare('SELECT image FROM article_images WHERE id = ?');
        $stmt->execute([$imgId]);
        if ($file = $stmt->fetchColumn()) {
            @unlink(UPLOAD_DIR . 'articles/' . $file);
            db()->prepare('DELETE FROM article_images WHERE id = ?')->execute([$imgId]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        exit;
    }

    // حذف AJAX یک فایل پیوست (همان الگوی delete_image، برای media_assets)
    if ($action === 'delete_asset') {
        header('Content-Type: application/json');
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '') || !can('articles.edit')) {
            echo json_encode(['success' => false]);
            exit;
        }
        $assetId = (int) ($_POST['asset_id'] ?? 0);
        $stmt = db()->prepare("SELECT file_name FROM media_assets WHERE id = ? AND module = 'article'");
        $stmt->execute([$assetId]);
        if ($file = $stmt->fetchColumn()) {
            @unlink(UPLOAD_DIR . 'articles/assets/' . $file);
            db()->prepare('DELETE FROM media_assets WHERE id = ?')->execute([$assetId]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        exit;
    }

    csrf_check();

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        require_permission($id ? 'articles.edit' : 'articles.create');
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $author = trim($_POST['author'] ?? 'Admin');
        $status = $_POST['status'] ?? 'draft';
        $slug = trim($_POST['slug'] ?? '') ?: strtolower(preg_replace('/\s+/', '-', $title));

        if ($title === '') { set_flash('error', 'عنوان مقاله الزامی است.'); redirect('articles.php'); }

        $oldImage = null;
        if ($id) {
            $stmt = db()->prepare('SELECT image FROM articles WHERE id = ?');
            $stmt->execute([$id]);
            $oldImage = $stmt->fetchColumn();
        }
        $image = upload_image($_FILES['image'] ?? [], 'articles', $oldImage ?: null);

        if ($id) {
            db()->prepare('UPDATE articles SET title=?, slug=?, content=?, image=?, author=?, status=? WHERE id=?')
                ->execute([$title, $slug, $content, $image, $author, $status, $id]);
            $articleId = $id;
            set_flash('success', 'مقاله ویرایش شد.');
        } else {
            db()->prepare('INSERT INTO articles (title, slug, content, image, author, status) VALUES (?,?,?,?,?,?)')
                ->execute([$title, $slug, $content, $image, $author, $status]);
            $articleId = (int) db()->lastInsertId();
            set_flash('success', 'مقاله جدید اضافه شد.');
        }

        // هرچند عکس که کاربر برای گالری انتخاب کرده باشد، همه ذخیره می‌شوند
        $galleryFiles = upload_gallery_images($_FILES['gallery'] ?? [], 'articles');
        if ($galleryFiles) {
            $stmt = db()->prepare('INSERT INTO article_images (article_id, image) VALUES (?, ?)');
            foreach ($galleryFiles as $file) {
                $stmt->execute([$articleId, $file]);
            }
        }

        // فایل‌های پیوست عمومی (HTML/GLB/GLTF/PDF/... — خروجی ابزار AI)
        if (!empty($_FILES['assets']['name'][0] ?? '')) {
            $stmt = db()->prepare(
                'INSERT INTO media_assets (module, item_id, file_name, original_name, ext, mime_type, size_bytes) VALUES (?,?,?,?,?,?,?)'
            );
            $count = count($_FILES['assets']['name']);
            for ($i = 0; $i < $count; $i++) {
                if (($_FILES['assets']['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
                $single = [
                    'name'     => $_FILES['assets']['name'][$i],
                    'tmp_name' => $_FILES['assets']['tmp_name'][$i] ?? '',
                    'error'    => $_FILES['assets']['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                    'size'     => $_FILES['assets']['size'][$i] ?? 0,
                ];
                $saved = upload_asset_file($single, 'articles');
                if ($saved) {
                    $stmt->execute(['article', $articleId, $saved['file_name'], $saved['original_name'], $saved['ext'], $saved['mime_type'], $saved['size_bytes']]);
                } else {
                    set_flash('error', 'فایل «' . e($single['name']) . '» رد شد (پسوند/حجم/نوع مجاز نیست).');
                }
            }
        }

        redirect('articles.php');
    }

    if ($action === 'delete') {
        require_permission('articles.delete');
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = db()->prepare('SELECT image FROM articles WHERE id = ?');
        $stmt->execute([$id]);
        if ($img = $stmt->fetchColumn()) @unlink(UPLOAD_DIR . 'articles/' . $img);

        // فایل‌های گالری هم از دیسک پاک شوند (ردیف‌های جدول با ON DELETE CASCADE خودکار حذف می‌شوند)
        $stmt = db()->prepare('SELECT image FROM article_images WHERE article_id = ?');
        $stmt->execute([$id]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $gimg) {
            @unlink(UPLOAD_DIR . 'articles/' . $gimg);
        }

        $stmt = db()->prepare("SELECT file_name FROM media_assets WHERE module='article' AND item_id = ?");
        $stmt->execute([$id]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $af) {
            @unlink(UPLOAD_DIR . 'articles/assets/' . $af);
        }
        db()->prepare("DELETE FROM media_assets WHERE module='article' AND item_id = ?")->execute([$id]);

        db()->prepare('DELETE FROM articles WHERE id = ?')->execute([$id]);
        set_flash('success', 'مقاله حذف شد.');
        redirect('articles.php');
    }
}

$articles = db()->query('SELECT * FROM articles ORDER BY created_at DESC')->fetchAll();

// گالری همه‌ی مقالات را یک‌جا می‌گیریم و بر اساس article_id گروه‌بندی می‌کنیم
$galleryByArticle = [];
$galleryRows = db()->query('SELECT id, article_id, image FROM article_images ORDER BY sort_order, id')->fetchAll();
foreach ($galleryRows as $g) {
    $galleryByArticle[$g['article_id']][] = ['id' => $g['id'], 'image' => $g['image']];
}
$assetsByArticle = [];
$assetRows = db()->query("SELECT * FROM media_assets WHERE module='article' ORDER BY created_at DESC")->fetchAll();
foreach ($assetRows as $ar) {
    $assetsByArticle[$ar['item_id']][] = $ar;
}

foreach ($articles as &$art) {
    $art['gallery'] = $galleryByArticle[$art['id']] ?? [];
    $art['assets']  = $assetsByArticle[$art['id']] ?? [];
}
unset($art);

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>مدیریت مقالات</h2><p class="breadcrumb">داشبورد <b>/ مقالات</b></p></div>
                <?php if (can('articles.create')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openModal()"><i class="fa-solid fa-plus"></i> مقاله جدید</button>
                <?php endif; ?>
            </div>

            <div class="table-card glass">
                <table class="data-table">
                    <thead><tr><th>تصویر</th><th>عنوان</th><th>نویسنده</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr></thead>
                    <tbody>
                        <?php foreach ($articles as $a): ?>
                        <tr>
                            <td><img loading="lazy" decoding="async" class="row-thumb" src="<?= e(image_url($a['image'], 'articles')) ?>" alt=""></td>
                            <td><b><?= e($a['title']) ?></b></td>
                            <td><?= e($a['author']) ?></td>
                            <td><span class="badge badge-<?= e($a['status']) ?>"><?= e(status_label($a['status'])) ?></span></td>
                            <td><?= time_ago($a['created_at']) ?></td>
                            <td class="actions-cell">
                                <?php if (can('articles.edit')): ?>
                                <button class="btn-icon btn-sm" onclick='openModal(<?= json_encode($a, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                                <?php endif; ?>
                                <?php if (can('articles.delete')): ?>
                                <form method="post" onsubmit="return confirm('حذف شود؟')">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                    <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($articles)): ?><tr><td colspan="6" style="text-align:center;color:var(--text-2);padding:30px">مقاله‌ای ثبت نشده است.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="aModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="mTitle">مقاله جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id">
            <div class="form-group">
                <label>تصویر شاخص</label>
                <img id="f_preview" class="current-image" src="<?= e(image_url(null, 'articles')) ?>">
                <input type="file" name="image" class="form-control" accept="image/*" data-preview="#f_preview">
            </div>
            <div class="form-group">
                <label>گالری تصاویر (هر تعداد عکس که بخواهید، هم‌زمان قابل انتخاب است)</label>
                <div class="gallery-preview" id="f_gallery_existing"></div>
                <input type="file" name="gallery[]" id="f_gallery" class="form-control" accept="image/*" multiple>
                <div class="gallery-preview" id="f_gallery_new"></div>
            </div>
            <div class="form-group">
                <label>فایل پیوست (HTML، GLB/GLTF، PDF، ZIP، ویدیو، JSON — خروجی ابزار AI هم اینجا آپلود می‌شود)</label>
                <div class="gallery-preview" id="f_assets_existing"></div>
                <input type="file" name="assets[]" id="f_assets" class="form-control" multiple accept=".html,.htm,.svg,.glb,.gltf,.pdf,.zip,.mp4,.webm,.json">
                <small style="color:var(--text-2)">حداکثر ۳۰ مگابایت برای هر فایل.</small>
            </div>
            <div class="form-group"><label>عنوان</label><input type="text" name="title" id="f_title" class="form-control" required></div>
            <div class="form-group"><label>متن مقاله</label><textarea name="content" id="f_content" class="form-control" style="min-height:140px"></textarea></div>
            <div class="form-row">
                <div class="form-group"><label>نویسنده</label><input type="text" name="author" id="f_author" class="form-control" value="Admin"></div>
                <div class="form-group">
                    <label>وضعیت</label>
                    <select name="status" id="f_status" class="form-control">
                        <option value="draft">پیش‌نویس</option>
                        <option value="published">منتشر شده</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
const GALLERY_BASE = '<?= UPLOAD_URL ?>articles/';

function renderExistingGallery(items) {
    const box = document.getElementById('f_gallery_existing');
    box.innerHTML = '';
    (items || []).forEach(img => {
        const wrap = document.createElement('div');
        wrap.className = 'gallery-thumb';
        wrap.innerHTML = `<img src="${GALLERY_BASE}${img.image}" alt="">
            <button type="button" class="gallery-thumb-remove" title="حذف عکس"><i class="fa-solid fa-xmark"></i></button>`;
        wrap.querySelector('.gallery-thumb-remove').addEventListener('click', () => deleteGalleryImage(img.id, wrap));
        box.appendChild(wrap);
    });
}

function deleteGalleryImage(imageId, el) {
    if (!confirm('این عکس از گالری حذف شود؟')) return;
    fetch('articles.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=delete_image&image_id=${encodeURIComponent(imageId)}&csrf_token=${encodeURIComponent('<?= csrf_token() ?>')}`
    }).then(r => r.json()).then(res => {
        if (res.success) el.remove();
    });
}

const ASSET_ICONS = { html:'fa-code', htm:'fa-code', svg:'fa-bezier-curve', glb:'fa-cube', gltf:'fa-cube', pdf:'fa-file-pdf', zip:'fa-file-zipper', mp4:'fa-file-video', webm:'fa-file-video', json:'fa-file-code' };

function renderExistingAssets(items) {
    const box = document.getElementById('f_assets_existing');
    box.innerHTML = '';
    (items || []).forEach(a => {
        const isEmbeddable = ['html','htm','svg'].includes(a.ext);
        const wrap = document.createElement('div');
        wrap.className = 'gallery-thumb';
        wrap.style.cssText = 'display:flex;align-items:center;gap:8px;padding:8px 10px;width:auto';
        wrap.innerHTML = `<i class="fa-solid ${ASSET_ICONS[a.ext] || 'fa-file'}"></i>
            <span style="font-size:12.5px">${a.original_name || a.file_name}</span>
            ${isEmbeddable
                ? `<a href="asset-embed.php?id=${a.id}" target="_blank" title="پیش‌نمایش" class="btn-icon btn-sm"><i class="fa-solid fa-eye"></i></a>`
                : `<a href="<?= UPLOAD_URL ?>articles/assets/${a.file_name}" target="_blank" title="دانلود" class="btn-icon btn-sm"><i class="fa-solid fa-download"></i></a>`}
            <button type="button" class="gallery-thumb-remove" title="حذف فایل"><i class="fa-solid fa-xmark"></i></button>`;
        wrap.querySelector('.gallery-thumb-remove').addEventListener('click', () => deleteAsset(a.id, wrap));
        box.appendChild(wrap);
    });
}

function deleteAsset(assetId, el) {
    if (!confirm('این فایل پیوست حذف شود؟')) return;
    fetch('articles.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=delete_asset&asset_id=${encodeURIComponent(assetId)}&csrf_token=${encodeURIComponent('<?= csrf_token() ?>')}`
    }).then(r => r.json()).then(res => {
        if (res.success) el.remove();
    });
}

// پیش‌نمایش عکس‌های تازه انتخاب‌شده (قبل از ارسال فرم)
document.getElementById('f_gallery').addEventListener('change', function () {
    const box = document.getElementById('f_gallery_new');
    box.innerHTML = '';
    Array.from(this.files).forEach(file => {
        const wrap = document.createElement('div');
        wrap.className = 'gallery-thumb';
        wrap.innerHTML = `<img src="${URL.createObjectURL(file)}" alt="">`;
        box.appendChild(wrap);
    });
});

function openModal(data) {
    document.getElementById('aModal').classList.add('show');
    document.getElementById('f_gallery_new').innerHTML = '';
    document.getElementById('f_gallery').value = '';
    document.getElementById('f_assets').value = '';
    if (data) {
        mTitle.textContent = 'ویرایش مقاله';
        f_id.value = data.id; f_title.value = data.title; f_content.value = data.content || '';
        f_author.value = data.author; f_status.value = data.status;
        f_preview.src = data.image ? '<?= UPLOAD_URL ?>articles/' + data.image : '<?= e(image_url(null, "articles")) ?>';
        renderExistingGallery(data.gallery);
        renderExistingAssets(data.assets);
    } else {
        mTitle.textContent = 'مقاله جدید';
        document.querySelector('#aModal form').reset(); f_id.value = '';
        f_preview.src = '<?= e(image_url(null, "articles")) ?>';
        renderExistingGallery([]);
        renderExistingAssets([]);
    }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
