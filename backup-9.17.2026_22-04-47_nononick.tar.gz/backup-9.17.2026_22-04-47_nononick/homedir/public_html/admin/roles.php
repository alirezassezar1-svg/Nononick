<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('roles.manage');
$pageTitle = 'نقش‌ها و دسترسی‌ها';

$allPermissions = db()->query('SELECT * FROM permissions ORDER BY `group` ASC, id ASC')->fetchAll();
$groupedPermissions = [];
foreach ($allPermissions as $p) { $groupedPermissions[$p['group']][] = $p; }

$groupLabels = [
    'dashboard' => 'داشبورد', 'projects' => 'پروژه‌ها', 'services' => 'خدمات',
    'portfolio' => 'نمونه‌کارها', 'articles' => 'مقالات', 'users' => 'کاربران',
    'admins' => 'مدیران', 'messages' => 'پیام‌ها', 'tasks' => 'وظایف',
    'events' => 'رویدادها', 'settings' => 'تنظیمات', 'roles' => 'نقش‌ها',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $permIds = array_map('intval', $_POST['permissions'] ?? []);

        if ($name === '' || $slug === '') {
            set_flash('error', 'نام و شناسه (slug) نقش الزامی است.');
            redirect('roles.php');
        }

        if ($id) {
            // چرا: نقش سیستمی «مدیر کل» تغییرناپذیر است تا همیشه حداقل یک نقش با دسترسی کامل وجود داشته باشد
            $isSystem = db()->prepare('SELECT is_system FROM roles WHERE id = ?');
            $isSystem->execute([$id]);
            if ((int) $isSystem->fetchColumn() === 1) {
                set_flash('error', 'نقش سیستمی «مدیر کل» قابل ویرایش نیست.');
                redirect('roles.php');
            }
            $stmt = db()->prepare('UPDATE roles SET name=?, slug=?, description=? WHERE id=?');
            $stmt->execute([$name, $slug, $desc, $id]);
        } else {
            $stmt = db()->prepare('INSERT INTO roles (name, slug, description) VALUES (?,?,?)');
            $stmt->execute([$name, $slug, $desc]);
            $id = (int) db()->lastInsertId();
        }

        db()->prepare('DELETE FROM role_permissions WHERE role_id = ?')->execute([$id]);
        if ($permIds) {
            $ins = db()->prepare('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)');
            foreach ($permIds as $pid) $ins->execute([$id, $pid]);
        }

        set_flash('success', 'نقش با موفقیت ذخیره شد.');
        redirect('roles.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $isSystem = db()->prepare('SELECT is_system FROM roles WHERE id = ?');
        $isSystem->execute([$id]);
        if ((int) $isSystem->fetchColumn() === 1) {
            set_flash('error', 'نقش سیستمی قابل حذف نیست.');
        } else {
            db()->prepare('DELETE FROM roles WHERE id = ?')->execute([$id]);
            set_flash('success', 'نقش حذف شد.');
        }
        redirect('roles.php');
    }
}

$roles = db()->query('SELECT * FROM roles ORDER BY id ASC')->fetchAll();
$rolePermMap = [];
$rp = db()->query('SELECT role_id, permission_id FROM role_permissions')->fetchAll();
foreach ($rp as $row) { $rolePermMap[$row['role_id']][] = (int) $row['permission_id']; }
$adminCountByRole = [];
$ac = db()->query('SELECT role_id, COUNT(*) c FROM admin_roles GROUP BY role_id')->fetchAll();
foreach ($ac as $row) { $adminCountByRole[$row['role_id']] = (int) $row['c']; }

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>

        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>نقش‌ها و دسترسی‌ها</h2><p class="breadcrumb">داشبورد <b>/ نقش‌ها</b></p></div>
                <button class="btn btn-primary" style="width:auto" onclick="openRoleModal()"><i class="fa-solid fa-plus"></i> نقش جدید</button>
            </div>

            <div class="table-card glass">
                <table class="data-table">
                    <thead><tr><th>نقش</th><th>شناسه</th><th>توضیحات</th><th>تعداد مدیران</th><th>عملیات</th></tr></thead>
                    <tbody>
                        <?php foreach ($roles as $r): ?>
                        <tr>
                            <td><b><?= e($r['name']) ?></b> <?php if ($r['is_system']): ?><span class="badge badge-active">سیستمی</span><?php endif; ?></td>
                            <td><code><?= e($r['slug']) ?></code></td>
                            <td><?= e($r['description']) ?></td>
                            <td><?= $adminCountByRole[$r['id']] ?? 0 ?> نفر</td>
                            <td class="actions-cell">
                                <?php if (!$r['is_system']): ?>
                                <button class="btn-icon btn-sm" onclick='openRoleModal(<?= json_encode($r, JSON_UNESCAPED_UNICODE) ?>, <?= json_encode($rolePermMap[$r['id']] ?? []) ?>)'><i class="fa-solid fa-pen"></i></button>
                                <form method="post" onsubmit="return confirm('این نقش حذف شود؟')">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                    <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                                </form>
                                <?php else: ?>
                                <span style="color:var(--text-2);font-size:12px">دسترسی کامل — غیرقابل ویرایش</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="rModal">
    <div class="modal-box modal-lg">
        <div class="modal-head"><h3 id="rmTitle">نقش جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="rm_id">
            <div class="form-row">
                <div class="form-group"><label>نام نقش</label><input type="text" name="name" id="rm_name" class="form-control" required></div>
                <div class="form-group"><label>شناسه (slug — انگلیسی)</label><input type="text" name="slug" id="rm_slug" class="form-control" required placeholder="مثال: editor"></div>
            </div>
            <div class="form-group">
                <label>توضیحات</label>
                <input type="text" name="description" id="rm_desc" class="form-control">
            </div>

            <div class="form-group">
                <label>دسترسی‌ها (بر اساس بخش)</label>
                <?php foreach ($groupedPermissions as $group => $perms): ?>
                <div class="perm-group">
                    <div class="perm-group-head">
                        <b><?= e($groupLabels[$group] ?? $group) ?></b>
                        <button type="button" class="link" onclick="toggleGroup(this, '<?= $group ?>')">انتخاب همه</button>
                    </div>
                    <div class="checkbox-grid">
                        <?php foreach ($perms as $p): ?>
                        <label class="checkbox-pill">
                            <input type="checkbox" name="permissions[]" value="<?= $p['id'] ?>" class="rm-perm-check" data-group="<?= $group ?>">
                            <?= e($p['name']) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره نقش</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleGroup(btn, group) {
    const boxes = document.querySelectorAll(`.rm-perm-check[data-group="${group}"]`);
    const allChecked = [...boxes].every(b => b.checked);
    boxes.forEach(b => b.checked = !allChecked);
}

function openRoleModal(data, permIds) {
    document.getElementById('rModal').classList.add('show');
    document.querySelectorAll('.rm-perm-check').forEach(cb => cb.checked = false);
    if (data) {
        rmTitle.textContent = 'ویرایش نقش';
        rm_id.value = data.id; rm_name.value = data.name; rm_slug.value = data.slug; rm_desc.value = data.description || '';
        (permIds || []).forEach(id => {
            const cb = document.querySelector(`.rm-perm-check[value="${id}"]`);
            if (cb) cb.checked = true;
        });
    } else {
        rmTitle.textContent = 'نقش جدید';
        document.querySelector('#rModal form').reset();
        rm_id.value = '';
    }
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
