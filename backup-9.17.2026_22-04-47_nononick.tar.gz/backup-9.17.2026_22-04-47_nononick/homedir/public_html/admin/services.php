<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('services.view');
$pageTitle = 'خدمات';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
        require_permission('services.manage');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $icon = trim($_POST['icon'] ?? 'fa-solid fa-globe');
        $desc = trim($_POST['description'] ?? '');
        $order = (int) ($_POST['sort_order'] ?? 0);

        if ($title === '') { set_flash('error', 'عنوان خدمت الزامی است.'); redirect('services.php'); }

        if ($id) {
            db()->prepare('UPDATE services SET title=?, icon=?, description=?, sort_order=? WHERE id=?')
                ->execute([$title, $icon, $desc, $order, $id]);
            set_flash('success', 'خدمت ویرایش شد.');
        } else {
            db()->prepare('INSERT INTO services (title, icon, description, sort_order) VALUES (?,?,?,?)')
                ->execute([$title, $icon, $desc, $order]);
            set_flash('success', 'خدمت جدید اضافه شد.');
        }
        redirect('services.php');
    }

    if ($action === 'delete') {
        db()->prepare('DELETE FROM services WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]);
        set_flash('success', 'خدمت حذف شد.');
        redirect('services.php');
    }
}

$services = db()->query('SELECT * FROM services ORDER BY sort_order ASC, id DESC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>مدیریت خدمات</h2><p class="breadcrumb">داشبورد <b>/ خدمات</b></p></div>
                <?php if (can('services.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openModal()"><i class="fa-solid fa-plus"></i> خدمت جدید</button>
                <?php endif; ?>
            </div>

            <div class="services-grid" style="grid-template-columns:repeat(4,1fr);">
                <?php foreach ($services as $s): ?>
                <div class="service-tile glass" style="text-align:right;position:relative;padding:20px;">
                    <div class="ic"><i class="<?= e($s['icon']) ?>"></i></div>
                    <b style="display:block;font-size:14px;margin-bottom:6px;"><?= e($s['title']) ?></b>
                    <small style="color:var(--text-2);font-size:11.5px;display:block;margin-bottom:14px;min-height:32px;"><?= e($s['description']) ?></small>
                    <div class="actions-cell">
                        <?php if (can('services.manage')): ?>
                        <button class="btn-icon btn-sm" onclick='openModal(<?= json_encode($s, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                        <?php endif; ?>
                        <?php if (can('services.manage')): ?>
                        <form method="post" onsubmit="return confirm('حذف شود؟')">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $s['id'] ?>">
                            <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="serviceModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="mTitle">خدمت جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id">
            <div class="form-group"><label>عنوان</label><input type="text" name="title" id="f_title" class="form-control" required></div>
            <div class="form-group">
                <label>آیکون (کلاس Font Awesome)</label>
                <input type="text" name="icon" id="f_icon" class="form-control" placeholder="fa-solid fa-globe">
            </div>
            <div class="form-group"><label>توضیح کوتاه</label><input type="text" name="description" id="f_desc" class="form-control"></div>
            <div class="form-group"><label>ترتیب نمایش</label><input type="number" name="sort_order" id="f_order" class="form-control" value="0"></div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(data) {
    document.getElementById('serviceModal').classList.add('show');
    if (data) {
        mTitle.textContent = 'ویرایش خدمت';
        f_id.value = data.id; f_title.value = data.title; f_icon.value = data.icon;
        f_desc.value = data.description || ''; f_order.value = data.sort_order;
    } else {
        mTitle.textContent = 'خدمت جدید';
        document.querySelector('#serviceModal form').reset(); f_id.value = '';
    }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
