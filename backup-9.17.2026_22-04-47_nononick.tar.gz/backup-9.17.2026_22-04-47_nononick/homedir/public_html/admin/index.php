<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('dashboard.view');

$pageTitle = 'داشبورد';

$totalProjects = db()->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$totalClients  = db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalRevenue  = db()->query("SELECT COALESCE(SUM(budget),0) FROM projects")->fetchColumn();
$totalVisits   = db()->query("SELECT COALESCE(SUM(visits),0) FROM site_visits")->fetchColumn();

$tasksToday = db()->query("SELECT * FROM tasks WHERE due_date = CURDATE() ORDER BY is_done ASC, id DESC")->fetchAll();
$doneCount  = count(array_filter($tasksToday, fn($t) => $t['is_done']));

$services = db()->query("SELECT * FROM services ORDER BY sort_order ASC LIMIT 6")->fetchAll();
$recentProjects = db()->query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 4")->fetchAll();
$visits = db()->query("SELECT visit_date, visits FROM site_visits ORDER BY visit_date ASC LIMIT 7")->fetchAll();
$activities = db()->query("SELECT * FROM activities ORDER BY created_at DESC LIMIT 3")->fetchAll();

$upcomingEvents = db()->query("SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 5")->fetchAll();
$eventDates = array_column($upcomingEvents, 'event_date');

$dow = ['ش','ی','د','س','چ','پ','ج'];
$daysInMonth = (int) date('t');
$today = (int) date('j');
$firstDayOfWeek = (int) date('N', strtotime(date('Y-m-01'))); // 1..7 (Mon..Sun) — approx grid start

$chartLabels = [];
$chartData = [];
$persianDows = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];
foreach ($visits as $i => $v) {
    $chartLabels[] = $persianDows[$i % 7];
    $chartData[] = (int) $v['visits'];
}

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>

        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>">
                    <i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?>
                </div>
            <?php endif; ?>

            <div class="page-head">
                <div>
                    <h2>خوش آمدید، <?= e($admin['full_name']) ?> 👋</h2>
                    <p class="breadcrumb">داشبورد <b>/ نمای کلی</b></p>
                </div>
            </div>

            <!-- STAT CARDS -->
            <div class="stats-grid">
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-folder-open"></i></div>
                    <div>
                        <div class="label">کل پروژه ها</div>
                        <div class="value"><?= (int)$totalProjects ?></div>
                        <div class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> ۱۲% نسبت به ماه قبل</div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-users"></i></div>
                    <div>
                        <div class="label">مشتریان</div>
                        <div class="value"><?= (int)$totalClients ?></div>
                        <div class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> ۹% نسبت به ماه قبل</div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-sack-dollar"></i></div>
                    <div>
                        <div class="label">درآمد کل</div>
                        <div class="value"><?= number_format($totalRevenue / 1000000, 1) ?>M</div>
                        <div class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> ۱۸% نسبت به ماه قبل</div>
                    </div>
                </div>
                <div class="stat-card glass">
                    <div class="icon"><i class="fa-solid fa-chart-line"></i></div>
                    <div>
                        <div class="label">بازدید وب سایت</div>
                        <div class="value"><?= number_format($totalVisits) ?></div>
                        <div class="trend up"><i class="fa-solid fa-arrow-trend-up"></i> ۲۲% نسبت به ماه قبل</div>
                    </div>
                </div>
            </div>

            <!-- WELCOME + CHART -->
            <div class="row">
                <div class="welcome-card glass">
                    <div class="txt">
                        <h2>خوش آمدید! <?= e($admin['full_name']) ?> 👋</h2>
                        <p>
                            شما امروز <b><?= count($tasksToday) ?></b> وظیفه دارید.
                            <?= (int)$totalProjects ?> پروژه در حال پیشرفت
                            و <?= (int)($unreadMessages ?? 0) ?> پیام جدید دارید.
                        </p>
                        <br>
                        <a href="projects.php" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-chart-simple"></i> مشاهده گزارش کامل</a>
                    </div>
                    <div class="visual">
                        <div class="orb" style="width:70px;height:70px;background:radial-gradient(circle,#8b5cf6,transparent);top:10px;right:10px;"></div>
                        <div class="orb" style="width:100px;height:100px;background:radial-gradient(circle,#3b82f6,transparent);bottom:0;left:10px;"></div>
                        <i class="fa-solid fa-laptop" style="font-size:70px;background:linear-gradient(135deg,#8b5cf6,#3b82f6);-webkit-background-clip:text;background-clip:text;color:transparent;position:absolute;bottom:30px;left:50%;transform:translateX(-50%);"></i>
                    </div>
                </div>

                <div class="card glass chart-card">
                    <div class="card-head">
                        <h3>گزارش بازدید</h3>
                        <div class="period-filter" id="periodFilter">
                            <button data-period="week" class="active">هفته</button>
                            <button data-period="month">ماه</button>
                            <button data-period="year">سال</button>
                        </div>
                    </div>
                    <canvas id="visitsChart" height="240"></canvas>
                </div>
            </div>

            <!-- ADVANCED: project status breakdown -->
            <div class="row" style="margin-top:18px;">
                <div class="card glass" style="max-width:320px;">
                    <div class="card-head"><h3>وضعیت پروژه‌ها</h3></div>
                    <canvas id="statusChart" height="220"></canvas>
                </div>
                <div class="card glass" style="flex:1;">
                    <div class="card-head"><h3>خلاصه ماهانه</h3></div>
                    <div class="empty-state" style="padding:24px 20px;">
                        <i class="fa-solid fa-chart-pie"></i>
                        <h4>مقایسه پیشرفته به‌زودی</h4>
                        <p>گزارش مقایسه‌ی درآمد و پروژه‌ها به تفکیک ماه، در فاز بعدی به این بخش اضافه می‌شود.</p>
                    </div>
                </div>
            </div>

            <!-- SERVICES + TASKS/CALENDAR -->
            <div class="row tri">
                <div class="card glass">
                    <div class="card-head">
                        <h3>خدمات پرکاربرد</h3>
                        <a href="services.php" class="link">مشاهده همه</a>
                    </div>
                    <div class="services-grid">
                        <?php foreach ($services as $s): ?>
                        <div class="service-tile">
                            <div class="ic"><i class="<?= e($s['icon']) ?>"></i></div>
                            <span><?= e($s['title']) ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card glass">
                    <div class="card-head">
                        <h3>وظایف امروز</h3>
                        <span style="font-size:12px;color:var(--text-2)"><?= $doneCount ?>/<?= count($tasksToday) ?></span>
                    </div>
                    <ul class="tasks-list">
                        <?php foreach ($tasksToday as $t): ?>
                        <li class="<?= $t['is_done'] ? 'done' : '' ?>">
                            <span class="task-check <?= $t['is_done'] ? 'done' : '' ?>" data-id="<?= $t['id'] ?>">
                                <?php if ($t['is_done']): ?><i class="fa-solid fa-check"></i><?php endif; ?>
                            </span>
                            <span><?= e($t['title']) ?></span>
                        </li>
                        <?php endforeach; ?>
                        <?php if (empty($tasksToday)): ?><li>وظیفه‌ای برای امروز ثبت نشده است.</li><?php endif; ?>
                    </ul>
                    <a href="tasks.php" class="link" style="display:block;margin-top:12px;font-size:12.5px;">مشاهده تمام وظایف <i class="fa-solid fa-arrow-left"></i></a>
                </div>

                <div class="card glass">
                    <div class="card-head">
                        <h3>تقویم</h3>
                        <span style="font-size:12px;color:var(--text-2)"><?= date('F Y') ?></span>
                    </div>
                    <div class="mini-cal-grid">
                        <?php foreach ($dow as $d): ?><span class="dow"><?= $d ?></span><?php endforeach; ?>
                        <?php
                        $offset = $firstDayOfWeek % 7; // blank cells before day 1
                        for ($i = 0; $i < $offset; $i++) echo '<span></span>';
                        for ($d = 1; $d <= $daysInMonth; $d++):
                            $dateStr = date('Y-m-') . str_pad($d, 2, '0', STR_PAD_LEFT);
                            $hasEvent = in_array($dateStr, $eventDates, true);
                            $cls = ($d === $today ? 'today ' : '') . ($hasEvent ? 'has-event' : '');
                        ?>
                        <div class="day <?= $cls ?>"><?= $d ?></div>
                        <?php endfor; ?>
                    </div>
                    <a href="events.php" class="btn btn-primary" style="margin-top:16px;"><i class="fa-solid fa-plus"></i> ایجاد رویداد جدید</a>
                </div>
            </div>

            <!-- RECENT PROJECTS -->
            <div class="card glass" style="margin-bottom:18px;">
                <div class="card-head">
                    <h3>پروژه های اخیر</h3>
                    <a href="projects.php" class="link">مشاهده همه</a>
                </div>
                <div class="projects-grid">
                    <?php foreach ($recentProjects as $p): ?>
                    <div class="project-tile glass">
                        <img loading="lazy" decoding="async" class="thumb" src="<?= e(image_url($p['image'], 'projects')) ?>" alt="">
                        <div class="info">
                            <b><?= e($p['title']) ?></b>
                            <small class="<?= $p['status'] === 'completed' ? 'green' : '' ?>"><?= e(status_label($p['status'])) ?></small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ACTIVITIES -->
            <div class="card glass" style="padding:16px;">
                <div class="card-head" style="margin-bottom:10px;"><h3>آخرین فعالیت ها</h3></div>
                <div class="activities-strip">
                    <?php foreach ($activities as $a): ?>
                    <div class="activity-item glass">
                        <div class="ic"><i class="<?= e($a['icon']) ?>"></i></div>
                        <div>
                            <b><?= e($a['title']) ?></b>
                            <small><?= e($a['description']) ?> · <?= time_ago($a['created_at']) ?></small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('visitsChart');
const visitsChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($chartLabels, JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{
            label: 'بازدید',
            data: <?= json_encode($chartData) ?>,
            borderRadius: 8,
            backgroundColor: (c) => {
                const g = c.chart.ctx.createLinearGradient(0,0,0,260);
                g.addColorStop(0,'#a855f7'); g.addColorStop(1,'#3b82f6');
                return g;
            },
            maxBarThickness: 42
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { display:false }, ticks: { color:'#8b85a8', font:{family:'Vazirmatn'} } },
            y: { grid: { color:'rgba(255,255,255,.06)' }, ticks: { color:'#8b85a8' } }
        }
    }
});

const statusChart = new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: ['در حال اجرا', 'تکمیل شده', 'در انتظار'],
        datasets: [{
            data: [0, 0, 0],
            backgroundColor: ['#8b5cf6', '#22c55e', '#f59e0b'],
            borderWidth: 0
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom', labels: { color: '#8b85a8', font: { family: 'Vazirmatn' } } } },
        cutout: '68%'
    }
});

// period filter — چرا: نمایش داشبورد پیشرفته با مقایسه بازه‌های زمانی مختلف
document.querySelectorAll('#periodFilter button').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#periodFilter button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        fetch(`dashboard-data.php?period=${btn.dataset.period}`)
            .then(r => r.json())
            .then(res => {
                visitsChart.data.labels = res.labels;
                visitsChart.data.datasets[0].data = res.data;
                visitsChart.update();
                statusChart.data.datasets[0].data = res.status.data;
                statusChart.update();
            });
    });
});

// بارگذاری اولیه‌ی نمودار وضعیت پروژه‌ها
fetch('dashboard-data.php?period=week').then(r => r.json()).then(res => {
    statusChart.data.datasets[0].data = res.status.data;
    statusChart.update();
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
