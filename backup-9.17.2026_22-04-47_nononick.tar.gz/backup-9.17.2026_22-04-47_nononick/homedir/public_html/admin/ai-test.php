<?php
/**
 * Nononik — تست اتصال به DeepSeek (فقط ادمین)
 *
 * چرا: قبل از وصل کردن کامل موتور تولید محتوا (پیش‌نویس، انتشار
 * خودکار و...)، این صفحه فقط یک درخواست ساده به DeepSeek می‌فرسته
 * تا مطمئن بشیم کلید API درست کار می‌کنه. بعد از تست موفق، این
 * فایل رو از سرور پاک کنید — دائمی نیست.
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/includes/DeepSeekClient.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prompt = trim($_POST['prompt'] ?? '');
    if ($prompt !== '') {
        $client = new DeepSeekClient(db());
        $result = $client->generateText(
            'تو یک دستیار محتوا برای آژانس طراحی وب‌سایت Nononik هستی. به فارسی، کوتاه و روان جواب بده.',
            $prompt
        );
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تست اتصال DeepSeek</title>
<style>
body{font-family:Tahoma,Arial,sans-serif;background:#111;color:#eee;padding:30px;max-width:700px;margin:auto;}
h2{margin-bottom:4px;}
p.note{color:#999;font-size:13px;margin-top:0;}
textarea{width:100%;height:100px;background:#1c1c1c;color:#eee;border:1px solid #333;border-radius:8px;padding:10px;box-sizing:border-box;}
button{margin-top:12px;padding:10px 22px;background:#7c3aed;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;}
button:hover{background:#6d28d9;}
.box{margin-top:24px;padding:16px;background:#1c1c1c;border-radius:8px;white-space:pre-wrap;line-height:1.9;}
.err{color:#f87171;font-weight:bold;}
.ok{color:#4ade80;font-weight:bold;}
</style>
</head>
<body>
<h2>تست اتصال به DeepSeek</h2>
<p class="note">این صفحه موقتیه — بعد از اطمینان از کارکرد درست، حذفش کنید.</p>

<form method="post">
  <textarea name="prompt" placeholder="مثلاً: یک کپشن اینستاگرام درباره طراحی سایت بنویس"><?= htmlspecialchars($_POST['prompt'] ?? '') ?></textarea>
  <br>
  <button type="submit">ارسال به DeepSeek</button>
</form>

<?php if ($result): ?>
  <div class="box">
    <?php if ($result['success']): ?>
      <p class="ok">✅ اتصال موفق بود</p>
      <p><?= nl2br(htmlspecialchars($result['content'])) ?></p>
    <?php else: ?>
      <p class="err">❌ خطا: <?= htmlspecialchars($result['error']) ?></p>
    <?php endif; ?>
  </div>
<?php endif; ?>
</body>
</html>
