<?php
/**
 * Nononik - Advanced Dashboard data endpoint
 * چرا: فیلتر زمانی نمودار بازدید (هفته/ماه/سال) بدون رفرش صفحه.
 */
require_once __DIR__ . '/includes/auth.php';
require_permission('dashboard.view');
header('Content-Type: application/json; charset=utf-8');

$period = $_GET['period'] ?? 'week';
$persianDows = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];

if ($period === 'year') {
    // ۱۲ ماه اخیر، جمع بازدید هر ماه
    $stmt = db()->query("
        SELECT DATE_FORMAT(visit_date, '%Y-%m') AS ym, SUM(visits) AS total
        FROM site_visits
        WHERE visit_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY ym ORDER BY ym ASC
    ");
    $rows = $stmt->fetchAll();
    $labels = array_map(fn($r) => $r['ym'], $rows);
    $data = array_map(fn($r) => (int) $r['total'], $rows);
} elseif ($period === 'month') {
    $stmt = db()->query("
        SELECT visit_date, visits FROM site_visits
        WHERE visit_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        ORDER BY visit_date ASC
    ");
    $rows = $stmt->fetchAll();
    $labels = array_map(fn($r) => date('j M', strtotime($r['visit_date'])), $rows);
    $data = array_map(fn($r) => (int) $r['visits'], $rows);
} else { // week
    $stmt = db()->query("SELECT visit_date, visits FROM site_visits ORDER BY visit_date DESC LIMIT 7");
    $rows = array_reverse($stmt->fetchAll());
    $labels = [];
    foreach ($rows as $i => $r) { $labels[] = $persianDows[$i % 7]; }
    $data = array_map(fn($r) => (int) $r['visits'], $rows);
}

// تفکیک وضعیت پروژه‌ها برای نمودار Doughnut
$statusStmt = db()->query("SELECT status, COUNT(*) AS c FROM projects GROUP BY status");
$statusRows = $statusStmt->fetchAll();
$statusMap = ['in_progress' => 0, 'completed' => 0, 'pending' => 0];
foreach ($statusRows as $r) {
    $statusMap[$r['status']] = (int) $r['c'];
}

echo json_encode([
    'labels' => $labels,
    'data' => $data,
    'status' => [
        'labels' => ['در حال اجرا', 'تکمیل شده', 'در انتظار'],
        'data' => array_values($statusMap),
    ],
], JSON_UNESCAPED_UNICODE);
