<?php
/**
 * Nononik - Verification & Testing Script
 * Phase 1-2 Integrity Check
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$base_path = __DIR__;

// ============================================
// ANSI Colors for Terminal
// ============================================
class Terminal {
    const GREEN = "\033[32m";
    const RED = "\033[31m";
    const YELLOW = "\033[33m";
    const BLUE = "\033[34m";
    const RESET = "\033[0m";
    const BOLD = "\033[1m";

    public static function success($msg) { echo self::GREEN . "✅ " . self::RESET . $msg . "\n"; }
    public static function error($msg) { echo self::RED . "❌ " . self::RESET . $msg . "\n"; }
    public static function warning($msg) { echo self::YELLOW . "⚠️  " . self::RESET . $msg . "\n"; }
    public static function info($msg) { echo self::BLUE . "ℹ️  " . self::RESET . $msg . "\n"; }
    public static function header($msg) { echo "\n" . self::BOLD . self::BLUE . "=== " . $msg . " ===" . self::RESET . "\n\n"; }
    public static function hr() { echo str_repeat("─", 50) . "\n"; }
}

// ============================================
// Test Functions
// ============================================

function test_file_exists($path, $name) {
    global $base_path;
    $full_path = $base_path . '/' . $path;
    if (file_exists($full_path)) {
        Terminal::success("$name موجود است");
        return true;
    } else {
        Terminal::error("$name موجود نیست: $path");
        return false;
    }
}

function test_file_readable($path, $name) {
    global $base_path;
    $full_path = $base_path . '/' . $path;
    if (is_readable($full_path)) {
        Terminal::success("$name قابل‌خواندگی است");
        return true;
    } else {
        Terminal::error("$name قابل‌خواندگی نیست: $path");
        return false;
    }
}

function test_file_size($path, $name, $min_bytes = 100) {
    global $base_path;
    $full_path = $base_path . '/' . $path;
    if (!file_exists($full_path)) {
        Terminal::error("$name موجود نیست");
        return false;
    }
    $size = filesize($full_path);
    if ($size > $min_bytes) {
        Terminal::success("$name ({$size} bytes)");
        return true;
    } else {
        Terminal::error("$name خالی یا کوچک‌تر از حد است ({$size} bytes)");
        return false;
    }
}

function test_php_syntax($path, $name) {
    global $base_path;
    $full_path = $base_path . '/' . $path;
    if (!file_exists($full_path)) return false;
    
    $output = shell_exec("php -l " . escapeshellarg($full_path) . " 2>&1");
    if (strpos($output, 'No syntax errors') !== false) {
        Terminal::success("$name - Syntax OK");
        return true;
    } else {
        Terminal::error("$name - Syntax Error: " . trim($output));
        return false;
    }
}

function test_css_validity($path, $name) {
    global $base_path;
    $full_path = $base_path . '/' . $path;
    if (!file_exists($full_path)) return false;
    
    $content = file_get_contents($full_path);
    
    // Basic checks
    $checks = [
        'باز و بسته شدگی brakets' => (substr_count($content, '{') === substr_count($content, '}')),
        'موجودیت selectors' => (preg_match('/(\.[\w-]+|#[\w-]+|\[)/', $content) > 0),
    ];
    
    $all_passed = true;
    foreach ($checks as $check => $passed) {
        if ($passed) {
            Terminal::success("$name - $check ✓");
        } else {
            Terminal::warning("$name - $check ✗");
            $all_passed = false;
        }
    }
    
    return $all_passed;
}

// ============================================
// START TESTING
// ============================================

echo Terminal::BOLD . Terminal::BLUE . "
╔════════════════════════════════════════════════════════════╗
║     Nononik - Phase 1-2 Verification & Testing          ║
║              تست یکپارچگی Nononik                      ║
╚════════════════════════════════════════════════════════════╝
" . Terminal::RESET . "\n";

$results = [];

// ============================================
// TEST 1: PHASE 1 - DESIGN SYSTEM
// ============================================
Terminal::header("PHASE 1: سیستم طراحی");

$phase1_files = [
    'assets/css/design-tokens.css' => 'Design Tokens',
    'assets/css/theme.css' => 'Theme (Glassmorphism)',
    'assets/css/motion.css' => 'Motion Animations',
    'assets/css/components.css' => 'Component Styles',
    'assets/css/command-palette.css' => 'Command Palette',
    'assets/js/motion.js' => 'GSAP Motion System',
    'assets/js/command-palette.js' => 'Command Palette Logic',
];

$phase1_pass = 0;
foreach ($phase1_files as $path => $name) {
    if (test_file_exists($path, $name) && test_file_readable($path, $name)) {
        if (strpos($path, '.css') !== false) {
            test_css_validity($path, $name);
        } elseif (strpos($path, '.js') !== false) {
            test_file_size($path, $name, 50);
        }
        $phase1_pass++;
    }
}

Terminal::hr();
Terminal::info("Phase 1: {$phase1_pass}/" . count($phase1_files) . " فایل OK");

// ============================================
// TEST 2: PHASE 2 - ARCHITECTURE
// ============================================
Terminal::header("PHASE 2: معماری تمیز");

$phase2_files = [
    'config/app.php' => 'App Configuration',
    'includes/Response.php' => 'API Response Formatter',
    'includes/Validator.php' => 'Validation Framework',
    'includes/Repository.php' => 'Repository Pattern',
    'includes/Service.php' => 'Service Layer',
];

$phase2_pass = 0;
foreach ($phase2_files as $path => $name) {
    if (test_file_exists($path, $name) && test_file_readable($path, $name)) {
        test_php_syntax($path, $name);
        test_file_size($path, $name, 100);
        $phase2_pass++;
    }
}

Terminal::hr();
Terminal::info("Phase 2: {$phase2_pass}/" . count($phase2_files) . " فایل OK");

// ============================================
// TEST 3: DOCUMENTATION
// ============================================
Terminal::header("مستندات");

$docs = [
    'DESIGN_SYSTEM.md' => 'Design System Guide',
    'PHASE2_ARCHITECTURE.md' => 'Architecture Guide',
    'ROADMAP.md' => 'Project Roadmap',
    'SETUP_GUIDE.md' => 'Setup Guide',
];

$docs_pass = 0;
foreach ($docs as $path => $name) {
    if (test_file_exists($path, $name)) {
        test_file_size($path, $name, 500);
        $docs_pass++;
    }
}

Terminal::hr();
Terminal::info("مستندات: {$docs_pass}/" . count($docs) . " فایل OK");

// ============================================
// TEST 4: COMPATIBILITY
// ============================================
Terminal::header("سازگاری");

Terminal::info("PHP Version: " . phpversion());
if (version_compare(phpversion(), '8.2', '>=')) {
    Terminal::success("PHP 8.2+ سازگار است");
} else {
    Terminal::warning("PHP 8.2+ توصیه می‌شود");
}

$extensions = ['pdo', 'pdo_mysql', 'json', 'gd'];
foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        Terminal::success("Extension '$ext' موجود است");
    } else {
        Terminal::error("Extension '$ext' موجود نیست");
    }
}

// ============================================
// TEST 5: LOAD & SYNTAX CHECK
// ============================================
Terminal::header("سینتکس کد");

try {
    require $base_path . '/includes/Response.php';
    Terminal::success("Response.php بدون خطا لود شد");
} catch (Exception $e) {
    Terminal::error("Response.php: " . $e->getMessage());
}

try {
    require $base_path . '/includes/Validator.php';
    Terminal::success("Validator.php بدون خطا لود شد");
} catch (Exception $e) {
    Terminal::error("Validator.php: " . $e->getMessage());
}

try {
    require $base_path . '/includes/Repository.php';
    Terminal::success("Repository.php بدون خطا لود شد");
} catch (Exception $e) {
    Terminal::error("Repository.php: " . $e->getMessage());
}

try {
    require $base_path . '/includes/Service.php';
    Terminal::success("Service.php بدون خطا لود شد");
} catch (Exception $e) {
    Terminal::error("Service.php: " . $e->getMessage());
}

// ============================================
// FINAL SUMMARY
// ============================================
Terminal::header("خلاصه");

$total_files = count($phase1_files) + count($phase2_files) + count($docs);
$total_pass = $phase1_pass + $phase2_pass + $docs_pass;

echo Terminal::BOLD . "📊 نتایج:\n" . Terminal::RESET;
echo "  Phase 1 (طراحی):        {$phase1_pass}/" . count($phase1_files) . " ✓\n";
echo "  Phase 2 (معماری):      {$phase2_pass}/" . count($phase2_files) . " ✓\n";
echo "  مستندات:               {$docs_pass}/" . count($docs) . " ✓\n";
echo "  ─────────────────────────\n";
echo "  کل:                    {$total_pass}/{$total_files} ✓\n\n";

if ($total_pass === $total_files) {
    Terminal::success("تمام تست‌ها موفقیت‌آمیز بود! 🎉");
    Terminal::info("پروژه آماده برای استفاده است.");
} else {
    Terminal::warning("بعضی تست‌ها ناموفق بود. لطفاً بررسی کنید.");
}

Terminal::hr();
Terminal::info("مراحل بعد:");
echo "  1. SETUP_GUIDE.md را بخوانید\n";
echo "  2. php -S localhost:8000 اجرا کنید\n";
echo "  3. http://localhost:8000 را بازدید کنید\n";
echo "  4. Ctrl+K برای جستجو فشار دهید\n";
echo "  5. DevTools میں صفحات را بررسی کنید\n\n";

Terminal::success("Happy coding! 🚀");
?>
