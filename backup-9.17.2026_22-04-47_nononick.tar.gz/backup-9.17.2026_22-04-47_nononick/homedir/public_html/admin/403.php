<?php
/**
 * Nononik — صفحه ۴۰۳ (عدم دسترسی)
 * چرا: از includes/functions.php توسط require_permission() فراخوانی می‌شود؛
 * صفحه‌ای مستقل است چون ممکن است پیش از رندر کامل layout هر صفحه صدا زده شود.
 */
if (!function_exists('e')) {
    require_once __DIR__ . '/includes/functions.php';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>عدم دسترسی | Nononik</title>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= defined('BASE_URL') ? BASE_URL : '/' ?>assets/css/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-card glass" style="text-align:center;">
        <div class="logo" style="background:linear-gradient(135deg,#ef4444,#f59e0b);margin:0 auto 18px;">
            <i class="fa-solid fa-lock" style="font-size:20px;color:#fff;"></i>
        </div>
        <h1>۴۰۳ — عدم دسترسی</h1>
        <p>متأسفانه شما مجوز لازم برای مشاهده‌ی این بخش از پنل را ندارید.</p>
        <p style="font-size:12.5px;color:var(--text-2);margin-top:8px;">
            اگر فکر می‌کنید این یک اشتباه است، با مدیر کل پنل تماس بگیرید تا نقش/دسترسی مناسب را برای شما فعال کند.
        </p>
        <a href="<?= (defined('BASE_URL') ? BASE_URL : '/') ?>index.php" class="btn btn-primary" style="margin-top:22px;">
            <i class="fa-solid fa-house"></i> بازگشت به داشبورد
        </a>
    </div>
</div>
</body>
</html>
