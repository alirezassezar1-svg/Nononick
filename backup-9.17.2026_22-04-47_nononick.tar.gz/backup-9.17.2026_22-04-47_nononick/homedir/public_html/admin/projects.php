<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('projects.view');
$pageTitle = 'پروژه ها';

// ---------- Handle actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        require_permission($id ? 'projects.edit' : 'projects.create');
        $title = trim($_POST['title'] ?? '');
        $client = trim($_POST['client_name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $status = $_POST['status'] ?? 'in_progress';
        $progress = max(0, min(100, (int) ($_POST['progress'] ?? 0)));
        $budget = (float) ($_POST['budget'] ?? 0);
        $started = $_POST['started_at'] ?: null;
        $userId = ($_POST['user_id'] ?? '') !== '' ? (int) $_POST['user_id'] : null; // چرا: اتصال پروژه به حساب مشتری در پنل کاربر

        if ($title === '') {
            set_flash('error', 'عنوان پروژه الزامی است.');
            redirect('projects.php');
        }

        $oldImage = null;
        if ($id) {
            $stmt = db()->prepare('SELECT image FROM projects WHERE id = ?');
            $stmt->execute([$id]);
            $oldImage = $stmt->fetchColumn();
        }
        $image = upload_image($_FILES['image'] ?? [], 'projects', $oldImage ?: null);

        if ($id) {
            $stmt = db()->prepare('UPDATE projects SET title=?, client_name=?, user_id=?, description=?, image=?, status=?, progress=?, budget=?, started_at=? WHERE id=?');
            $stmt->execute([$title, $client, $userId, $desc, $image, $status, $progress, $budget, $started, $id]);
            set_flash('success', 'پروژه با موفقیت ویرایش شد.');
        } else {
            $stmt = db()->prepare('INSERT INTO projects (title, client_name, user_id, description, image, status, progress, budget, started_at) VALUES (?,?,?,?,?,?,?,?,?)');
            $stmt->execute([$title, $client, $userId, $desc, $image, $status, $progress, $budget, $started]);
            db()->prepare('INSERT INTO activities (icon,title,description) VALUES (?,?,?)')
                ->execute(['fa-solid fa-folder-plus', 'پروژه جدید اضافه شد', $title]);
            set_flash('success', 'پروژه جدید با موفقیت اضافه شد.');
        }
        redirect('projects.php');
    }

    if ($action === 'delete') {
        require_permission('projects.delete');
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = db()->prepare('SELECT image FROM projects WHERE id = ?');
        $stmt->execute([$id]);
        if ($img = $stmt->fetchColumn()) {
            @unlink(UPLOAD_DIR . 'projects/' . $img);
        }
        db()->prepare('DELETE FROM projects WHERE id = ?')->execute([$id]);
        set_flash('success', 'پروژه حذف شد.');
        redirect('projects.php');
    }
}

// ---------- List + search + pagination ----------
$search = trim($_GET['q'] ?? '');
$perPage = 8;
$page = max(1, (int) ($_GET['page'] ?? 1));

$where = '';
$params = [];
if ($search !== '') {
    $where = 'WHERE title LIKE ? OR client_name LIKE ?';
    $params = ["%$search%", "%$search%"];
}

$total = db()->prepare("SELECT COUNT(*) FROM projects $where");
$total->execute($params);
$totalRows = (int) $total->fetchColumn();
[$totalPages, $page, $offset] = paginate($totalRows, $perPage, $page);

$stmt = db()->prepare("SELECT * FROM projects $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$projects = $stmt->fetchAll();

// چرا: برای اتصال پروژه به حساب مشتری در پنل کاربر (dropdown داخل مودال)
$clientUsers = db()->query('SELECT id, full_name, email FROM users ORDER BY full_name ASC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div>
                    <h2>مدیریت پروژه‌ها</h2>
                    <p class="breadcrumb">داشبورد <b>/ پروژه‌ها</b></p>
                </div>
                <?php if (can('projects.create')): ?>
                <button class="btn btn-primary" style="width:auto" data-modal-target="#projectModal" onclick="openProjectModal()"><i class="fa-solid fa-plus"></i> پروژه جدید</button>
                <?php endif; ?>
            </div>

            <div class="toolbar">
                <form class="search-box" method="get">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" name="q" placeholder="جستجوی پروژه یا کارفرما..." value="<?= e($search) ?>">
                </form>
                <span style="font-size:12.5px;color:var(--text-2)"><?= $totalRows ?> پروژه یافت شد</span>
            </div>

            <div class="table-card glass">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>تصویر</th><th>عنوان پروژه</th><th>کارفرما</th><th>وضعیت</th><th>پیشرفت</th><th>بودجه</th><th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($projects as $p): ?>
                        <tr>
                            <td><img loading="lazy" decoding="async" class="row-thumb" src="<?= e(image_url($p['image'], 'projects')) ?>" alt=""></td>
                            <td><b><?= e($p['title']) ?></b></td>
                            <td>
                                <?= e($p['client_name']) ?>
                                <?php if ($p['user_id']): ?><br><small style="color:var(--cyan)"><i class="fa-solid fa-user-check"></i> متصل به پنل کاربر</small><?php endif; ?>
                            </td>
                            <td><span class="badge badge-<?= e($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
                            <td style="min-width:120px;">
                                <div class="progress-bar"><span style="width:<?= (int)$p['progress'] ?>%"></span></div>
                                <small style="color:var(--text-2)"><?= (int)$p['progress'] ?>%</small>
                            </td>
                            <td><?= number_format($p['budget']) ?> تومان</td>
                            <td class="actions-cell">
                                <?php if (can('projects.edit')): ?>
                                <button class="btn-icon btn-sm" onclick='openProjectModal(<?= json_encode($p, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                                <?php endif; ?>
                                <?php if (can('projects.delete')): ?>
                                <form method="post" onsubmit="return confirm('آیا از حذف این پروژه مطمئن هستید؟')">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                    <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($projects)): ?><tr><td colspan="7" style="text-align:center;color:var(--text-2);padding:30px">پروژه‌ای یافت نشد.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>" class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal-overlay" id="projectModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3 id="projectModalTitle">پروژه جدید</h3>
            <button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id" value="">

            <div class="form-group">
                <label>تصویر پروژه</label>
                <img id="f_preview" class="current-image" src="<?= e(image_url(null, 'projects')) ?>" alt="">
                <input type="file" name="image" class="form-control" accept="image/*" data-preview="#f_preview">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>عنوان پروژه</label>
                    <input type="text" name="title" id="f_title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>نام کارفرما</label>
                    <input type="text" name="client_name" id="f_client" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <label>اتصال به پنل کاربر <small style="color:var(--text-2);font-weight:400;">(اختیاری — این پروژه در داشبورد کدام مشتری نمایش داده شود؟)</small></label>
                <select name="user_id" id="f_user_id" class="form-control">
                    <option value="">— بدون اتصال —</option>
                    <?php foreach ($clientUsers as $u): ?>
                    <option value="<?= $u['id'] ?>"><?= e($u['full_name']) ?> (<?= e($u['email']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>توضیحات</label>
                <textarea name="description" id="f_desc" class="form-control"></textarea>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>وضعیت</label>
                    <select name="status" id="f_status" class="form-control">
                        <option value="in_progress">در حال اجرا</option>
                        <option value="completed">تکمیل شده</option>
                        <option value="pending">در انتظار</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>درصد پیشرفت</label>
                    <input type="number" name="progress" id="f_progress" min="0" max="100" class="form-control" value="0">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>بودجه (تومان)</label>
                    <input type="number" name="budget" id="f_budget" class="form-control" value="0">
                </div>
                <div class="form-group">
                    <label>تاریخ شروع</label>
                    <input type="date" name="started_at" id="f_started" class="form-control">
                </div>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
function openProjectModal(data) {
    document.getElementById('projectModal').classList.add('show');
    const title = document.getElementById('projectModalTitle');
    if (data) {
        title.textContent = 'ویرایش پروژه';
        f_id.value = data.id;
        f_title.value = data.title;
        f_client.value = data.client_name || '';
        f_user_id.value = data.user_id || '';
        f_desc.value = data.description || '';
        f_status.value = data.status;
        f_progress.value = data.progress;
        f_budget.value = data.budget;
        f_started.value = data.started_at || '';
        f_preview.src = data.image ? '<?= UPLOAD_URL ?>projects/' + data.image : '<?= e(image_url(null, "projects")) ?>';
    } else {
        title.textContent = 'پروژه جدید';
        document.querySelector('#projectModal form').reset();
        f_id.value = '';
        f_user_id.value = '';
        f_preview.src = '<?= e(image_url(null, "projects")) ?>';
    }
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
