# Phase 2: Clean Architecture & Core Systems ✅

## Overview

Phase 2 implements a **clean, PSR-12 compliant architecture** with industry-standard patterns:

- **Service Layer**: Business logic encapsulation
- **Repository Pattern**: Data access abstraction
- **Validation Framework**: Reusable validators with Persian messages
- **Response Formatter**: Standardized JSON API responses
- **Activity Logging**: Complete audit trail
- **Notification System**: In-app alerts

---

## Architecture Overview

```
Application Layer (Controllers/Pages)
    ↓
Service Layer (Business Logic)
    ↓
Repository Layer (Data Access)
    ↓
Database (MySQL/PDO)
```

### Data Flow Example

```
index.php (page)
  ↓
UserService::getProfile($id)
  ├─ Validate inputs
  ├─ Call repository
  └─ Log activity
    ↓
UserRepository::find($id)
  ├─ Execute prepared statement
  └─ Return data
```

---

## Core Classes

### 1. Response — Standardized API Responses

```php
// Success response
Response::success($data, 'درخواست موفق', 200);

// Error response
Response::error('خطا در پردازش', 400);

// Validation errors
Response::validationError(['email' => 'ایمیل نامعتبر است']);

// Paginated response
Response::paginated($items, $total, $page, $per_page);

// Download file
Response::download($file_path, $filename);
```

### 2. Validator — Validation Framework

```php
// Basic usage
$validator = new Validator($data);
$validator->rule('email', 'required|email');
$validator->rule('password', 'required|min:8|confirmed');

if ($validator->validate()) {
    // Process...
} else {
    $errors = $validator->errors();
}

// Static usage
$validator = Validator::make($data, [
    'name' => 'required|min:3|max:100',
    'email' => 'required|email|unique:users,email',
    'password' => 'required|min:8|confirmed',
]);
```

**Available Rules:**
- `required` — Field is mandatory
- `email` — Valid email format
- `min:N` — Minimum N characters
- `max:N` — Maximum N characters
- `numeric` — Must be number
- `persian` — Must contain Persian characters
- `phone` — Valid Iranian phone number
- `url` — Valid URL
- `image` — Valid image file
- `date` — Valid date
- `unique:table,column` — Value unique in database
- `match:field` — Match another field
- `confirmed` — Has `_confirmation` field matching

**All error messages in Persian!**

### 3. Repository — Data Access Layer

```php
// Base methods (all repos have these)
$user = $userRepo->find($id);                    // Find by ID
$user = $userRepo->findBy('email', $email);    // Find by column
$users = $userRepo->findAll($options);         // Find all
$count = $userRepo->count();                   // Count total
$id = $userRepo->create($data);                // Create new
$success = $userRepo->update($id, $data);      // Update
$success = $userRepo->delete($id);             // Delete
$success = $userRepo->softDelete($id);         // Soft delete
$success = $userRepo->restore($id);            // Restore
$exists = $userRepo->exists($id);              // Check exists
$paginated = $userRepo->paginate($page, 20);   // Paginate

// Custom methods (per repository)
$user = $userRepo->findByEmail($email);
$users = $userRepo->getActive($limit);
$users = $userRepo->getByRole('admin');
$results = $userRepo->search($query);
```

### 4. Service — Business Logic Layer

```php
$userService = new UserService($userRepository);

// Create user with validation and logging
$user_id = $userService->create([
    'name' => 'احمد',
    'email' => 'ahmad@example.com',
    'username' => 'ahmad',
    'password' => 'SecurePass123',
    'password_confirmation' => 'SecurePass123',
]);

if ($user_id) {
    // Success!
} else {
    $error = $userService->firstError();
}

// Update profile
$success = $userService->update($user_id, [
    'name' => 'احمد محمدی',
]);

// Change password
$success = $userService->changePassword($user_id, $old_pass, $new_pass);

// Delete
$success = $userService->delete($user_id);

// Search
$results = $userService->search('احمد');

// Paginate
$data = $userService->paginate($page, 20);
```

---

## File Structure

```
includes/
├── app.php                 Config & initialization
├── Response.php            API response formatter
├── Validator.php           Validation framework
├── Repository.php          Base + User repository
├── Service.php             Base + User service
├── functions.php           Helper functions
├── security.php            Security utilities
├── auth.php                Authentication
├── header.php              HTML head
├── footer.php              HTML footer
├── sidebar.php
├── topbar.php
└── ... (existing files)
```

---

## Usage Examples

### Creating a New User

```php
<?php
// pages/users/create.php

require_once __DIR__ . '/../../includes/app.php';
require_once __DIR__ . '/../../includes/Response.php';
require_once __DIR__ . '/../../includes/Validator.php';
require_once __DIR__ . '/../../includes/Repository.php';
require_once __DIR__ . '/../../includes/Service.php';

// Only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::methodNotAllowed();
}

// Validate CSRF token
if (!verify_csrf_token($_POST['_token'] ?? '')) {
    Response::error('خطای امنیتی', 403);
}

// Create service
$userRepo = new UserRepository($pdo);
$userService = new UserService($userRepo);

// Create user
$user_id = $userService->create($_POST);

if ($user_id) {
    Response::success(['id' => $user_id], 'کاربر با موفقیت ایجاد شد', 201);
} else {
    Response::error($userService->firstError(), 422);
}
```

### Activity Logging

All service operations automatically log activities:

```php
// Logged to activity_logs table:
// - user_id (who did it)
// - action (what they did)
// - data (JSON details)
// - ip_address (from where)
// - user_agent (which browser)
// - created_at (when)
```

### Notifications

Services can send in-app notifications:

```php
// In UserService::create()
$this->sendNotification(
    $user_id,
    'خوش آمدید',
    'حسابتان ایجاد شد',
    'success'
);

// User sees in-app notification
// Can also queue for email later
```

---

## Database Schema Updates

New tables created for Phase 2:

```sql
-- Activity Log
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    data JSON,
    ip_address VARCHAR(50),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY (user_id, created_at)
);

-- Notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT,
    type VARCHAR(20),
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY (user_id, created_at)
);
```

---

## Extending the System

### Create a New Service

```php
class ProjectService extends Service {
    public function create($data) {
        $this->clearErrors();
        
        // Validate
        $validator = Validator::make($data, [
            'name' => 'required|min:3|max:100',
            'description' => 'required|min:10|max:1000',
        ]);
        
        if (!$validator->validate()) {
            foreach ($validator->errors() as $errors) {
                $this->addError($errors[0]);
            }
            return null;
        }
        
        // Create
        $id = $this->repository->create($data);
        
        if ($id) {
            $this->logActivity('project_created', auth_user_id(), [
                'project_id' => $id,
            ]);
        }
        
        return $id;
    }
}
```

### Create a New Repository

```php
class ProjectRepository extends Repository {
    protected $table = 'projects';
    
    public function getActive() {
        return $this->findAll([
            'where' => ['status = ?'],
            'params' => ['active'],
            'order_by' => 'created_at DESC',
        ]);
    }
    
    public function search($query) {
        $query = "%{$query}%";
        $sql = "SELECT * FROM {$this->table} "
             . "WHERE name LIKE ? OR description LIKE ? "
             . "ORDER BY name ASC LIMIT 20";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$query, $query]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
```

---

## Best Practices

✅ **DO:**
- Use services for all business logic
- Validate all inputs with Validator
- Log important activities
- Return standardized Response objects
- Use transactions for multi-step operations
- Handle errors gracefully

❌ **DON'T:**
- Access database directly from pages
- Mix business logic in HTML
- Trust user input
- Catch exceptions silently
- Create magic methods
- Use global variables

---

## Testing the System

```php
// Quick test in browser console
// Create user
POST /api/users/create.php
{
    "name": "تست",
    "email": "test@example.com",
    "username": "test",
    "password": "Test1234567",
    "password_confirmation": "Test1234567"
}

// Response
{
    "success": true,
    "message": "کاربر با موفقیت ایجاد شد",
    "data": { "id": 123 },
    "timestamp": 1234567890
}

// Update user
POST /api/users/123/update.php
{
    "name": "تست اپ دیت"
}

// Response
{
    "success": true,
    "message": "درخواست با موفقیت انجام شد",
    "data": null,
    "timestamp": 1234567890
}

// Validation error
POST /api/users/create.php
{
    "name": "Test"
    // Missing required fields
}

// Response
{
    "success": false,
    "message": "داده‌های ارسالی معتبر نیستند",
    "errors": {
        "email": ["email الزامی است"],
        "password": ["password الزامی است"]
    },
    "timestamp": 1234567890
}
```

---

## What's Next

**Phase 3:** Dashboard & Advanced Analytics
- Real KPI cards with live data
- Interactive charts with time range
- Advanced filtering and export
- Calendar and Kanban views

---

**Phase 2 Complete: Clean Architecture ✅**
