<?php
/**
 * Nononik - Bootstrap
 * Included at the top of every protected page.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/security.php';

apply_security_headers();

// ---- Auth guard ----
$currentScript = basename($_SERVER['SCRIPT_NAME']);
$publicPages = ['login.php'];

if (!in_array($currentScript, $publicPages, true)) {
    if (empty($_SESSION['admin_id'])) {
        redirect('login.php');
    }
}

$admin = null;
if (!empty($_SESSION['admin_id'])) {
    $stmt = db()->prepare('SELECT * FROM admins WHERE id = ?');
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    if (!$admin) {
        session_destroy();
        redirect('login.php');
    }
}
