<?php
/**
 * Nononik — Validation Framework
 * Reusable validators with Persian error messages
 */

class Validator
{
    private $data = [];
    private $errors = [];
    private $rules = [];

    public function __construct($data = [])
    {
        $this->data = $data;
    }

    /**
     * Add validation rule
     *
     * @param string $field Field name
     * @param string $rules Pipe-separated rules (required|email|min:5|max:100)
     * @return self
     */
    public function rule($field, $rules)
    {
        $this->rules[$field] = $rules;
        return $this;
    }

    /**
     * Validate data against rules
     *
     * @return bool True if valid, false otherwise
     */
    public function validate()
    {
        foreach ($this->rules as $field => $rules) {
            $value = $this->data[$field] ?? '';
            $rule_list = explode('|', $rules);

            foreach ($rule_list as $rule) {
                $this->validateField($field, $value, trim($rule));
            }
        }

        return empty($this->errors);
    }

    /**
     * Validate single field
     *
     * @param string $field Field name
     * @param mixed $value Field value
     * @param string $rule Validation rule
     * @return void
     */
    private function validateField($field, $value, $rule)
    {
        if (strpos($rule, ':') !== false) {
            [$rule, $param] = explode(':', $rule, 2);
        } else {
            $param = null;
        }

        switch ($rule) {
            case 'required':
                if (empty($value)) {
                    $this->addError($field, "{$field} الزامی است");
                }
                break;

            case 'email':
                if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->addError($field, "{$field} باید یک آدرس ایمیل معتبر باشد");
                }
                break;

            case 'min':
                if (!empty($value) && strlen($value) < (int)$param) {
                    $this->addError($field, "{$field} حداقل باید {$param} کاراکتر باشد");
                }
                break;

            case 'max':
                if (!empty($value) && strlen($value) > (int)$param) {
                    $this->addError($field, "{$field} حداکثر باید {$param} کاراکتر باشد");
                }
                break;

            case 'numeric':
                if (!empty($value) && !is_numeric($value)) {
                    $this->addError($field, "{$field} باید عدد باشد");
                }
                break;

            case 'persian':
                if (!empty($value) && !self::isPersian($value)) {
                    $this->addError($field, "{$field} باید شامل کاراکترهای فارسی باشد");
                }
                break;

            case 'phone':
                if (!empty($value) && !preg_match('/^(\+98|0)?9\d{9}$/', $value)) {
                    $this->addError($field, "{$field} باید شماره تلفن معتبر باشد");
                }
                break;

            case 'url':
                if (!empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) {
                    $this->addError($field, "{$field} باید یک URL معتبر باشد");
                }
                break;

            case 'image':
                if (!empty($value) && !self::isImage($value)) {
                    $this->addError($field, "{$field} باید یک تصویر باشد");
                }
                break;

            case 'date':
                if (!empty($value) && !strtotime($value)) {
                    $this->addError($field, "{$field} باید تاریخ معتبر باشد");
                }
                break;

            case 'unique':
                if (!empty($value) && !self::isUnique($param, $field, $value)) {
                    $this->addError($field, "{$field} قبلاً ثبت شده است");
                }
                break;

            case 'match':
                if (!empty($value) && $value !== ($this->data[$param] ?? '')) {
                    $this->addError($field, "{$field} با {$param} مطابقت ندارد");
                }
                break;

            case 'confirmed':
                $confirm_field = "{$field}_confirmation";
                if ($value !== ($this->data[$confirm_field] ?? '')) {
                    $this->addError($field, "{$field} تایید نشده است");
                }
                break;

            default:
                // Custom rule support
                if (method_exists($this, "validate_{$rule}")) {
                    $this->{"validate_{$rule}"}($field, $value, $param);
                }
        }
    }

    /**
     * Add validation error
     *
     * @param string $field Field name
     * @param string $message Error message
     * @return void
     */
    private function addError($field, $message)
    {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }

    /**
     * Get all errors
     *
     * @return array
     */
    public function errors()
    {
        return $this->errors;
    }

    /**
     * Get first error
     *
     * @return string|null
     */
    public function firstError()
    {
        if (empty($this->errors)) {
            return null;
        }

        $first_field_errors = reset($this->errors);
        return $first_field_errors[0] ?? null;
    }

    /**
     * Get error for field
     *
     * @param string $field Field name
     * @return string|null
     */
    public function errorFor($field)
    {
        return $this->errors[$field][0] ?? null;
    }

    /**
     * Check if Persian text
     *
     * @param string $text Text to check
     * @return bool
     */
    public static function isPersian($text)
    {
        return preg_match('/[\x{0600}-\x{06FF}]/u', $text);
    }

    /**
     * Check if valid image
     *
     * @param string $file_path File path
     * @return bool
     */
    public static function isImage($file_path)
    {
        if (!file_exists($file_path)) {
            return false;
        }

        $mime = mime_content_type($file_path);
        return strpos($mime, 'image/') === 0;
    }

    /**
     * Check if value is unique in database
     *
     * @param string $table Table name
     * @param string $column Column name
     * @param string $value Value to check
     * @return bool
     */
    public static function isUnique($table, $column, $value)
    {
        global $pdo;

        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$table} WHERE {$column} = ?");
            $stmt->execute([$value]);
            return $stmt->fetchColumn() === 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Static validate method for quick validation
     *
     * @param array $data Data to validate
     * @param array $rules Rules as array
     * @return self
     */
    public static function make($data, $rules = [])
    {
        $validator = new self($data);

        foreach ($rules as $field => $rule) {
            $validator->rule($field, $rule);
        }

        return $validator;
    }
}
