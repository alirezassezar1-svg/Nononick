<?php
/**
 * Nononik — API Response Formatter
 * Standardized JSON responses for all API endpoints
 */

class Response
{
    /**
     * Send success response
     *
     * @param mixed $data Response data
     * @param string $message Success message
     * @param int $code HTTP status code
     * @return void
     */
    public static function success($data = null, $message = 'درخواست با موفقیت انجام شد', $code = 200)
    {
        self::send([
            'success' => true,
            'message' => $message,
            'data' => $data,
            'timestamp' => time(),
        ], $code);
    }

    /**
     * Send error response
     *
     * @param string $message Error message
     * @param int $code HTTP status code
     * @param mixed $errors Validation errors
     * @return void
     */
    public static function error($message = 'خطا در پردازش درخواست', $code = 400, $errors = null)
    {
        self::send([
            'success' => false,
            'message' => $message,
            'errors' => $errors,
            'timestamp' => time(),
        ], $code);
    }

    /**
     * Send validation error response
     *
     * @param array $errors Validation errors
     * @return void
     */
    public static function validationError($errors)
    {
        self::error('داده‌های ارسالی معتبر نیستند', 422, $errors);
    }

    /**
     * Send unauthorized response
     *
     * @return void
     */
    public static function unauthorized()
    {
        self::error('شما مجاز به دسترسی نیستید', 401);
    }

    /**
     * Send forbidden response
     *
     * @return void
     */
    public static function forbidden()
    {
        self::error('دسترسی ممنوع است', 403);
    }

    /**
     * Send not found response
     *
     * @return void
     */
    public static function notFound()
    {
        self::error('منبع درخواستی یافت نشد', 404);
    }

    /**
     * Send method not allowed response
     *
     * @return void
     */
    public static function methodNotAllowed()
    {
        self::error('روش درخواست مجاز نیست', 405);
    }

    /**
     * Send too many requests response
     *
     * @return void
     */
    public static function tooManyRequests()
    {
        self::error('تعداد درخواست‌های بیش از حد مجاز', 429);
    }

    /**
     * Send internal server error response
     *
     * @return void
     */
    public static function internalError()
    {
        self::error('خطای داخلی سرور', 500);
    }

    /**
     * Send raw JSON response
     *
     * @param array $data Response data
     * @param int $code HTTP status code
     * @return void
     */
    private static function send($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /**
     * Paginated response
     *
     * @param array $items Items list
     * @param int $total Total count
     * @param int $page Current page
     * @param int $per_page Items per page
     * @return void
     */
    public static function paginated($items, $total, $page = 1, $per_page = 20)
    {
        $last_page = ceil($total / $per_page);

        self::success([
            'items' => $items,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $per_page,
                'last_page' => $last_page,
                'has_more' => $page < $last_page,
            ],
        ]);
    }

    /**
     * Download file response
     *
     * @param string $file_path File path
     * @param string $file_name Download name
     * @return void
     */
    public static function download($file_path, $file_name = null)
    {
        if (!file_exists($file_path)) {
            self::notFound();
        }

        $file_name = $file_name ?? basename($file_path);
        $mime_type = mime_content_type($file_path);

        header('Content-Type: ' . $mime_type);
        header('Content-Disposition: attachment; filename="' . $file_name . '"');
        header('Content-Length: ' . filesize($file_path));

        readfile($file_path);
        exit;
    }
}
