<?php
/**
 * @var string $pageTitle
 * @var string|null $metaDescription  (اختیاری، override توضیحات متا برای هر صفحه)
 */
$siteTitle = setting('site_title', 'Nononik');
$siteDesc  = $metaDescription ?? setting('site_description', 'پنل مدیریت هوشمند Nononik');
$siteLogo  = setting('site_logo', '') ?: (BASE_URL . 'assets/img/placeholder.svg');
$ogImage   = setting('og_image', '') ?: $siteLogo;
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'داشبورد') ?> | <?= e($siteTitle) ?></title>

<!-- چرا: این پنل خصوصی و پشت لاگین است — نباید در نتایج گوگل ایندکس شود -->
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="<?= e($siteDesc) ?>">
<meta name="keywords" content="<?= e(setting('seo_keywords', '')) ?>">

<!-- Open Graph -->
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($pageTitle ?? 'داشبورد') ?> | <?= e($siteTitle) ?>">
<meta property="og:description" content="<?= e($siteDesc) ?>">
<meta property="og:image" content="<?= e($ogImage) ?>">
<meta property="og:locale" content="fa_IR">

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($siteTitle) ?>">
<meta name="twitter:description" content="<?= e($siteDesc) ?>">

<!-- Schema.org — آماده استفاده مجدد در Frontend عمومی که روی همین دیتابیس ساخته می‌شود -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": <?= json_encode($siteTitle, JSON_UNESCAPED_UNICODE) ?>,
  "description": <?= json_encode($siteDesc, JSON_UNESCAPED_UNICODE) ?>,
  "email": <?= json_encode(setting('contact_email', ''), JSON_UNESCAPED_UNICODE) ?>
}
</script>

<!-- چرا: اعمال تم قبل از رندر CSS، جلوگیری از فلش تم اشتباه (FOUC) -->
<script>
(function () {
  var saved = localStorage.getItem('sunpanel-theme');
  var theme = saved || 'dark';
  document.documentElement.setAttribute('data-theme', theme);
})();
</script>

<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<!-- چرا: فونت با font-display:swap لود می‌شود تا از FOIT (متن نامرئی هنگام لود فونت) جلوگیری شود -->
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" media="all">
<!-- چرا: آیکون‌ها بحرانی نیستند؛ با preload+onload به‌صورت غیرمسدودکننده لود می‌شوند (بهبود LCP) -->
<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>

<!-- Design System -->
<link rel="icon" href="<?= BASE_URL ?>assets/images/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="16x16" href="<?= BASE_URL ?>assets/images/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="48x48" href="<?= BASE_URL ?>assets/images/favicon-48x48.png">
<link rel="icon" type="image/png" sizes="192x192" href="<?= BASE_URL ?>assets/images/favicon-192x192.png">
<link rel="icon" type="image/png" sizes="512x512" href="<?= BASE_URL ?>assets/images/favicon-512x512.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>assets/images/apple-touch-icon.png">
<link rel="manifest" href="<?= BASE_URL ?>assets/images/site.webmanifest">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/design-tokens.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/theme.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/motion.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/components.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/command-palette.css">

<!-- Legacy styles (will be refactored) -->
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/text-3d.css">
<style>
:root{
  --text-3d-blue-1: <?= e(setting('text3d_blue1', '#c4b5fd')) ?>;
  --text-3d-blue-2: <?= e(setting('text3d_blue2', '#60a5fa')) ?>;
  --text-3d-pink-1: <?= e(setting('text3d_pink1', '#f0abfc')) ?>;
  --text-3d-pink-2: <?= e(setting('text3d_pink2', '#c084fc')) ?>;
}
</style>
</head>
<body>
<!-- چرا: کرسر سفارشی و افکت ذرات پس‌زمینه، بخشی از لایه Visual System -->
<div class="mesh-bg"></div>
<div class="custom-cursor" id="customCursor"></div>
<div class="page-transition" id="pageTransition"></div>
<div class="toast-container" id="toastContainer"></div>
