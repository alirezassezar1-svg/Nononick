<?php $unreadMessages = $unreadMessages ?? db()->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn(); ?>
<header class="topbar">
    <button class="btn-icon" data-sidebar-toggle style="display:none" id="mobileToggle"><i class="fa-solid fa-bars"></i></button>
    <div class="search-box" id="globalSearch">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="globalSearchInput" placeholder="جستجو در داشبورد... (پروژه، کاربر، مقاله...)" autocomplete="off">
        <span class="search-kbd">Ctrl K</span>
        <div class="search-results" id="globalSearchResults"></div>
    </div>
    <div class="topbar-actions">
        <button class="icon-btn" id="themeToggle" title="حالت روشن/تاریک">
            <i class="fa-solid fa-circle-half-stroke"></i>
        </button>
        <button class="icon-btn" title="اعلان‌ها">
            <i class="fa-regular fa-bell"></i>
            <span class="dot">8</span>
        </button>
        <a href="messages.php" class="icon-btn" title="پیام‌ها">
            <i class="fa-regular fa-envelope"></i>
            <?php if ($unreadMessages > 0): ?><span class="dot"><?= (int)$unreadMessages ?></span><?php endif; ?>
        </a>
        <div class="lang-pill"><i class="fa-solid fa-globe"></i> FA</div>
        <div class="admin-pill" data-admin-toggle>
            <img src="<?= e(image_url($admin['avatar'] ?? null, 'users')) ?>" alt="avatar">
            <div>
                <div class="name"><?= e($admin['full_name'] ?? 'Admin') ?></div>
                <div class="role"><?= e($admin['role'] ?? 'مدیر سیستم') ?></div>
            </div>
            <i class="fa-solid fa-chevron-down" style="font-size:11px;color:var(--text-2)"></i>
            <div class="admin-dropdown">
                <a href="users.php"><i class="fa-regular fa-user"></i> پروفایل</a>
                <a href="settings.php"><i class="fa-solid fa-gear"></i> تنظیمات</a>
                <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> خروج</a>
            </div>
        </div>
    </div>
</header>
