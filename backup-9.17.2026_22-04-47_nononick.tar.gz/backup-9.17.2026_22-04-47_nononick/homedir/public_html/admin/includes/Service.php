<?php
/**
 * Nononik — Service Layer Base Class
 * Business logic encapsulation
 */

abstract class Service
{
    protected $repository;
    protected $errors = [];

    public function __construct(Repository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * Get service errors
     *
     * @return array
     */
    public function errors()
    {
        return $this->errors;
    }

    /**
     * Add service error
     *
     * @param string $message Error message
     * @return void
     */
    protected function addError($message)
    {
        $this->errors[] = $message;
    }

    /**
     * Clear service errors
     *
     * @return void
     */
    protected function clearErrors()
    {
        $this->errors = [];
    }

    /**
     * Check if operation was successful
     *
     * @return bool
     */
    public function isSuccessful()
    {
        return empty($this->errors);
    }

    /**
     * Get first error message
     *
     * @return string|null
     */
    public function firstError()
    {
        return $this->errors[0] ?? null;
    }

    /**
     * Log activity
     *
     * @param string $action Action performed
     * @param int $user_id User ID
     * @param array $data Additional data
     * @return void
     */
    protected function logActivity($action, $user_id, $data = [])
    {
        global $pdo;

        try {
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action, data, ip_address, user_agent, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $user_id,
                $action,
                json_encode($data, JSON_UNESCAPED_UNICODE),
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? '',
            ]);
        } catch (PDOException $e) {
            error_log('Activity log error: ' . $e->getMessage());
        }
    }

    /**
     * Send notification
     *
     * @param int $user_id User ID
     * @param string $title Notification title
     * @param string $message Notification message
     * @param string $type Notification type (info, success, warning, error)
     * @return void
     */
    protected function sendNotification($user_id, $title, $message, $type = 'info')
    {
        global $pdo;

        try {
            $stmt = $pdo->prepare("
                INSERT INTO notifications (user_id, title, message, type, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");

            $stmt->execute([$user_id, $title, $message, $type]);
        } catch (PDOException $e) {
            error_log('Notification error: ' . $e->getMessage());
        }
    }
}

/**
 * User Service — Example implementation
 */
class UserService extends Service
{
    /**
     * Get user profile
     *
     * @param int $user_id User ID
     * @return array|null
     */
    public function getProfile($user_id)
    {
        $user = $this->repository->find($user_id);

        if (!$user) {
            $this->addError('کاربر یافت نشد');
            return null;
        }

        // Remove sensitive data
        unset($user['password']);

        return $user;
    }

    /**
     * Create new user
     *
     * @param array $data User data
     * @return int|null User ID or null on failure
     */
    public function create($data)
    {
        $this->clearErrors();

        // Validate
        $validator = Validator::make($data, [
            'name' => 'required|min:3|max:100',
            'email' => 'required|email|unique:users,email',
            'username' => 'required|min:3|max:50|unique:users,username',
            'password' => 'required|min:8|confirmed',
        ]);

        if (!$validator->validate()) {
            $errors = $validator->errors();
            foreach ($errors as $field => $messages) {
                $this->addError($messages[0]);
            }
            return null;
        }

        // Hash password
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        unset($data['password_confirmation']);

        // Create user
        $user_id = $this->repository->create($data);

        if ($user_id) {
            // Log activity
            $this->logActivity('user_created', auth_user_id(), [
                'user_id' => $user_id,
                'username' => $data['username'],
            ]);

            // Send welcome notification
            $this->sendNotification($user_id, 'خوش آمدید', 'حسابتان با موفقیت ایجاد شد', 'success');
        } else {
            $this->addError('خطا در ایجاد کاربر');
        }

        return $user_id;
    }

    /**
     * Update user profile
     *
     * @param int $user_id User ID
     * @param array $data Data to update
     * @return bool
     */
    public function update($user_id, $data)
    {
        $this->clearErrors();

        $user = $this->repository->find($user_id);
        if (!$user) {
            $this->addError('کاربر یافت نشد');
            return false;
        }

        // Validate
        $validator = Validator::make($data, [
            'name' => 'required|min:3|max:100',
            'email' => 'required|email',
            'bio' => 'max:500',
        ]);

        if (!$validator->validate()) {
            $errors = $validator->errors();
            foreach ($errors as $field => $messages) {
                $this->addError($messages[0]);
            }
            return false;
        }

        // Update
        $success = $this->repository->update($user_id, $data);

        if ($success) {
            $this->logActivity('user_updated', auth_user_id(), [
                'user_id' => $user_id,
            ]);
        } else {
            $this->addError('خطا در بروزرسانی کاربر');
        }

        return $success;
    }

    /**
     * Change user password
     *
     * @param int $user_id User ID
     * @param string $old_password Old password
     * @param string $new_password New password
     * @return bool
     */
    public function changePassword($user_id, $old_password, $new_password)
    {
        $this->clearErrors();

        $user = $this->repository->find($user_id);
        if (!$user) {
            $this->addError('کاربر یافت نشد');
            return false;
        }

        // Verify old password
        if (!password_verify($old_password, $user['password'])) {
            $this->addError('رمز عبور فعلی نادرست است');
            return false;
        }

        // Validate new password
        if (strlen($new_password) < 8) {
            $this->addError('رمز عبور جدید باید حداقل 8 کاراکتر باشد');
            return false;
        }

        // Update password
        $success = $this->repository->update($user_id, [
            'password' => password_hash($new_password, PASSWORD_BCRYPT),
        ]);

        if ($success) {
            $this->logActivity('password_changed', $user_id, []);
            $this->sendNotification($user_id, 'رمز عبور تغییر کرد', 'رمز عبور شما با موفقیت تغییر کرد', 'success');
        } else {
            $this->addError('خطا در تغییر رمز عبور');
        }

        return $success;
    }

    /**
     * Delete user
     *
     * @param int $user_id User ID
     * @return bool
     */
    public function delete($user_id)
    {
        $this->clearErrors();

        $user = $this->repository->find($user_id);
        if (!$user) {
            $this->addError('کاربر یافت نشد');
            return false;
        }

        $success = $this->repository->delete($user_id);

        if ($success) {
            $this->logActivity('user_deleted', auth_user_id(), [
                'user_id' => $user_id,
                'username' => $user['username'],
            ]);
        } else {
            $this->addError('خطا در حذف کاربر');
        }

        return $success;
    }

    /**
     * Search users
     *
     * @param string $query Search query
     * @return array
     */
    public function search($query)
    {
        return $this->repository->search($query);
    }

    /**
     * Get users with pagination
     *
     * @param int $page Page number
     * @param int $per_page Items per page
     * @return array
     */
    public function paginate($page = 1, $per_page = 20)
    {
        return $this->repository->paginate($page, $per_page, [
            'order_by' => 'created_at DESC',
        ]);
    }
}
