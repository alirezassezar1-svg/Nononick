<?php
/**
 * Nononik — Repository Pattern Base Class
 * Abstract repository for consistent data access
 */

abstract class Repository
{
    protected $pdo;
    protected $table;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Find by primary key
     *
     * @param int $id Primary key value
     * @return array|null
     */
    public function find($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ? LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$id]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Find by specific column
     *
     * @param string $column Column name
     * @param mixed $value Column value
     * @return array|null
     */
    public function findBy($column, $value)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$column} = ? LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$value]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Find all records
     *
     * @param array $options Query options (where, order_by, limit, offset)
     * @return array
     */
    public function findAll($options = [])
    {
        $sql = "SELECT * FROM {$this->table}";

        if (!empty($options['where'])) {
            $sql .= " WHERE " . implode(' AND ', $options['where']);
        }

        if (!empty($options['order_by'])) {
            $sql .= " ORDER BY " . $options['order_by'];
        }

        if (!empty($options['limit'])) {
            $sql .= " LIMIT " . (int)$options['limit'];
        }

        if (!empty($options['offset'])) {
            $sql .= " OFFSET " . (int)$options['offset'];
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($options['params'] ?? []);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Count records
     *
     * @param array $where Where conditions
     * @return int
     */
    public function count($where = [])
    {
        $sql = "SELECT COUNT(*) FROM {$this->table}";

        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();

        return (int)$stmt->fetchColumn();
    }

    /**
     * Create new record
     *
     * @param array $data Record data
     * @return int|false Last insert ID or false
     */
    public function create($data)
    {
        $columns = array_keys($data);
        $placeholders = array_fill(0, count($columns), '?');

        $sql = "INSERT INTO {$this->table} (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array_values($data));
            return $this->pdo->lastInsertId();
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    /**
     * Update record
     *
     * @param int $id Primary key value
     * @param array $data Data to update
     * @return bool
     */
    public function update($id, $data)
    {
        $sets = array_map(fn($key) => "{$key} = ?", array_keys($data));
        $sql = "UPDATE {$this->table} SET " . implode(', ', $sets) . " WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $values = array_values($data);
            $values[] = $id;
            return $stmt->execute($values);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    /**
     * Delete record
     *
     * @param int $id Primary key value
     * @return bool
     */
    public function delete($id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    /**
     * Soft delete record
     *
     * @param int $id Primary key value
     * @return bool
     */
    public function softDelete($id)
    {
        return $this->update($id, ['deleted_at' => date('Y-m-d H:i:s')]);
    }

    /**
     * Restore soft-deleted record
     *
     * @param int $id Primary key value
     * @return bool
     */
    public function restore($id)
    {
        return $this->update($id, ['deleted_at' => null]);
    }

    /**
     * Check if record exists
     *
     * @param int $id Primary key value
     * @return bool
     */
    public function exists($id)
    {
        return $this->find($id) !== null;
    }

    /**
     * Paginate records
     *
     * @param int $page Page number
     * @param int $per_page Items per page
     * @param array $options Additional query options
     * @return array
     */
    public function paginate($page = 1, $per_page = 20, $options = [])
    {
        $page = max(1, (int)$page);
        $per_page = max(1, (int)$per_page);
        $offset = ($page - 1) * $per_page;

        $total = $this->count($options['where'] ?? []);
        $items = $this->findAll(array_merge($options, [
            'limit' => $per_page,
            'offset' => $offset,
        ]));

        return [
            'items' => $items,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $per_page,
                'last_page' => ceil($total / $per_page),
            ],
        ];
    }

    /**
     * Begin transaction
     *
     * @return bool
     */
    public function beginTransaction()
    {
        return $this->pdo->beginTransaction();
    }

    /**
     * Commit transaction
     *
     * @return bool
     */
    public function commit()
    {
        return $this->pdo->commit();
    }

    /**
     * Rollback transaction
     *
     * @return bool
     */
    public function rollback()
    {
        return $this->pdo->rollBack();
    }
}

/**
 * User Repository — Example implementation
 */
class UserRepository extends Repository
{
    protected $table = 'users';

    /**
     * Find user by email
     *
     * @param string $email Email address
     * @return array|null
     */
    public function findByEmail($email)
    {
        return $this->findBy('email', $email);
    }

    /**
     * Find user by username
     *
     * @param string $username Username
     * @return array|null
     */
    public function findByUsername($username)
    {
        return $this->findBy('username', $username);
    }

    /**
     * Get active users
     *
     * @param int $limit Limit
     * @return array
     */
    public function getActive($limit = 10)
    {
        return $this->findAll([
            'where' => ['status = ?'],
            'params' => ['active'],
            'order_by' => 'created_at DESC',
            'limit' => $limit,
        ]);
    }

    /**
     * Get users by role
     *
     * @param string $role Role name
     * @return array
     */
    public function getByRole($role)
    {
        $sql = "SELECT u.* FROM {$this->table} u "
             . "JOIN user_roles ur ON u.id = ur.user_id "
             . "JOIN roles r ON ur.role_id = r.id "
             . "WHERE r.name = ?";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$role]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Count active users
     *
     * @return int
     */
    public function countActive()
    {
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE status = 'active'";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();

        return (int)$stmt->fetchColumn();
    }

    /**
     * Search users
     *
     * @param string $query Search query
     * @return array
     */
    public function search($query)
    {
        $query = "%{$query}%";
        $sql = "SELECT * FROM {$this->table} "
             . "WHERE name LIKE ? OR email LIKE ? OR username LIKE ? "
             . "ORDER BY name ASC LIMIT 20";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$query, $query, $query]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
