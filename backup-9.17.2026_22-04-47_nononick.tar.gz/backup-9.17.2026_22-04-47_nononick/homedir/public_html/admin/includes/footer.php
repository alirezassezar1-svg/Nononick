<script>window.CSRF_TOKEN = "<?= csrf_token() ?>";</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Flip.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/motion.js"></script>
<script src="<?= BASE_URL ?>assets/js/command-palette.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
