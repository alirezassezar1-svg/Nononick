<?php
/**
 * Nononik — DeepSeek API Client
 *
 * چرا: یک کلاس سبک برای ارسال درخواست به DeepSeek Chat Completions API
 * و گرفتن پاسخ متنی. کلید API و مدل از جدول ai_settings خونده می‌شه
 * (نه هاردکد توی فایل) — تا کلید هیچ‌وقت داخل کد قرار نگیره و راحت
 * از پنل ادمین یا phpMyAdmin قابل تغییر باشه.
 *
 * استفاده:
 *   $client = new DeepSeekClient(db());
 *   $res = $client->generateText('نقش/لحن سیستم', 'درخواست کاربر');
 *   if ($res['success']) { echo $res['content']; }
 */

class DeepSeekClient
{
    private PDO $db;
    private string $apiKey;
    private string $apiBase;
    private string $model;

    public function __construct(PDO $db)
    {
        $this->db      = $db;
        $this->apiKey  = $this->setting('deepseek_api_key', '');
        $this->apiBase = rtrim($this->setting('deepseek_api_base', 'https://api.deepseek.com'), '/');
        $this->model   = $this->setting('deepseek_model', 'deepseek-chat');
    }

    private function setting(string $key, string $default = ''): string
    {
        $stmt = $this->db->prepare('SELECT setting_value FROM ai_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return ($val === false || $val === null || $val === '') ? $default : $val;
    }

    public function isConfigured(): bool
    {
        return $this->apiKey !== '';
    }

    /**
     * یک درخواست متنی به DeepSeek می‌فرسته و پاسخ رو برمی‌گردونه.
     *
     * @return array{success:bool, content:string, error:string, raw:array}
     */
    public function generateText(string $systemPrompt, string $userPrompt, int $maxTokens = 800, float $temperature = 0.7): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'content' => '',
                'error'   => 'کلید API دیپ‌سیک تنظیم نشده (ردیف deepseek_api_key در جدول ai_settings خالیه).',
                'raw'     => [],
            ];
        }

        $payload = [
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $userPrompt],
            ],
            'temperature' => $temperature,
            'max_tokens'  => $maxTokens,
        ];

        $ch = curl_init($this->apiBase . '/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey,
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT    => 60,
        ]);

        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError !== '') {
            return ['success' => false, 'content' => '', 'error' => 'خطای اتصال: ' . $curlError, 'raw' => []];
        }

        $data = json_decode((string) $response, true);

        if ($httpCode !== 200 || !isset($data['choices'][0]['message']['content'])) {
            $errMsg = $data['error']['message'] ?? ('پاسخ نامعتبر از DeepSeek (HTTP ' . $httpCode . ')');
            return ['success' => false, 'content' => '', 'error' => $errMsg, 'raw' => $data ?: []];
        }

        return [
            'success' => true,
            'content' => trim($data['choices'][0]['message']['content']),
            'error'   => '',
            'raw'     => $data,
        ];
    }
}
