<?php
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$unreadMessages = db()->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();

function nav_active(string $page, string $current): string {
    return $page === $current ? 'active' : '';
}
?>
<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="logo-cube" aria-hidden="true">
          <div class="logo-cube-inner">
            <div class="face front"></div>
            <div class="face back"></div>
            <div class="face right"></div>
            <div class="face left"></div>
            <div class="face top"></div>
            <div class="face bottom"></div>
          </div>
        </div>
    </div>

    <div class="profile-card">
        <img class="avatar" src="<?= e(image_url($admin['avatar'] ?? null, 'users')) ?>" alt="avatar">
        <h4><?= e($admin['full_name'] ?? 'Admin User') ?></h4>
        <p><?= e($admin['role'] ?? 'مدیر سیستم') ?></p>
        <span class="badge-pro"><i class="fa-solid fa-crown"></i> Pro Member</span>
    </div>

    <nav class="nav-menu">
        <?php if (can('dashboard.view')): ?><a href="index.php" class="<?= nav_active('index.php', $currentPage) ?>"><i class="fa-solid fa-table-cells-large"></i> داشبورد</a><?php endif; ?>
        <?php if (can('projects.view')): ?><a href="projects.php" class="<?= nav_active('projects.php', $currentPage) ?>"><i class="fa-solid fa-folder-open"></i> پروژه‌ها</a><?php endif; ?>
        <?php if (can('services.view')): ?><a href="services.php" class="<?= nav_active('services.php', $currentPage) ?>"><i class="fa-solid fa-layer-group"></i> خدمات</a><?php endif; ?>
        <?php if (can('portfolio.view')): ?><a href="portfolio.php" class="<?= nav_active('portfolio.php', $currentPage) ?>"><i class="fa-solid fa-briefcase"></i> نمونه کارها</a><?php endif; ?>
        <?php if (can('articles.view')): ?><a href="articles.php" class="<?= nav_active('articles.php', $currentPage) ?>"><i class="fa-solid fa-file-lines"></i> مقالات</a><?php endif; ?>
        <?php if (can('users.view')): ?><a href="users.php" class="<?= nav_active('users.php', $currentPage) ?>"><i class="fa-solid fa-users"></i> کاربران</a><?php endif; ?>
        <?php if (can('messages.view')): ?>
        <a href="messages.php" class="<?= nav_active('messages.php', $currentPage) ?>">
            <i class="fa-solid fa-envelope"></i> پیام‌ها
            <?php if ($unreadMessages > 0): ?><span class="count"><?= (int)$unreadMessages ?></span><?php endif; ?>
        </a>
        <?php endif; ?>
        <?php if (can('messages.view')):
            $unreadClientMsgs = (int) db()->query("SELECT COUNT(*) FROM client_messages WHERE sender = 'client' AND is_read = 0")->fetchColumn();
        ?>
        <a href="client-messages.php" class="<?= nav_active('client-messages.php', $currentPage) ?>">
            <i class="fa-solid fa-comments"></i> پیام‌های مشتریان (پنل کاربر)
            <?php if ($unreadClientMsgs > 0): ?><span class="count"><?= $unreadClientMsgs ?></span><?php endif; ?>
        </a>
        <?php endif; ?>
        <?php if (can('tasks.view')): ?><a href="tasks.php" class="<?= nav_active('tasks.php', $currentPage) ?>"><i class="fa-solid fa-list-check"></i> وظایف</a><?php endif; ?>
        <?php if (can('events.view')): ?><a href="events.php" class="<?= nav_active('events.php', $currentPage) ?>"><i class="fa-regular fa-calendar"></i> رویدادها</a><?php endif; ?>
        <?php if (can('admins.view')): ?><a href="admins.php" class="<?= nav_active('admins.php', $currentPage) ?>"><i class="fa-solid fa-user-shield"></i> مدیران</a><?php endif; ?>
        <?php if (can('roles.manage')): ?><a href="roles.php" class="<?= nav_active('roles.php', $currentPage) ?>"><i class="fa-solid fa-key"></i> نقش‌ها و دسترسی‌ها</a><?php endif; ?>
        <?php if (can('settings.manage')): ?><a href="settings.php?tab=text3d" class="<?= ($currentPage === 'settings.php' && ($_GET['tab'] ?? '') === 'text3d') ? 'active' : '' ?>"><i class="fa-solid fa-cube"></i> ویرایشگر سه‌بعدی</a><?php endif; ?>
        <a href="settings.php" class="<?= nav_active('settings.php', $currentPage) ?>"><i class="fa-solid fa-gear"></i> تنظیمات</a>
    </nav>

    <div class="sidebar-bottom">
        <button class="btn-icon" id="themeToggleSidebar" title="حالت روشن/تاریک"><i class="fa-solid fa-circle-half-stroke"></i></button>
        <button class="btn-icon" data-sidebar-toggle title="منو"><i class="fa-solid fa-bars"></i></button>
        <a class="btn-icon" href="logout.php" title="خروج"><i class="fa-solid fa-power-off"></i></a>
    </div>
</aside>
