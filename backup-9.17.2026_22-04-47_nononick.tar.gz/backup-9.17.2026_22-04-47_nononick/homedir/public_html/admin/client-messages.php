<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('messages.view');
$pageTitle = 'پیام‌های مشتریان (پنل کاربر)';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    require_permission('messages.manage');
    $userId = (int) ($_POST['user_id'] ?? 0);
    $text = trim($_POST['message'] ?? '');
    if ($userId && $text !== '') {
        db()->prepare('INSERT INTO client_messages (user_id, sender, message) VALUES (?, "admin", ?)')
            ->execute([$userId, $text]);
    }
    redirect('client-messages.php?user_id=' . $userId);
}

// چرا: لیست مشتریانی که حداقل یک پیام (از خودشان یا ادمین) دارند، به‌همراه تعداد پیام خوانده‌نشده از سمت مشتری
$conversations = db()->query("
    SELECT u.id, u.full_name, u.email, u.avatar,
           MAX(cm.created_at) AS last_at,
           SUM(CASE WHEN cm.sender = 'client' AND cm.is_read = 0 THEN 1 ELSE 0 END) AS unread
    FROM client_messages cm
    JOIN users u ON u.id = cm.user_id
    GROUP BY u.id, u.full_name, u.email, u.avatar
    ORDER BY last_at DESC
")->fetchAll();

$activeUserId = (int) ($_GET['user_id'] ?? ($conversations[0]['id'] ?? 0));
$activeClient = null;
$thread = [];

if ($activeUserId) {
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$activeUserId]);
    $activeClient = $stmt->fetch();

    if ($activeClient) {
        // چرا: با باز کردن گفتگو، پیام‌های ارسالی مشتری برای ادمین خوانده‌شده علامت می‌خورد
        db()->prepare("UPDATE client_messages SET is_read = 1 WHERE user_id = ? AND sender = 'client'")->execute([$activeUserId]);

        $t = db()->prepare('SELECT * FROM client_messages WHERE user_id = ? ORDER BY created_at ASC');
        $t->execute([$activeUserId]);
        $thread = $t->fetchAll();
    }
}

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <div class="page-head">
                <div>
                    <h2>پیام‌های مشتریان</h2>
                    <p class="breadcrumb">داشبورد <b>/ پیام‌های پنل کاربر</b></p>
                </div>
            </div>

            <div class="row" style="align-items:flex-start;">
                <div class="card glass" style="flex:0 0 300px;padding:12px;">
                    <div class="card-head" style="padding:6px 8px;"><h3>گفتگوها</h3></div>
                    <?php if (!$conversations): ?>
                    <div class="empty-state" style="padding:24px 12px;">
                        <i class="fa-regular fa-comments"></i>
                        <h4>هنوز پیامی نیست</h4>
                        <p>وقتی مشتری از پنل کاربر پیام بفرستد، اینجا نمایش داده می‌شود.</p>
                    </div>
                    <?php else: foreach ($conversations as $c): ?>
                    <a href="?user_id=<?= $c['id'] ?>" style="display:flex;align-items:center;gap:10px;padding:10px 8px;border-radius:var(--radius-sm);text-decoration:none;color:inherit;<?= $c['id'] == $activeUserId ? 'background:var(--glass-strong);' : '' ?>">
                        <img class="avatar" style="width:38px;height:38px;" src="<?= e(image_url($c['avatar'] ?? null, 'users')) ?>" alt="">
                        <div style="flex:1;min-width:0;">
                            <div style="font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($c['full_name']) ?></div>
                            <div style="font-size:11.5px;color:var(--text-2);"><?= e(time_ago($c['last_at'])) ?></div>
                        </div>
                        <?php if ($c['unread'] > 0): ?><span class="count"><?= (int)$c['unread'] ?></span><?php endif; ?>
                    </a>
                    <?php endforeach; endif; ?>
                </div>

                <div class="card glass" style="flex:1;display:flex;flex-direction:column;height:min(600px, 70vh);">
                    <?php if (!$activeClient): ?>
                    <div class="empty-state" style="padding:32px 20px;margin:auto;">
                        <i class="fa-regular fa-comment-dots"></i>
                        <h4>گفتگویی انتخاب نشده</h4>
                        <p>یک مشتری را از لیست کنار انتخاب کنید.</p>
                    </div>
                    <?php else: ?>
                    <div class="card-head">
                        <h3><i class="fa-solid fa-user"></i> <?= e($activeClient['full_name']) ?></h3>
                        <span style="font-size:12px;color:var(--text-2)"><?= e($activeClient['email']) ?></span>
                    </div>
                    <div style="flex:1;overflow-y:auto;padding:6px 4px;display:flex;flex-direction:column;gap:12px;">
                        <?php foreach ($thread as $m): $isAdmin = $m['sender'] === 'admin'; ?>
                        <div style="align-self:<?= $isAdmin ? 'flex-start' : 'flex-end' ?>;max-width:75%;">
                            <div style="background:<?= $isAdmin ? 'linear-gradient(135deg, var(--purple), var(--blue))' : 'var(--glass-strong)' ?>;color:<?= $isAdmin ? '#fff' : 'var(--text-0)' ?>;border:1px solid var(--border);border-radius:var(--radius-md);padding:10px 14px;font-size:13.5px;line-height:1.9;">
                                <?= nl2br(e($m['message'])) ?>
                            </div>
                            <small style="display:block;margin-top:4px;color:var(--text-2);font-size:11px;">
                                <?= $isAdmin ? 'شما (تیم Nononik)' : e($activeClient['full_name']) ?> — <?= e(time_ago($m['created_at'])) ?>
                            </small>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (can('messages.manage')): ?>
                    <form method="post" style="display:flex;gap:10px;margin-top:14px;border-top:1px solid var(--border);padding-top:14px;">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="user_id" value="<?= $activeClient['id'] ?>">
                        <input type="text" name="message" class="form-control" placeholder="پاسخ خود را بنویسید..." required autocomplete="off" style="flex:1;">
                        <button type="submit" class="btn btn-primary" style="width:auto;"><i class="fa-solid fa-paper-plane"></i></button>
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
