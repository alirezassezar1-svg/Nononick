<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('tasks.view');
$pageTitle = 'وظایف';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // AJAX toggle (no full csrf redirect flow, but still verify token)
    if ($action === 'toggle') {
        header('Content-Type: application/json');
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
            echo json_encode(['success' => false]);
            exit;
        }
        $id = (int) ($_POST['id'] ?? 0);
        db()->prepare('UPDATE tasks SET is_done = 1 - is_done WHERE id = ?')->execute([$id]);
        echo json_encode(['success' => true]);
        exit;
    }

    csrf_check();
        require_permission('tasks.manage');

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $due = $_POST['due_date'] ?: date('Y-m-d');
        if ($title === '') { set_flash('error', 'عنوان وظیفه الزامی است.'); redirect('tasks.php'); }

        if ($id) {
            db()->prepare('UPDATE tasks SET title=?, due_date=? WHERE id=?')->execute([$title, $due, $id]);
            set_flash('success', 'وظیفه ویرایش شد.');
        } else {
            db()->prepare('INSERT INTO tasks (title, due_date) VALUES (?,?)')->execute([$title, $due]);
            set_flash('success', 'وظیفه جدید اضافه شد.');
        }
        redirect('tasks.php');
    }

    if ($action === 'delete') {
        db()->prepare('DELETE FROM tasks WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]);
        set_flash('success', 'وظیفه حذف شد.');
        redirect('tasks.php');
    }
}

$tasks = db()->query('SELECT * FROM tasks ORDER BY is_done ASC, due_date DESC, id DESC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>مدیریت وظایف</h2><p class="breadcrumb">داشبورد <b>/ وظایف</b></p></div>
                <?php if (can('tasks.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openModal()"><i class="fa-solid fa-plus"></i> وظیفه جدید</button>
                <?php endif; ?>
            </div>

            <div class="card glass">
                <ul class="tasks-list">
                    <?php foreach ($tasks as $t): ?>
                    <li class="<?= $t['is_done'] ? 'done' : '' ?>" style="justify-content:space-between;">
                        <div style="display:flex;align-items:center;gap:12px;">
                            <span class="task-check <?= $t['is_done'] ? 'done' : '' ?>" data-id="<?= $t['id'] ?>">
                                <?php if ($t['is_done']): ?><i class="fa-solid fa-check"></i><?php endif; ?>
                            </span>
                            <span><?= e($t['title']) ?></span>
                        </div>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <small style="color:var(--text-2)"><?= e($t['due_date']) ?></small>
                            <?php if (can('tasks.manage')): ?>
                            <button class="btn-icon btn-sm" onclick='openModal(<?= json_encode($t, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                            <?php endif; ?>
                            <?php if (can('tasks.manage')): ?>
                            <form method="post" onsubmit="return confirm('حذف شود؟')">
                                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                                <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                    <?php if (empty($tasks)): ?><li>وظیفه‌ای ثبت نشده است.</li><?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="tModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="mTitle">وظیفه جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id">
            <div class="form-group"><label>عنوان وظیفه</label><input type="text" name="title" id="f_title" class="form-control" required></div>
            <div class="form-group"><label>تاریخ سررسید</label><input type="date" name="due_date" id="f_due" class="form-control"></div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(data) {
    document.getElementById('tModal').classList.add('show');
    if (data) {
        mTitle.textContent = 'ویرایش وظیفه';
        f_id.value = data.id; f_title.value = data.title; f_due.value = data.due_date;
    } else {
        mTitle.textContent = 'وظیفه جدید';
        document.querySelector('#tModal form').reset(); f_id.value = '';
    }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
