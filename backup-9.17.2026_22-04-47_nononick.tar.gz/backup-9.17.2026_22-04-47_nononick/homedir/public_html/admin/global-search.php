<?php
/**
 * Nononik - Global Live Search
 * چرا: جستجوی سراسری روی داشبورد، جهت دسترسی سریع به پروژه‌ها/کاربران/مقالات/وظایف/رویدادها
 * بدون رفرش صفحه (AJAX) با خروجی JSON.
 *
 * اصلاحیه Audit:
 * - باگ: جدول tasks ستون status ندارد (فقط is_done دارد) — کوئری قبلی با خطای
 *   SQL کرش می‌کرد. اصلاح شد به CASE روی is_done.
 * - امنیت: هر بخش اکنون قبل از کوئری‌زدن، پرمیشن مربوطه را چک می‌کند تا ادمین با
 *   نقش محدود (مثلاً پشتیبان) نتواند از طریق جستجو به داده‌ی ماژول‌هایی که به آن
 *   دسترسی ندارد دست پیدا کند.
 */
require_once __DIR__ . '/includes/auth.php';
header('Content-Type: application/json; charset=utf-8');

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) {
    echo json_encode(['results' => []]);
    exit;
}

$like = '%' . $q . '%';
$results = [];

if (can('projects.view')) {
    $stmt = db()->prepare("SELECT id, title AS label, 'projects.php' AS url, 'پروژه' AS type, status AS meta
                            FROM projects WHERE title LIKE ? OR client_name LIKE ? LIMIT 5");
    $stmt->execute([$like, $like]);
    $results = array_merge($results, $stmt->fetchAll());
}

if (can('articles.view')) {
    $stmt = db()->prepare("SELECT id, title AS label, 'articles.php' AS url, 'مقاله' AS type, status AS meta
                            FROM articles WHERE title LIKE ? LIMIT 5");
    $stmt->execute([$like]);
    $results = array_merge($results, $stmt->fetchAll());
}

if (can('users.view')) {
    $stmt = db()->prepare("SELECT id, full_name AS label, 'users.php' AS url, 'کاربر' AS type, email AS meta
                            FROM users WHERE full_name LIKE ? OR email LIKE ? LIMIT 5");
    $stmt->execute([$like, $like]);
    $results = array_merge($results, $stmt->fetchAll());
}

if (can('tasks.view')) {
    $stmt = db()->prepare("SELECT id, title AS label, 'tasks.php' AS url, 'وظیفه' AS type,
                            CASE WHEN is_done = 1 THEN 'انجام‌شده' ELSE 'در انتظار' END AS meta
                            FROM tasks WHERE title LIKE ? LIMIT 5");
    $stmt->execute([$like]);
    $results = array_merge($results, $stmt->fetchAll());
}

if (can('events.view')) {
    $stmt = db()->prepare("SELECT id, title AS label, 'events.php' AS url, 'رویداد' AS type, event_date AS meta
                            FROM events WHERE title LIKE ? LIMIT 5");
    $stmt->execute([$like]);
    $results = array_merge($results, $stmt->fetchAll());
}

if (can('portfolio.view')) {
    $stmt = db()->prepare("SELECT id, title AS label, 'portfolio.php' AS url, 'نمونه‌کار' AS type, category AS meta
                            FROM portfolio WHERE title LIKE ? LIMIT 5");
    $stmt->execute([$like]);
    $results = array_merge($results, $stmt->fetchAll());
}

echo json_encode(['results' => $results], JSON_UNESCAPED_UNICODE);
