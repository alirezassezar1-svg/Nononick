# ☀️ Sun Panel — Premium Admin Dashboard
## The Best Persian Admin Panel in the World

*بهترین پنل مدیریت فارسی جهان — Premium quality, world-class design, enterprise security*

---

## 🎯 Vision

Sun Panel is not just an admin panel. It's a **world-class experience** built to the standards of Linear, Vercel, Stripe Dashboard, and Raycast. Every pixel, every animation, every interaction is crafted with obsessive attention to detail.

### Core Principles
- **Design Excellence**: Ultra-premium Glassmorphism 2.0, perfect light/dark theme, micro-interactions on everything
- **Performance**: Sub-1.5s FCP, zero CLS, smooth animations at 60fps
- **Security**: OWASP Top 10 compliance, enterprise-grade hardening
- **Accessibility**: WCAG 2.1 AA, perfect RTL, keyboard navigation everywhere
- **Code Quality**: PSR-12, 95%+ type hints, zero warnings, clean architecture
- **Developer Experience**: Intuitive APIs, well-documented, easy to extend

---

## 📦 New Design System (Phase 1)

### Design Tokens (`assets/css/design-tokens.css`)
Comprehensive CSS variables system:

```css
/* Colors */
--color-base-0 through --color-base-7    /* Neutral palette */
--color-purple, --color-blue, --color-cyan, --color-pink /* Brand colors */
--color-success, --color-warning, --color-danger, --color-info /* Semantic colors */

/* Typography */
--font-size-xs through --font-size-4xl   /* 11px to 32px scale */
--font-weight-light through --font-weight-extrabold
--line-height-tight through --line-height-loose

/* Spacing (4px baseline) */
--spacing-1 through --spacing-24         /* 4px to 96px scale */

/* Components */
--radius-xs through --radius-full        /* Border radius scale */
--shadow-glow, --shadow-md, --shadow-lg  /* Depth and elevation */
--transition-fast through --transition-slowest /* Animation timing */

/* Z-Index System */
--z-hide, --z-base, --z-dropdown, --z-modal, --z-tooltip, --z-notification
```

**Usage Pattern:**
```css
.card {
  background-color: var(--color-base-4);
  padding: var(--spacing-6);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-glow);
  transition: all var(--transition-normal);
}
```

### Glassmorphism 2.0 Theme (`assets/css/theme.css`)

**Features:**
- ✨ Perfect light/dark mode implementation with `prefers-color-scheme`
- 🎨 Customizable accent colors (purple, blue, cyan, indigo, pink)
- 🔮 Layered depth system with backdrop-filter blur
- 💫 Smart glow effects context-aware
- 📱 Full responsive from 320px to 4K
- ♿ WCAG 2.1 AA color contrast compliance

**Core Classes:**
```html
<!-- Base glass components -->
<div class="glass">Basic glassmorphism</div>
<div class="glass-card">Elevated card with hover effect</div>
<div class="glass-deep">Deep glass for modals/dropdowns</div>

<!-- Surfaces -->
<div class="surface">Basic surface</div>
<div class="surface-elevated">Elevated surface</div>

<!-- Buttons -->
<button class="btn btn-primary">Primary</button>
<button class="btn btn-secondary">Secondary</button>
<button class="btn btn-danger">Danger</button>
<button class="btn btn-ghost">Ghost</button>
<button class="btn btn-sm">Small</button>
<button class="btn btn-lg">Large</button>
<button class="btn btn-icon">Icon Button</button>
```

### Motion System (`assets/css/motion.css` + `assets/js/motion.js`)

**CSS Animations:**
- Entrance/Exit: fadeIn, slideIn*, zoomIn
- Scroll: parallax, skeletonLoading
- Interactive: pulse, glow, shimmer, bounce, shake
- Page transitions: smooth slide and fade
- Stagger animations for lists

**JavaScript Motion API:**
```javascript
// Auto-initialized on page load
window.motionSystem

// Methods:
motionSystem.staggerAnimate('.items', { stagger: 0.1, duration: 0.5 })
motionSystem.magneticButton(element)
motionSystem.animateNumber(element, 0, 1000, 2)
motionSystem.showToast('Success!', 'success', 3000)
motionSystem.openModal('.modal')
motionSystem.closeModal('.modal')

// Animations respect prefers-reduced-motion
// All animations disabled if user preference set
```

### Component Library (`assets/css/components.css`)

**Pre-built Components:**

1. **Avatar** - Profile pictures with status indicators
   ```html
   <div class="avatar">AB</div>
   <div class="avatar-xs">S</div>
   <div class="avatar-lg"><img src="..." alt=""></div>
   <div class="avatar-status">Online indicator</div>
   <div class="avatar-group">Multiple avatars</div>
   ```

2. **Stat Cards** - KPI display with trends
   ```html
   <div class="stat-card">
     <div class="stat-card-header">
       <div class="stat-card-title">Total Users</div>
       <div class="stat-card-icon">👥</div>
     </div>
     <div class="stat-card-value">1,234</div>
     <div class="stat-card-change positive">+12% this week</div>
   </div>
   ```

3. **Charts** - Chart container with filters
   ```html
   <div class="chart-container">
     <div class="chart-header">
       <div class="chart-title">User Growth</div>
       <div class="chart-controls">
         <button class="chart-filter active">7d</button>
         <button class="chart-filter">30d</button>
       </div>
     </div>
     <!-- Chart.js canvas here -->
   </div>
   ```

4. **Timeline** - Activity timeline
   ```html
   <div class="timeline">
     <div class="timeline-item">
       <div class="timeline-date">Today at 2:30 PM</div>
       <div class="timeline-title">User signed up</div>
       <div class="timeline-description">John Doe</div>
     </div>
   </div>
   ```

5. **Tag Input** - Multi-select tags
   ```html
   <div class="tag-input" id="tagInput">
     <span class="tag">React <span class="tag-close">×</span></span>
     <input type="text" class="tag-input-field" placeholder="Add tag...">
   </div>
   ```

6. **Progress** - Progress bars with animation
   ```html
   <div class="progress-item">
     <div class="progress-label">
       <span>Upload Progress</span>
       <span class="progress-value">45%</span>
     </div>
     <div class="progress-bar">
       <div class="progress-fill" style="width: 45%"></div>
     </div>
   </div>
   ```

7. **Skeleton Loader** - Animated placeholders
   ```html
   <div class="skeleton-card">
     <div class="skeleton-line"></div>
     <div class="skeleton-line short"></div>
     <div class="skeleton-line"></div>
   </div>
   ```

8. **Breadcrumb** - Navigation path
   ```html
   <nav class="breadcrumb">
     <span class="breadcrumb-item">Home</span>
     <span class="breadcrumb-separator">/</span>
     <span class="breadcrumb-item">Dashboard</span>
     <span class="breadcrumb-separator">/</span>
     <span class="breadcrumb-item active">Users</span>
   </nav>
   ```

9. **Empty State** - Meaningful empty messages
   ```html
   <div class="empty-state">
     <div class="empty-state-icon">📭</div>
     <div class="empty-state-title">No items yet</div>
     <div class="empty-state-description">Create your first item to get started</div>
     <div class="empty-state-action">
       <button class="btn btn-primary">Create Item</button>
     </div>
   </div>
   ```

### Command Palette (`assets/css/command-palette.css` + `assets/js/command-palette.js`)

**Raycast-style command palette with Ctrl+K / Cmd+K:**

Features:
- 🔍 Global search with fuzzy matching
- ⌨️ Fully keyboard navigable (↑↓ Enter ESC)
- 🎨 Grouped commands (Navigation, Actions, Help)
- 🏷️ Command badges (e.g., "Dangerous")
- 📱 Responsive (mobile drawer)
- ✨ Smooth animations with GSAP

**Available Commands:**
- Dashboard, Projects, Users, Admins, Tasks, Messages, Settings
- Toggle Theme, Logout
- Keyboard Shortcuts, Global Search

**To Use:**
```javascript
// Open with Ctrl+K or Cmd+K
// Add custom commands:
window.commandPalette.commands.push({
  id: 'custom-action',
  title: 'My Custom Action',
  subtitle: 'Does something awesome',
  icon: 'fa-star',
  group: 'Custom',
  action: () => console.log('Action executed!')
});
```

---

## 🚀 Getting Started

### 1. **Setup Database**
```bash
mysql -u root -p < database.sql
```

### 2. **Configure Connection**
Edit `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'sun_panel_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', 'http://localhost:8000/');
```

### 3. **Run Server**
```bash
php -S localhost:8000
```

### 4. **Login**
- **Username:** `admin`
- **Password:** `Admin@123`

### 5. **Open Command Palette**
Press `Ctrl+K` (or `Cmd+K` on Mac)

---

## 📊 Project Structure

```
sun-panel/
├── assets/
│   ├── css/
│   │   ├── design-tokens.css       ← Design system variables
│   │   ├── theme.css               ← Glassmorphism 2.0 theme
│   │   ├── motion.css              ← Animation keyframes
│   │   ├── components.css          ← Pre-built components
│   │   ├── command-palette.css     ← Command palette styles
│   │   └── style.css               ← Legacy (being refactored)
│   ├── js/
│   │   ├── motion.js               ← GSAP motion system
│   │   ├── command-palette.js      ← Command palette logic
│   │   └── main.js                 ← App initialization
│   └── img/
├── config/
│   └── database.php                ← PDO configuration
├── includes/
│   ├── header.php                  ← HTML head + CSS imports
│   ├── footer.php                  ← JS scripts + closing tags
│   ├── sidebar.php
│   ├── topbar.php
│   ├── auth.php                    ← Authentication logic
│   ├── functions.php               ← Helper functions
│   └── security.php                ← Security functions
├── uploads/
│   ├── projects/
│   ├── portfolio/
│   ├── articles/
│   ├── users/
│   └── site/
├── index.php                       ← Dashboard
├── projects.php, users.php, etc.   ← CRUD pages
├── login.php                       ← Login page
├── logout.php                      ← Logout handler
├── database.sql                    ← Schema + seed data
└── README.md                       ← This file
```

---

## 🎨 Customization

### Change Accent Color

Three ways to set custom accent color:

**1. Via CSS (easiest):**
```html
<html data-accent="cyan">
```

**2. Via JavaScript:**
```javascript
document.documentElement.setAttribute('data-accent', 'indigo');
```

**3. Via User Settings (stored in database):**
```php
$accentColor = setting('accent_color', 'purple');
// Sync to frontend
echo '<html data-accent="' . $accentColor . '">';
```

**Available accent colors:**
- `purple` (default)
- `blue`
- `cyan`
- `indigo`
- `pink`

### Override Design Tokens

In your custom CSS:
```css
:root {
  --color-purple: #7c3aed;  /* Deeper purple */
  --radius-lg: 24px;        /* Larger radius */
  --transition-normal: 300ms; /* Slower transitions */
}
```

### Add Custom Animations

```css
@keyframes myCustomAnimation {
  from { opacity: 0; }
  to { opacity: 1; }
}

.custom-element {
  animation: myCustomAnimation var(--transition-slow);
}
```

---

## ♿ Accessibility

### WCAG 2.1 AA Compliance

- ✅ Keyboard navigation (Tab, Shift+Tab)
- ✅ Focus indicators (visible on all interactive elements)
- ✅ Color contrast ratios (minimum 4.5:1)
- ✅ ARIA labels on icons
- ✅ Semantic HTML structure
- ✅ RTL support perfect
- ✅ Touch targets minimum 44x44px

### Testing

```bash
# Manual keyboard testing
# 1. Press Tab to navigate all elements
# 2. Shift+Tab to go backwards
# 3. Enter/Space to activate
# 4. Arrow keys for lists/tabs

# Color contrast check
# Use WebAIM contrast checker:
# https://webaim.org/resources/contrastchecker/

# Screen reader testing
# Use NVDA (Windows) or VoiceOver (Mac)

# Mobile touch testing
# Ensure all buttons have >=44px targets
```

---

## 🔒 Security Features

### Implemented

- ✅ CSRF Token Protection (all forms)
- ✅ SQL Injection Prevention (Prepared Statements with PDO)
- ✅ XSS Protection (`htmlspecialchars` output escaping)
- ✅ Password Hashing (`password_hash` / `password_verify`)
- ✅ Session Management (secure session_start)
- ✅ Rate Limiting (login attempts)
- ✅ Image Upload Validation (mime-type, size check)
- ✅ Security Headers (CSP, X-Frame-Options, etc.)

### Coming Soon (Phase 5)

- 2FA (TOTP)
- API Key Authentication
- Session Timeout
- IP Whitelisting
- Audit Log Viewer
- Advanced Rate Limiting

---

## ⚡ Performance

### Metrics Target

- **FCP (First Contentful Paint):** < 1.5s
- **LCP (Largest Contentful Paint):** < 2.5s
- **CLS (Cumulative Layout Shift):** 0
- **TTI (Time to Interactive):** < 3s
- **Lighthouse Score:** 95+

### Optimizations Done

- ✅ CSS variables for fast theme switching
- ✅ Lazy loading images with native `loading="lazy"`
- ✅ GSAP for 60fps animations (GPU-accelerated)
- ✅ Minimal external dependencies
- ✅ Preload critical assets
- ✅ Local fonts (Vazirmatn)
- ✅ No blocking render scripts

---

## 🌙 Light/Dark Mode

### Auto Detection
System automatically detects user preference via `prefers-color-scheme`

### Manual Toggle
```javascript
// Toggle theme
const current = localStorage.getItem('sunpanel-theme') || 'dark';
const next = current === 'dark' ? 'light' : 'dark';
localStorage.setItem('sunpanel-theme', next);
document.documentElement.setAttribute('data-theme', next);
```

### Custom Theme Colors

Edit in `design-tokens.css`:

```css
@media (prefers-color-scheme: light) {
  :root {
    --color-base-0:   #ffffff;
    --color-text-0:   #1a1629;
    /* ... */
  }
}
```

---

## 📱 Responsive Design

### Breakpoints

- **XS:** 320px (phones)
- **SM:** 640px (tablets)
- **MD:** 1024px (desktop)
- **LG:** 1280px (large desktop)
- **XL:** 1536px (ultra-wide)

### Usage

```css
/* Mobile-first approach */
.element {
  display: block; /* Small screens */
}

@media (min-width: 640px) {
  .element {
    display: flex; /* Tablets and up */
  }
}

@media (min-width: 1024px) {
  .element {
    display: grid; /* Desktop and up */
  }
}
```

---

## 🧪 Testing

### Manual QA Checklist

- [ ] All pages load without errors
- [ ] Forms submit and validate correctly
- [ ] Images upload and display properly
- [ ] Responsive design works on mobile, tablet, desktop
- [ ] Dark/light theme toggle works
- [ ] Command palette (Ctrl+K) opens and searches
- [ ] Animations smooth (no jank)
- [ ] RTL text alignment correct
- [ ] Keyboard navigation works
- [ ] Performance acceptable (< 2.5s LCP)

---

## 🚀 Deployment

### Requirements

- PHP 8.2+
- MySQL 5.7+
- Apache or Nginx
- SSL certificate (for production)

### Steps

1. **Clone/Copy files to server**
   ```bash
   scp -r sun-panel/ user@server:/var/www/
   ```

2. **Set permissions**
   ```bash
   chmod -R 755 uploads/
   chmod -R 755 logs/
   ```

3. **Update configuration**
   ```php
   // config/database.php
   define('BASE_URL', 'https://yourdomain.com/');
   ```

4. **Enable HTTPS**
   ```apache
   # .htaccess
   RewriteCond %{HTTPS} off
   RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```

---

## 📚 Documentation

### CSS Variables Reference

```
File: assets/css/design-tokens.css

COLORS:
  --color-base-0 to --color-base-7       Main palette
  --color-text-0 to --color-text-4       Text colors
  --color-purple, --color-blue, --color-cyan, --color-pink

TYPOGRAPHY:
  --font-family-primary                   Vazirmatn
  --font-size-xs to --font-size-4xl      Sizes
  --font-weight-light to --font-weight-extrabold
  --line-height-tight to --line-height-loose

SPACING:
  --spacing-1 to --spacing-24             4px scale

RADIUS:
  --radius-xs to --radius-full

SHADOWS:
  --shadow-glow, --shadow-md, --shadow-lg

TRANSITIONS:
  --transition-fast to --transition-slowest

Z-INDEX:
  --z-hide, --z-base, --z-dropdown, --z-modal, --z-tooltip
```

### JavaScript API Reference

```javascript
// Motion System
window.motionSystem.staggerAnimate(selector, options)
window.motionSystem.magneticButton(element)
window.motionSystem.animateNumber(element, from, to, duration)
window.motionSystem.showToast(message, type, duration)
window.motionSystem.openModal(selector)
window.motionSystem.closeModal(selector)

// Command Palette
window.commandPalette.open()
window.commandPalette.close()
window.commandPalette.commands.push({...})
```

---

## 🤝 Contributing

### Code Style

- Follow PSR-12 for PHP
- Use ES6+ for JavaScript
- Comment complex logic
- Keep functions small and focused

### Before Committing

```bash
# Check PHP syntax
php -l includes/functions.php

# Validate CSS (optional, requires npm)
npx stylelint assets/css/*.css

# Check for console errors
# Open browser DevTools console
```

---

## 📜 License

This project is proprietary. All rights reserved.

---

## 👨‍💻 Support

For issues or questions:
1. Check this README first
2. Look at existing code examples
3. Review inline comments
4. Contact development team

---

## 🎉 Credits

Designed and built with obsessive attention to detail to world-class standards.

Built on:
- **GSAP** - Animations and motion
- **Chart.js** - Data visualization
- **Vazirmatn** - Persian typography
- **FontAwesome** - Icons

---

**Sun Panel — The Best Persian Admin Panel in the World ☀️**

Last Updated: 2026-07-27
Version: 2.0 (Design System Complete)
