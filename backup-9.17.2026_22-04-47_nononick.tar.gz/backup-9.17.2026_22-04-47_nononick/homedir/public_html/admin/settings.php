<?php
require_once __DIR__ . '/includes/auth.php';
$pageTitle = 'تنظیمات';
$metaDescription = 'تنظیمات پروفایل، امنیت و سئوی پنل Nononik';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $oldAvatar = $admin['avatar'] ?? null;
        $avatar = upload_image($_FILES['avatar'] ?? [], 'users', $oldAvatar);

        if ($fullName === '' || $email === '') {
            set_flash('error', 'نام و ایمیل الزامی است.');
        } else {
            $stmt = db()->prepare('UPDATE admins SET full_name = ?, email = ?, avatar = ? WHERE id = ?');
            $stmt->execute([$fullName, $email, $avatar, $admin['id']]);
            set_flash('success', 'پروفایل با موفقیت به‌روزرسانی شد.');
        }
        redirect('settings.php');
    }

    if ($action === 'update_password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $admin['password'])) {
            set_flash('error', 'رمز عبور فعلی صحیح نیست.');
        } elseif (mb_strlen($new) < 8) {
            set_flash('error', 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.');
        } elseif ($new !== $confirm) {
            set_flash('error', 'تکرار رمز عبور مطابقت ندارد.');
        } else {
            $stmt = db()->prepare('UPDATE admins SET password = ? WHERE id = ?');
            $stmt->execute([password_hash($new, PASSWORD_BCRYPT), $admin['id']]);
            set_flash('success', 'رمز عبور با موفقیت تغییر کرد.');
        }
        redirect('settings.php');
    }

    if ($action === 'update_seo') {
        require_permission('settings.manage');
        set_setting('site_title', trim($_POST['site_title'] ?? ''));
        set_setting('site_description', trim($_POST['site_description'] ?? ''));
        set_setting('seo_keywords', trim($_POST['seo_keywords'] ?? ''));
        set_setting('contact_email', trim($_POST['contact_email'] ?? ''));
        set_flash('success', 'تنظیمات سئو ذخیره شد.');
        redirect('settings.php');
    }

    if ($action === 'update_logo') {
        require_permission('settings.manage');
        $oldLogo = setting('site_logo', '');
        $oldLogoFile = $oldLogo ? basename($oldLogo) : null;
        $logo = upload_image($_FILES['logo'] ?? [], 'site', $oldLogoFile);
        if ($logo) {
            set_setting('site_logo', image_url($logo, 'site'));
        }
        $oldOg = setting('og_image', '');
        $oldOgFile = $oldOg ? basename($oldOg) : null;
        $og = upload_image($_FILES['og_image'] ?? [], 'site', $oldOgFile);
        if ($og) {
            set_setting('og_image', image_url($og, 'site'));
        }
        set_flash('success', 'تصاویر سایت به‌روزرسانی شد.');
        redirect('settings.php');
    }
    if ($action === 'update_sms') {
        require_permission('settings.manage');
        set_setting('sms_enabled', isset($_POST['sms_enabled']) ? '1' : '0');
        set_setting('sms_provider', in_array($_POST['sms_provider'] ?? '', ['kavenegar', 'melipayamak'], true) ? $_POST['sms_provider'] : 'kavenegar');
        set_setting('sms_api_key', trim($_POST['sms_api_key'] ?? ''));
        set_setting('sms_username', trim($_POST['sms_username'] ?? ''));
        set_setting('sms_password', trim($_POST['sms_password'] ?? ''));
        set_setting('sms_sender_number', trim(to_english_digits($_POST['sms_sender_number'] ?? '')));
        set_setting('sms_admin_number', trim(to_english_digits($_POST['sms_admin_number'] ?? '')));
        set_setting('footer_contact_phone_raw', trim($_POST['contact_phone'] ?? ''));
        if (trim($_POST['contact_phone'] ?? '') !== '') {
            // چرا: همین شماره در فوتر (ویرایش زنده) و دکمه‌ی تماس هدر هم استفاده می‌شود
            $stmt = db()->prepare('INSERT INTO page_content (block_key, content) VALUES (?, ?) ON DUPLICATE KEY UPDATE content = VALUES(content)');
            $stmt->execute(['footer_contact_phone', trim($_POST['contact_phone'])]);
        }
        set_flash('success', 'تنظیمات تماس و پیامک ذخیره شد.');
        redirect('settings.php?tab=sms');
    }

    if ($action === 'update_text3d') {
        require_permission('settings.manage');
        $fields = ['text3d_blue1', 'text3d_blue2', 'text3d_pink1', 'text3d_pink2'];
        foreach ($fields as $f) {
            $val = trim($_POST[$f] ?? '');
            if (preg_match('/^#[0-9a-fA-F]{6}$/', $val)) {
                set_setting($f, $val);
            }
        }
        set_flash('success', 'رنگ‌های سه‌بعدی ذخیره شد.');
        redirect('settings.php?tab=text3d');
    }
}

$tab = $_GET['tab'] ?? 'profile';

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>

    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>

        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>">
                    <i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?>
                </div>
            <?php endif; ?>

            <div class="page-head">
                <div>
                    <h2>تنظیمات</h2>
                    <p class="breadcrumb">داشبورد <b>/ تنظیمات</b></p>
                </div>
            </div>

            <div class="settings-tabs">
                <a href="?tab=profile" class="<?= $tab === 'profile' ? 'active' : '' ?>"><i class="fa-regular fa-user"></i> پروفایل</a>
                <a href="?tab=security" class="<?= $tab === 'security' ? 'active' : '' ?>"><i class="fa-solid fa-shield-halved"></i> امنیت</a>
                <?php if (can('settings.manage')): ?>
                <a href="?tab=seo" class="<?= $tab === 'seo' ? 'active' : '' ?>"><i class="fa-solid fa-magnifying-glass-chart"></i> سئو</a>
                <a href="?tab=branding" class="<?= $tab === 'branding' ? 'active' : '' ?>"><i class="fa-regular fa-image"></i> لوگو و برندینگ</a>
                <a href="?tab=sms" class="<?= $tab === 'sms' ? 'active' : '' ?>"><i class="fa-solid fa-comment-sms"></i> تماس و پیامک</a>
                <a href="?tab=text3d" class="<?= $tab === 'text3d' ? 'active' : '' ?>"><i class="fa-solid fa-cube"></i> ویرایشگر زنده</a>
                <?php endif; ?>
            </div>

            <?php if ($tab === 'profile'): ?>
            <div class="card glass settings-card">
                <div class="card-head"><h3>اطلاعات پروفایل</h3></div>
                <form method="post" enctype="multipart/form-data" class="settings-form">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="update_profile">
                    <div class="avatar-upload">
                        <img src="<?= e(image_url($admin['avatar'] ?? null, 'users')) ?>" alt="">
                        <label class="btn btn-outline">
                            <i class="fa-solid fa-camera"></i> تغییر تصویر
                            <input type="file" name="avatar" accept="image/*" style="display:none">
                        </label>
                    </div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label>نام کامل</label>
                            <input type="text" name="full_name" value="<?= e($admin['full_name']) ?>" required>
                        </div>
                        <div class="form-field">
                            <label>ایمیل</label>
                            <input type="email" name="email" value="<?= e($admin['email']) ?>" required>
                        </div>
                    </div>
                    <button class="btn btn-primary" style="width:auto"><i class="fa-solid fa-floppy-disk"></i> ذخیره تغییرات</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($tab === 'security'): ?>
            <div class="card glass settings-card">
                <div class="card-head"><h3>تغییر رمز عبور</h3></div>
                <form method="post" class="settings-form">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="update_password">
                    <div class="form-grid">
                        <div class="form-field">
                            <label>رمز عبور فعلی</label>
                            <input type="password" name="current_password" required>
                        </div>
                        <div class="form-field">
                            <label>رمز عبور جدید</label>
                            <input type="password" name="new_password" minlength="8" required>
                        </div>
                        <div class="form-field">
                            <label>تکرار رمز عبور جدید</label>
                            <input type="password" name="confirm_password" minlength="8" required>
                        </div>
                    </div>
                    <button class="btn btn-primary" style="width:auto"><i class="fa-solid fa-key"></i> به‌روزرسانی رمز عبور</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($tab === 'seo' && can('settings.manage')): ?>
            <div class="card glass settings-card">
                <div class="card-head"><h3>تنظیمات سئو و متادیتا</h3></div>
                <form method="post" class="settings-form">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="update_seo">
                    <div class="form-grid">
                        <div class="form-field">
                            <label>عنوان سایت (Title)</label>
                            <input type="text" name="site_title" value="<?= e(setting('site_title')) ?>">
                        </div>
                        <div class="form-field">
                            <label>ایمیل تماس</label>
                            <input type="email" name="contact_email" value="<?= e(setting('contact_email')) ?>">
                        </div>
                        <div class="form-field" style="grid-column:1/-1">
                            <label>توضیحات متا (Meta Description)</label>
                            <textarea name="site_description" rows="3"><?= e(setting('site_description')) ?></textarea>
                        </div>
                        <div class="form-field" style="grid-column:1/-1">
                            <label>کلمات کلیدی (Keywords)</label>
                            <input type="text" name="seo_keywords" value="<?= e(setting('seo_keywords')) ?>">
                        </div>
                    </div>
                    <button class="btn btn-primary" style="width:auto"><i class="fa-solid fa-floppy-disk"></i> ذخیره تنظیمات سئو</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($tab === 'branding' && can('settings.manage')): ?>
            <div class="card glass settings-card">
                <div class="card-head"><h3>لوگو و تصویر اشتراک‌گذاری (OG Image)</h3></div>
                <form method="post" enctype="multipart/form-data" class="settings-form">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="update_logo">
                    <div class="form-grid">
                        <div class="form-field">
                            <label>لوگوی سایت</label>
                            <?php if (setting('site_logo')): ?><img src="<?= e(setting('site_logo')) ?>" style="height:44px;margin-bottom:8px;border-radius:8px"><?php endif; ?>
                            <input type="file" name="logo" accept="image/*">
                        </div>
                        <div class="form-field">
                            <label>تصویر OG (اشتراک‌گذاری شبکه‌های اجتماعی)</label>
                            <?php if (setting('og_image')): ?><img src="<?= e(setting('og_image')) ?>" style="height:44px;margin-bottom:8px;border-radius:8px"><?php endif; ?>
                            <input type="file" name="og_image" accept="image/*">
                        </div>
                    </div>
                    <button class="btn btn-primary" style="width:auto"><i class="fa-solid fa-floppy-disk"></i> ذخیره تصاویر</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($tab === 'sms' && can('settings.manage')): ?>
            <div class="card glass settings-card">
                <div class="card-head"><h3>شماره تماس و کلید تماس هدر سایت</h3></div>
                <p style="color:var(--text-2);font-size:13px;margin-bottom:14px;">
                    این شماره در دکمه‌ی تماس هدر سایت (لینک تلفن مستقیم) و در فوتر نمایش داده می‌شود.
                </p>
                <form method="post" class="settings-form">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="update_sms">
                    <div class="form-grid">
                        <div class="form-field">
                            <label>شماره تماس نمایشی سایت</label>
                            <input type="text" name="contact_phone" placeholder="۰۲۱-۰۰۰۰۰۰۰" value="<?= e(page_content('footer_contact_phone', '')) ?>">
                        </div>
                        <div class="form-field">
                            <label>شماره موبایل مدیر (دریافت پیامک پیام‌های جدید)</label>
                            <input type="text" name="sms_admin_number" placeholder="09xxxxxxxxx" value="<?= e(setting('sms_admin_number')) ?>">
                        </div>
                    </div>

                    <div class="card-head" style="margin-top:22px;"><h3>وب‌سرویس پیامک</h3></div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label style="display:flex;align-items:center;gap:8px;">
                                <input type="checkbox" name="sms_enabled" value="1" <?= setting('sms_enabled') === '1' ? 'checked' : '' ?> style="width:auto;">
                                فعال‌سازی ارسال پیامک برای «تماس با ما» و «مشاوره رایگان»
                            </label>
                        </div>
                        <div class="form-field">
                            <label>سرویس‌دهنده پیامک</label>
                            <select name="sms_provider">
                                <option value="kavenegar" <?= setting('sms_provider', 'kavenegar') === 'kavenegar' ? 'selected' : '' ?>>کاوه‌نگار (Kavenegar)</option>
                                <option value="melipayamak" <?= setting('sms_provider') === 'melipayamak' ? 'selected' : '' ?>>ملی‌پیامک (Melipayamak)</option>
                            </select>
                        </div>
                        <div class="form-field">
                            <label>کلید API (کاوه‌نگار)</label>
                            <input type="text" name="sms_api_key" value="<?= e(setting('sms_api_key')) ?>">
                        </div>
                        <div class="form-field">
                            <label>نام کاربری (ملی‌پیامک)</label>
                            <input type="text" name="sms_username" value="<?= e(setting('sms_username')) ?>">
                        </div>
                        <div class="form-field">
                            <label>رمز عبور (ملی‌پیامک)</label>
                            <input type="password" name="sms_password" value="<?= e(setting('sms_password')) ?>">
                        </div>
                        <div class="form-field">
                            <label>شماره فرستنده پیامک</label>
                            <input type="text" name="sms_sender_number" value="<?= e(setting('sms_sender_number')) ?>">
                        </div>
                    </div>
                    <button class="btn btn-primary" style="width:auto"><i class="fa-solid fa-floppy-disk"></i> ذخیره تنظیمات تماس و پیامک</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($tab === 'text3d' && can('settings.manage')):
                $b1 = setting('text3d_blue1', '#c4b5fd');
                $b2 = setting('text3d_blue2', '#60a5fa');
                $p1 = setting('text3d_pink1', '#f0abfc');
                $p2 = setting('text3d_pink2', '#c084fc');
            ?>
            <div class="card glass settings-card">
                <div class="card-head"><h3>ویرایشگر زنده‌ی جلوه‌ی سه‌بعدی نوشته‌ها</h3></div>
                <p style="color:var(--text-2);font-size:13px;margin-bottom:18px;">
                    این ۴ رنگ، پایه‌ی افکت سه‌بعدی/نئونیِ همه‌ی تیترهای پنل ادمین، پنل کاربری و سایت هستند.
                    با تغییر هر رنگ، پیش‌نمایش پایین همین لحظه به‌روزرسانی می‌شود؛ برای اعمال روی کل سایت «ذخیره» را بزنید.
                </p>

                <div id="t3dPreview" style="border-radius:16px;padding:32px 24px;text-align:center;background:var(--bg-1,#0c0a1a);margin-bottom:26px;border:1px solid var(--border);
                    --text-3d-blue-1: <?= e($b1) ?>; --text-3d-blue-2: <?= e($b2) ?>;
                    --text-3d-pink-1: <?= e($p1) ?>; --text-3d-pink-2: <?= e($p2) ?>;">
                    <h1 style="margin-bottom:10px;">عنوان اصلی — Nononic</h1>
                    <h2>عنوان بخش نمونه</h2>
                </div>

                <form method="post" class="settings-form" id="t3dForm">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="update_text3d">
                    <div class="form-grid">
                        <div class="form-field">
                            <label>رنگ اول گرادیان آبی (تیتر اصلی/برند)</label>
                            <input type="color" name="text3d_blue1" id="text3d_blue1" value="<?= e($b1) ?>" style="height:44px;padding:6px;">
                        </div>
                        <div class="form-field">
                            <label>رنگ دوم گرادیان آبی (تیتر اصلی/برند)</label>
                            <input type="color" name="text3d_blue2" id="text3d_blue2" value="<?= e($b2) ?>" style="height:44px;padding:6px;">
                        </div>
                        <div class="form-field">
                            <label>رنگ اول گرادیان صورتی (تیترهای فرعی)</label>
                            <input type="color" name="text3d_pink1" id="text3d_pink1" value="<?= e($p1) ?>" style="height:44px;padding:6px;">
                        </div>
                        <div class="form-field">
                            <label>رنگ دوم گرادیان صورتی (تیترهای فرعی)</label>
                            <input type="color" name="text3d_pink2" id="text3d_pink2" value="<?= e($p2) ?>" style="height:44px;padding:6px;">
                        </div>
                    </div>
                    <button class="btn btn-primary" style="width:auto"><i class="fa-solid fa-floppy-disk"></i> ذخیره و اعمال روی کل سایت</button>
                </form>
            </div>

            <script>
            (function () {
                var preview = document.getElementById('t3dPreview');
                var map = { text3d_blue1: '--text-3d-blue-1', text3d_blue2: '--text-3d-blue-2', text3d_pink1: '--text-3d-pink-1', text3d_pink2: '--text-3d-pink-2' };
                Object.keys(map).forEach(function (id) {
                    var input = document.getElementById(id);
                    input.addEventListener('input', function () {
                        preview.style.setProperty(map[id], input.value);
                    });
                });
            })();
            </script>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
