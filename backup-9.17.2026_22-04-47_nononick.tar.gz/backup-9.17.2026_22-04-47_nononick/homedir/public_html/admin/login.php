<?php
require_once __DIR__ . '/includes/auth.php';

if (!empty($_SESSION['admin_id'])) {
    redirect('index.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'لطفاً نام کاربری و رمز عبور را وارد کنید.';
    } elseif (login_is_rate_limited($username)) {
        // چرا: محدودسازی Brute-force — حداکثر ۵ تلاش ناموفق در ۱۵ دقیقه (به‌ازای IP یا نام‌کاربری)
        $error = 'به‌دلیل تلاش‌های ناموفق زیاد، حساب موقتاً قفل شده است. لطفاً ۱۵ دقیقه دیگر تلاش کنید.';
        security_log('login_blocked', "username={$username}");
    } else {
        $stmt = db()->prepare('SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            login_record_attempt($username, true);
            login_attempts_cleanup();
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $user['id'];
            db()->prepare('UPDATE admins SET last_login = NOW() WHERE id = ?')->execute([$user['id']]);
            redirect('index.php');
        } else {
            login_record_attempt($username, false);
            $error = 'نام کاربری یا رمز عبور اشتباه است.';
        }
    }
}

$pageTitle = 'ورود به سیستم';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ورود | Nononik</title>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="icon" href="<?= BASE_URL ?>assets/images/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="192x192" href="<?= BASE_URL ?>assets/images/favicon-192x192.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= BASE_URL ?>assets/images/apple-touch-icon.png">
<link rel="manifest" href="<?= BASE_URL ?>assets/images/site.webmanifest">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="login-card glass">
        <div class="logo">
            <img src="<?= BASE_URL ?>assets/images/logo-mark-white-128.png" width="34" height="34" alt="Nononik" style="width:34px;height:34px;object-fit:contain;">
        </div>
        <h1>ورود به پنل مدیریت</h1>
        <p>Nononik Admin Dashboard</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" novalidate>
            <div class="form-group">
                <label>نام کاربری یا ایمیل</label>
                <input type="text" name="username" class="form-control" placeholder="admin" required value="<?= e($_POST['username'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>رمز عبور</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-right-to-bracket"></i> ورود</button>
        </form>

        <div class="demo-hint">
            کاربر آزمایشی: <b>admin</b> &nbsp; | &nbsp; رمز عبور: <b>Admin@123</b>
        </div>
    </div>
</div>
</body>
</html>
