# 🚀 Sun Panel - Setup & Testing Guide

## ✅ Phase 1-2 Installation & Testing

تمام کدهای Phase 1 و Phase 2 **آماده استفاده** است. این guide شامل راهنمای نصب و تست کامل است.

---

## 📋 Requirements

- **PHP**: 8.2+
- **MySQL**: 5.7+
- **Browser**: Modern (Chrome, Firefox, Safari, Edge)
- **Server**: Apache/Nginx with PHP support

---

## 🛠️ Installation Steps

### 1️⃣ Database Setup

```bash
# وارد MySQL شوید و دیتابیس را تنظیم کنید
mysql -u root -p

# در MySQL:
CREATE DATABASE sun_panel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sun_panel;
SOURCE database.sql;
```

### 2️⃣ Configuration

ویرایش `config/database.php`:
```php
return [
    'host' => 'localhost',
    'db' => 'sun_panel',
    'user' => 'root',
    'password' => 'your_password',
    'charset' => 'utf8mb4'
];
```

### 3️⃣ Server Setup

**Apache (.htaccess موجود است):**
```bash
# فعال کنید mod_rewrite
sudo a2enmod rewrite
sudo systemctl restart apache2
```

**Local Testing (PHP Built-in Server):**
```bash
cd /path/to/sun-panel
php -S localhost:8000
```

### 4️⃣ Verify Installation

چک کنید که تمام فایل‌ها موجود هستند:
```bash
✅ assets/css/design-tokens.css
✅ assets/css/theme.css
✅ assets/css/motion.css
✅ assets/css/components.css
✅ assets/css/command-palette.css
✅ assets/js/motion.js
✅ assets/js/command-palette.js
✅ includes/Response.php
✅ includes/Validator.php
✅ includes/Repository.php
✅ includes/Service.php
✅ config/app.php
✅ DESIGN_SYSTEM.md
✅ PHASE2_ARCHITECTURE.md
```

---

## 🧪 Testing Phase 1 & 2

### ✅ Test 1: Design System (طراحی)

**URL:** `http://localhost:8000/` (Dashboard)

**چی چک کنید:**

1. **رنگ‌ها و تم:**
   - [ ] تم تاریک خوب نمایان است
   - [ ] دکمه‌ها رنگ gradient دارند
   - [ ] کارت‌ها اثر glassmorphism دارند
   - [ ] Sidebar و navbar سبک‌تر نشان می‌دهند

2. **انیمیشن‌ها:**
   - [ ] صفحه با transition صاف بارگذاری می‌شود
   - [ ] دکمه‌ها hover شان جادویی است (magnetic effect)
   - [ ] Skeleton loading برای کارت‌های محتوا
   - [ ] رول کردن صفحه انیمیشن‌های parallax دارد

3. **Command Palette:**
   - [ ] `Ctrl+K` را فشار دهید
   - [ ] جستجو کنید (مثلاً "user" یا "dashboard")
   - [ ] نتایج نمایش داده می‌شوند
   - [ ] `Escape` برای بستن

4. **Responsive:**
   - [ ] تغییر اندازه‌ی صفحه (320px تا 4K)
   - [ ] تمام کامپوننت‌ها responsive است
   - [ ] تاچ فریندلی برای موبایل

---

### ✅ Test 2: Architecture (معماری)

**فایل‌های مربوطه:**
- `includes/Response.php` - API responses
- `includes/Validator.php` - Form validation
- `includes/Repository.php` - Data access
- `includes/Service.php` - Business logic

**چگونه تست کنید:**

#### A) Validator تست کنید

```php
<?php
// test-validator.php
require 'includes/Validator.php';

$validator = new Validator();
$validator->validate([
    'email' => 'test@example.com',
    'password' => '12345678'
], [
    'email' => 'required|email',
    'password' => 'required|min:8'
]);

if ($validator->fails()) {
    echo "❌ Errors:\n";
    print_r($validator->getErrors());
} else {
    echo "✅ Valid!\n";
}
?>
```

#### B) Response تست کنید

```php
<?php
// test-response.php
require 'includes/Response.php';

// Success response
Response::success('کاربر ایجاد شد', ['id' => 1]);

// Error response
Response::error('خطای سرور', 500);

// Validation error
Response::validationError(['email' => 'ایمیل معتبر نیست']);
?>
```

#### C) Repository تست کنید

```php
<?php
// test-repository.php
require 'config/database.php';
require 'includes/Repository.php';
require 'includes/UserRepository.php'; // اگر ایجاد شده باشد

$userRepo = new UserRepository();
$users = $userRepo->all();
echo "تعداد کاربران: " . count($users);
?>
```

---

### ✅ Test 3: Security Headers

**Console (DevTools) را بررسی کنید:**

```bash
Ctrl+Shift+I → Network → Headers
```

**چی چک کنید:**
- [ ] `X-Content-Type-Options: nosniff`
- [ ] `X-Frame-Options: SAMEORIGIN`
- [ ] `X-XSS-Protection: 1; mode=block`
- [ ] `Referrer-Policy: strict-origin-when-cross-origin`
- [ ] `Content-Security-Policy` موجود است

---

### ✅ Test 4: RTL (فارسی راست‌چین)

**تمام صفحات را بررسی کنید:**
- [ ] متن راست‌چین است
- [ ] Input fields RTL هستند
- [ ] Sidebar از راست است
- [ ] Navbar درست نمایان است

---

## 🎨 Customization

### رنگ پرند‌ی (Accent Color) تغییر دهید

**File:** `assets/css/design-tokens.css`

```css
:root {
  /* تغییر از آبی/بنفش به سبز مثلاً */
  --accent-600: #10b981;    /* سبز */
  --accent-500: #34d399;
  --accent-400: #6ee7b7;
  /* ... */
}
```

### تم روشن (Light Mode)

**File:** `assets/css/theme.css`

```css
@media (prefers-color-scheme: light) {
  /* روشن‌تر کنید */
  :root {
    --bg-primary: #ffffff;
    --text-primary: #1f2937;
    /* ... */
  }
}
```

---

## 📊 Project Structure

```
sun-panel/
├── 📁 assets/
│   ├── 📁 css/
│   │   ├── design-tokens.css     # متغیرهای CSS
│   │   ├── theme.css              # تم Glassmorphism
│   │   ├── motion.css             # انیمیشن‌ها
│   │   ├── components.css         # کامپوننت‌های آماده
│   │   └── command-palette.css    # جستجو
│   └── 📁 js/
│       ├── motion.js              # GSAP utilities
│       └── command-palette.js     # جستجو logic
├── 📁 includes/
│   ├── Response.php               # API responses
│   ├── Validator.php              # Validation
│   ├── Repository.php             # Data access
│   ├── Service.php                # Business logic
│   ├── header.php
│   ├── footer.php
│   └── security.php
├── 📁 config/
│   ├── app.php                    # تنظیمات
│   └── database.php               # اتصال DB
├── 📁 pages/
│   ├── dashboard.php
│   ├── users.php
│   ├── projects.php
│   └── ...
├── index.php                      # صفحه‌ی اصلی
├── DESIGN_SYSTEM.md               # مستندات طراحی
├── PHASE2_ARCHITECTURE.md         # مستندات معماری
└── ROADMAP.md                     # نقشه‌راه
```

---

## 🐛 Troubleshooting

### ❌ Database connection error
```bash
# چک کنید:
- MySQL راه‌اندازی است؟
- Credentials درست هستند؟
- Database ایجاد شده؟
```

### ❌ CSS/JS not loading
```bash
# chmod تغییر دهید:
chmod -R 755 assets/
```

### ❌ 404 errors on pages
```bash
# .htaccess فعال است؟
# mod_rewrite فعال است؟
```

### ❌ Animations not working
```bash
# GSAP فایل موجود است؟
# Browser آپدیت است؟
# prefers-reduced-motion را غیرفعال کنید
```

---

## 📝 Usage Examples

### فرم جدید + Validation

```php
<?php
// pages/create-user.php
require 'includes/Validator.php';

if ($_POST) {
    $validator = new Validator();
    $validator->validate($_POST, [
        'name' => 'required|min:3',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:8|confirmed',
    ]);

    if ($validator->fails()) {
        $errors = $validator->getErrors();
        // نمایش خطاها
    } else {
        // ذخیره کاربر
    }
}
?>
```

### API Endpoint جدید

```php
<?php
// api/users.php
require 'includes/Response.php';
require 'includes/UserService.php';

$service = new UserService();

if ($_POST['action'] === 'create') {
    try {
        $user = $service->createUser($_POST);
        Response::success('کاربر ایجاد شد', $user);
    } catch (Exception $e) {
        Response::error($e->getMessage(), 400);
    }
}
?>
```

### Component استفاده کنید

```html
<!-- کارت glassmorphic -->
<div class="glass glass-lg shadow-lg p-6 rounded-xl">
    <h2>عنوان</h2>
    <p>محتوا</p>
</div>

<!-- دکمه magnetic -->
<button class="btn btn-primary magnetic">
    کلیک کنید
</button>

<!-- Avatar -->
<div class="avatar avatar-lg">
    <img src="user.jpg" alt="User" />
</div>
```

---

## 🚀 Next Steps (Phase 3)

بعد از تست موفق:

1. **Phase 3 شروع:** Dashboard & Analytics
2. **Database migrations** اجرا کنید
3. **Real data** اضافه کنید
4. **Performance** تست کنید

---

## 📞 Support

اگر سؤالی دارید:

1. `DESIGN_SYSTEM.md` بخوانید
2. `PHASE2_ARCHITECTURE.md` بخوانید
3. مستقیم بپرسید! 🎯

---

**Ready? Start testing! 🧪✨**

```bash
# شروع کنید:
php -S localhost:8000

# سپس رفتید:
http://localhost:8000
```
