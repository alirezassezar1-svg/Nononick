<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('events.view');
$pageTitle = 'رویدادها';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
        require_permission('events.manage');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $date = $_POST['event_date'] ?? '';
        $time = $_POST['event_time'] ?: null;
        $color = $_POST['color'] ?: '#8b5cf6';
        $desc = trim($_POST['description'] ?? '');

        if ($title === '' || $date === '') { set_flash('error', 'عنوان و تاریخ رویداد الزامی است.'); redirect('events.php'); }

        if ($id) {
            db()->prepare('UPDATE events SET title=?, event_date=?, event_time=?, color=?, description=? WHERE id=?')
                ->execute([$title, $date, $time, $color, $desc, $id]);
            set_flash('success', 'رویداد ویرایش شد.');
        } else {
            db()->prepare('INSERT INTO events (title, event_date, event_time, color, description) VALUES (?,?,?,?,?)')
                ->execute([$title, $date, $time, $color, $desc]);
            set_flash('success', 'رویداد جدید ایجاد شد.');
        }
        redirect('events.php');
    }

    if ($action === 'delete') {
        db()->prepare('DELETE FROM events WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]);
        set_flash('success', 'رویداد حذف شد.');
        redirect('events.php');
    }
}

$events = db()->query('SELECT * FROM events ORDER BY event_date ASC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>رویدادها و تقویم</h2><p class="breadcrumb">داشبورد <b>/ رویدادها</b></p></div>
                <?php if (can('events.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openModal()"><i class="fa-solid fa-plus"></i> ایجاد رویداد جدید</button>
                <?php endif; ?>
            </div>

            <div class="events-list">
                <?php foreach ($events as $ev): ?>
                <div class="event-row glass">
                    <div class="date-box" style="background:<?= e($ev['color']) ?>">
                        <span style="font-size:17px;"><?= date('d', strtotime($ev['event_date'])) ?></span>
                        <span style="font-size:10px;opacity:.85;"><?= date('M', strtotime($ev['event_date'])) ?></span>
                    </div>
                    <div style="flex:1">
                        <b style="font-size:14px;"><?= e($ev['title']) ?></b>
                        <p style="font-size:12.5px;color:var(--text-2);margin-top:4px;">
                            <?= e($ev['event_date']) ?><?= $ev['event_time'] ? ' — ' . e($ev['event_time']) : '' ?>
                            <?php if ($ev['description']): ?> · <?= e($ev['description']) ?><?php endif; ?>
                        </p>
                    </div>
                    <div class="actions-cell">
                        <?php if (can('events.manage')): ?>
                        <button class="btn-icon btn-sm" onclick='openModal(<?= json_encode($ev, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                        <?php endif; ?>
                        <?php if (can('events.manage')): ?>
                        <form method="post" onsubmit="return confirm('حذف شود؟')">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $ev['id'] ?>">
                            <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if (empty($events)): ?><p style="color:var(--text-2);text-align:center;padding:30px">رویدادی ثبت نشده است.</p><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="eModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="mTitle">رویداد جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id">
            <div class="form-group"><label>عنوان رویداد</label><input type="text" name="title" id="f_title" class="form-control" required></div>
            <div class="form-row">
                <div class="form-group"><label>تاریخ</label><input type="date" name="event_date" id="f_date" class="form-control" required></div>
                <div class="form-group"><label>ساعت</label><input type="time" name="event_time" id="f_time" class="form-control"></div>
            </div>
            <div class="form-group"><label>رنگ</label><input type="color" name="color" id="f_color" class="form-control" value="#8b5cf6" style="height:44px;padding:6px;"></div>
            <div class="form-group"><label>توضیحات</label><input type="text" name="description" id="f_desc" class="form-control"></div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(data) {
    document.getElementById('eModal').classList.add('show');
    if (data) {
        mTitle.textContent = 'ویرایش رویداد';
        f_id.value = data.id; f_title.value = data.title; f_date.value = data.event_date;
        f_time.value = data.event_time || ''; f_color.value = data.color; f_desc.value = data.description || '';
    } else {
        mTitle.textContent = 'رویداد جدید';
        document.querySelector('#eModal form').reset(); f_id.value = '';
    }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
