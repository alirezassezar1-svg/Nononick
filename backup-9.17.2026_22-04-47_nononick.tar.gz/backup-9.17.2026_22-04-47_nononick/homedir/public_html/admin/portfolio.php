<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('portfolio.view');
$pageTitle = 'نمونه کارها';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // حذف AJAX یک تصویر گالری (بدون رفرش کل صفحه، همان الگوی tasks.php)
    if ($action === 'delete_image') {
        header('Content-Type: application/json');
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '') || !can('portfolio.manage')) {
            echo json_encode(['success' => false]);
            exit;
        }
        $imgId = (int) ($_POST['image_id'] ?? 0);
        $stmt = db()->prepare('SELECT image FROM portfolio_images WHERE id = ?');
        $stmt->execute([$imgId]);
        if ($file = $stmt->fetchColumn()) {
            @unlink(UPLOAD_DIR . 'portfolio/' . $file);
            db()->prepare('DELETE FROM portfolio_images WHERE id = ?')->execute([$imgId]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        exit;
    }

    // حذف AJAX یک فایل پیوست (همان الگوی delete_image، برای media_assets)
    if ($action === 'delete_asset') {
        header('Content-Type: application/json');
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '') || !can('portfolio.manage')) {
            echo json_encode(['success' => false]);
            exit;
        }
        $assetId = (int) ($_POST['asset_id'] ?? 0);
        $stmt = db()->prepare("SELECT file_name FROM media_assets WHERE id = ? AND module = 'portfolio'");
        $stmt->execute([$assetId]);
        if ($file = $stmt->fetchColumn()) {
            @unlink(UPLOAD_DIR . 'portfolio/assets/' . $file);
            db()->prepare('DELETE FROM media_assets WHERE id = ?')->execute([$assetId]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        exit;
    }

    csrf_check();
        require_permission('portfolio.manage');

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $link = trim($_POST['link'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        // چرا: برای اینکه هر نمونه‌کار یک URL اختصاصی و قابل‌ایندکس داشته باشه
        // (portfolio-single.php?slug=...) دقیقاً همان الگوی articles.php
        $slug = trim($_POST['slug'] ?? '') ?: strtolower(preg_replace('/\s+/', '-', $title));
        // یکتاسازی ساده: اگه اسلاگ تکراری بود، آیدی بهش اضافه می‌شه
        $slugCheck = db()->prepare('SELECT id FROM portfolio WHERE slug = ? AND id != ?');
        $slugCheck->execute([$slug, $id ?: 0]);
        if ($slugCheck->fetch()) {
            $slug .= '-' . substr(uniqid(), -5);
        }

        if ($title === '') { set_flash('error', 'عنوان الزامی است.'); redirect('portfolio.php'); }

        $oldImage = null;
        if ($id) {
            $stmt = db()->prepare('SELECT image FROM portfolio WHERE id = ?');
            $stmt->execute([$id]);
            $oldImage = $stmt->fetchColumn();
        }
        $image = upload_image($_FILES['image'] ?? [], 'portfolio', $oldImage ?: null);

        if ($id) {
            db()->prepare('UPDATE portfolio SET title=?, slug=?, category=?, image=?, link=?, description=? WHERE id=?')
                ->execute([$title, $slug, $category, $image, $link, $desc, $id]);
            $portfolioId = $id;
            set_flash('success', 'نمونه کار ویرایش شد.');
        } else {
            db()->prepare('INSERT INTO portfolio (title, slug, category, image, link, description) VALUES (?,?,?,?,?,?)')
                ->execute([$title, $slug, $category, $image, $link, $desc]);
            $portfolioId = (int) db()->lastInsertId();
            set_flash('success', 'نمونه کار جدید اضافه شد.');
        }

        // هرچند عکس که کاربر برای گالری انتخاب کرده باشد، همه ذخیره می‌شوند
        $galleryFiles = upload_gallery_images($_FILES['gallery'] ?? [], 'portfolio');
        if ($galleryFiles) {
            $stmt = db()->prepare('INSERT INTO portfolio_images (portfolio_id, image) VALUES (?, ?)');
            foreach ($galleryFiles as $file) {
                $stmt->execute([$portfolioId, $file]);
            }
        }

        // فایل‌های پیوست عمومی (HTML/GLB/GLTF/PDF/... — خروجی ابزار AI)
        if (!empty($_FILES['assets']['name'][0] ?? '')) {
            $stmt = db()->prepare(
                'INSERT INTO media_assets (module, item_id, file_name, original_name, ext, mime_type, size_bytes) VALUES (?,?,?,?,?,?,?)'
            );
            $count = count($_FILES['assets']['name']);
            for ($i = 0; $i < $count; $i++) {
                if (($_FILES['assets']['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
                $single = [
                    'name'     => $_FILES['assets']['name'][$i],
                    'tmp_name' => $_FILES['assets']['tmp_name'][$i] ?? '',
                    'error'    => $_FILES['assets']['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                    'size'     => $_FILES['assets']['size'][$i] ?? 0,
                ];
                $saved = upload_asset_file($single, 'portfolio');
                if ($saved) {
                    $stmt->execute(['portfolio', $portfolioId, $saved['file_name'], $saved['original_name'], $saved['ext'], $saved['mime_type'], $saved['size_bytes']]);
                } else {
                    set_flash('error', 'فایل «' . e($single['name']) . '» رد شد (پسوند/حجم/نوع مجاز نیست).');
                }
            }
        }

        redirect('portfolio.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = db()->prepare('SELECT image FROM portfolio WHERE id = ?');
        $stmt->execute([$id]);
        if ($img = $stmt->fetchColumn()) @unlink(UPLOAD_DIR . 'portfolio/' . $img);

        // فایل‌های گالری هم از دیسک پاک شوند (ردیف‌های جدول با ON DELETE CASCADE خودکار حذف می‌شوند)
        $stmt = db()->prepare('SELECT image FROM portfolio_images WHERE portfolio_id = ?');
        $stmt->execute([$id]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $gimg) {
            @unlink(UPLOAD_DIR . 'portfolio/' . $gimg);
        }

        $stmt = db()->prepare("SELECT file_name FROM media_assets WHERE module='portfolio' AND item_id = ?");
        $stmt->execute([$id]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $af) {
            @unlink(UPLOAD_DIR . 'portfolio/assets/' . $af);
        }
        db()->prepare("DELETE FROM media_assets WHERE module='portfolio' AND item_id = ?")->execute([$id]);

        db()->prepare('DELETE FROM portfolio WHERE id = ?')->execute([$id]);
        set_flash('success', 'نمونه کار حذف شد.');
        redirect('portfolio.php');
    }
}

$items = db()->query('SELECT * FROM portfolio ORDER BY created_at DESC')->fetchAll();

// گالری همه‌ی موارد را یک‌جا می‌گیریم و بر اساس portfolio_id گروه‌بندی می‌کنیم
$galleryByItem = [];
$galleryRows = db()->query('SELECT id, portfolio_id, image FROM portfolio_images ORDER BY sort_order, id')->fetchAll();
foreach ($galleryRows as $g) {
    $galleryByItem[$g['portfolio_id']][] = ['id' => $g['id'], 'image' => $g['image']];
}
$assetsByItem = [];
$assetRows = db()->query("SELECT * FROM media_assets WHERE module='portfolio' ORDER BY created_at DESC")->fetchAll();
foreach ($assetRows as $ar) {
    $assetsByItem[$ar['item_id']][] = $ar;
}

foreach ($items as &$it) {
    $it['gallery'] = $galleryByItem[$it['id']] ?? [];
    $it['assets']  = $assetsByItem[$it['id']] ?? [];
}
unset($it);

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>نمونه کارها</h2><p class="breadcrumb">داشبورد <b>/ نمونه کارها</b></p></div>
                <?php if (can('portfolio.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openModal()"><i class="fa-solid fa-plus"></i> افزودن نمونه کار</button>
                <?php endif; ?>
            </div>

            <div class="projects-grid">
                <?php foreach ($items as $p): ?>
                <div class="project-tile glass">
                    <img loading="lazy" decoding="async" class="thumb" src="<?= e(image_url($p['image'], 'portfolio')) ?>" alt="">
                    <div class="info">
                        <b><?= e($p['title']) ?></b>
                        <small><?= e($p['category']) ?></small>
                        <div class="actions-cell" style="margin-top:10px;">
                            <?php if (can('portfolio.manage')): ?>
                            <button class="btn-icon btn-sm" onclick='openModal(<?= json_encode($p, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                            <?php endif; ?>
                            <?php if (can('portfolio.manage')): ?>
                            <form method="post" onsubmit="return confirm('حذف شود؟')">
                                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if (empty($items)): ?><p style="color:var(--text-2)">نمونه کاری ثبت نشده است.</p><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="pModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="mTitle">نمونه کار جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id">
            <div class="form-group">
                <label>تصویر شاخص</label>
                <img id="f_preview" class="current-image" src="<?= e(image_url(null, 'portfolio')) ?>">
                <input type="file" name="image" class="form-control" accept="image/*" data-preview="#f_preview">
            </div>
            <div class="form-group">
                <label>گالری تصاویر (هر تعداد عکس که بخواهید، هم‌زمان قابل انتخاب است)</label>
                <div class="gallery-preview" id="f_gallery_existing"></div>
                <input type="file" name="gallery[]" id="f_gallery" class="form-control" accept="image/*" multiple>
                <div class="gallery-preview" id="f_gallery_new"></div>
            </div>
            <div class="form-group">
                <label>فایل پیوست (HTML، GLB/GLTF، PDF، ZIP، ویدیو، JSON — خروجی ابزار AI هم اینجا آپلود می‌شود)</label>
                <div class="gallery-preview" id="f_assets_existing"></div>
                <input type="file" name="assets[]" id="f_assets" class="form-control" multiple accept=".html,.htm,.svg,.glb,.gltf,.pdf,.zip,.mp4,.webm,.json">
                <small style="color:var(--text-2)">حداکثر ۳۰ مگابایت برای هر فایل.</small>
            </div>
            <div class="form-row">
                <div class="form-group"><label>عنوان</label><input type="text" name="title" id="f_title" class="form-control" required></div>
                <div class="form-group"><label>دسته‌بندی</label><input type="text" name="category" id="f_cat" class="form-control"></div>
            </div>
            <div class="form-group"><label>لینک نمونه کار</label><input type="text" name="link" id="f_link" class="form-control" placeholder="https://"></div>
            <div class="form-group"><label>توضیحات</label><textarea name="description" id="f_desc" class="form-control"></textarea></div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
const GALLERY_BASE = '<?= UPLOAD_URL ?>portfolio/';

function renderExistingGallery(items) {
    const box = document.getElementById('f_gallery_existing');
    box.innerHTML = '';
    (items || []).forEach(img => {
        const wrap = document.createElement('div');
        wrap.className = 'gallery-thumb';
        wrap.innerHTML = `<img src="${GALLERY_BASE}${img.image}" alt="">
            <button type="button" class="gallery-thumb-remove" title="حذف عکس"><i class="fa-solid fa-xmark"></i></button>`;
        wrap.querySelector('.gallery-thumb-remove').addEventListener('click', () => deleteGalleryImage(img.id, wrap));
        box.appendChild(wrap);
    });
}

function deleteGalleryImage(imageId, el) {
    if (!confirm('این عکس از گالری حذف شود؟')) return;
    fetch('portfolio.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=delete_image&image_id=${encodeURIComponent(imageId)}&csrf_token=${encodeURIComponent('<?= csrf_token() ?>')}`
    }).then(r => r.json()).then(res => {
        if (res.success) el.remove();
    });
}

const ASSET_ICONS = { html:'fa-code', htm:'fa-code', svg:'fa-bezier-curve', glb:'fa-cube', gltf:'fa-cube', pdf:'fa-file-pdf', zip:'fa-file-zipper', mp4:'fa-file-video', webm:'fa-file-video', json:'fa-file-code' };

function renderExistingAssets(items) {
    const box = document.getElementById('f_assets_existing');
    box.innerHTML = '';
    (items || []).forEach(a => {
        const isEmbeddable = ['html','htm','svg'].includes(a.ext);
        const wrap = document.createElement('div');
        wrap.className = 'gallery-thumb';
        wrap.style.cssText = 'display:flex;align-items:center;gap:8px;padding:8px 10px;width:auto';
        wrap.innerHTML = `<i class="fa-solid ${ASSET_ICONS[a.ext] || 'fa-file'}"></i>
            <span style="font-size:12.5px">${a.original_name || a.file_name}</span>
            ${isEmbeddable
                ? `<a href="asset-embed.php?id=${a.id}" target="_blank" title="پیش‌نمایش" class="btn-icon btn-sm"><i class="fa-solid fa-eye"></i></a>`
                : `<a href="<?= UPLOAD_URL ?>portfolio/assets/${a.file_name}" target="_blank" title="دانلود" class="btn-icon btn-sm"><i class="fa-solid fa-download"></i></a>`}
            <button type="button" class="gallery-thumb-remove" title="حذف فایل"><i class="fa-solid fa-xmark"></i></button>`;
        wrap.querySelector('.gallery-thumb-remove').addEventListener('click', () => deleteAsset(a.id, wrap));
        box.appendChild(wrap);
    });
}

function deleteAsset(assetId, el) {
    if (!confirm('این فایل پیوست حذف شود؟')) return;
    fetch('portfolio.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=delete_asset&asset_id=${encodeURIComponent(assetId)}&csrf_token=${encodeURIComponent('<?= csrf_token() ?>')}`
    }).then(r => r.json()).then(res => {
        if (res.success) el.remove();
    });
}

// پیش‌نمایش عکس‌های تازه انتخاب‌شده (قبل از ارسال فرم)
document.getElementById('f_gallery').addEventListener('change', function () {
    const box = document.getElementById('f_gallery_new');
    box.innerHTML = '';
    Array.from(this.files).forEach(file => {
        const wrap = document.createElement('div');
        wrap.className = 'gallery-thumb';
        wrap.innerHTML = `<img src="${URL.createObjectURL(file)}" alt="">`;
        box.appendChild(wrap);
    });
});

function openModal(data) {
    document.getElementById('pModal').classList.add('show');
    document.getElementById('f_gallery_new').innerHTML = '';
    document.getElementById('f_gallery').value = '';
    document.getElementById('f_assets').value = '';
    if (data) {
        mTitle.textContent = 'ویرایش نمونه کار';
        f_id.value = data.id; f_title.value = data.title; f_cat.value = data.category || '';
        f_link.value = data.link || ''; f_desc.value = data.description || '';
        f_preview.src = data.image ? '<?= UPLOAD_URL ?>portfolio/' + data.image : '<?= e(image_url(null, "portfolio")) ?>';
        renderExistingGallery(data.gallery);
        renderExistingAssets(data.assets);
    } else {
        mTitle.textContent = 'نمونه کار جدید';
        document.querySelector('#pModal form').reset(); f_id.value = '';
        f_preview.src = '<?= e(image_url(null, "portfolio")) ?>';
        renderExistingGallery([]);
        renderExistingAssets([]);
    }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
