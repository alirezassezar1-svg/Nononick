<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('users.view');
$pageTitle = 'کاربران';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
        require_permission('users.manage');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $role = trim($_POST['role'] ?? 'مشتری');
        $status = $_POST['status'] ?? 'active';

        if ($name === '' || $email === '') { set_flash('error', 'نام و ایمیل الزامی است.'); redirect('users.php'); }

        $oldAvatar = null;
        if ($id) {
            $stmt = db()->prepare('SELECT avatar FROM users WHERE id = ?');
            $stmt->execute([$id]);
            $oldAvatar = $stmt->fetchColumn();
        }
        $avatar = upload_image($_FILES['avatar'] ?? [], 'users', $oldAvatar ?: null);

        if ($id) {
            db()->prepare('UPDATE users SET full_name=?, email=?, phone=?, avatar=?, role=?, status=? WHERE id=?')
                ->execute([$name, $email, $phone, $avatar, $role, $status, $id]);
            set_flash('success', 'کاربر ویرایش شد.');
        } else {
            db()->prepare('INSERT INTO users (full_name, email, phone, avatar, role, status) VALUES (?,?,?,?,?,?)')
                ->execute([$name, $email, $phone, $avatar, $role, $status]);
            set_flash('success', 'کاربر جدید اضافه شد.');
        }
        redirect('users.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = db()->prepare('SELECT avatar FROM users WHERE id = ?');
        $stmt->execute([$id]);
        if ($img = $stmt->fetchColumn()) @unlink(UPLOAD_DIR . 'users/' . $img);
        db()->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
        set_flash('success', 'کاربر حذف شد.');
        redirect('users.php');
    }
}

$users = db()->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>مدیریت کاربران</h2><p class="breadcrumb">داشبورد <b>/ کاربران</b></p></div>
                <?php if (can('users.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="openModal()"><i class="fa-solid fa-plus"></i> کاربر جدید</button>
                <?php endif; ?>
            </div>

            <div class="table-card glass">
                <table class="data-table">
                    <thead><tr><th>کاربر</th><th>ایمیل</th><th>موبایل</th><th>نقش</th><th>وضعیت</th><th>تاریخ عضویت</th><th>عملیات</th></tr></thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td style="display:flex;align-items:center;gap:10px;">
                                <img loading="lazy" decoding="async" class="row-thumb" style="border-radius:50%" src="<?= e(image_url($u['avatar'], 'users')) ?>" alt="">
                                <b><?= e($u['full_name']) ?></b>
                            </td>
                            <td><?= e($u['email']) ?></td>
                            <td><?= e($u['phone']) ?></td>
                            <td><?= e($u['role']) ?></td>
                            <td><span class="badge badge-<?= e($u['status']) ?>"><?= e(status_label($u['status'])) ?></span></td>
                            <td><?= time_ago($u['created_at']) ?></td>
                            <td class="actions-cell">
                                <?php if (can('users.manage')): ?>
                                <button class="btn-icon btn-sm" onclick='openModal(<?= json_encode($u, JSON_UNESCAPED_UNICODE) ?>)'><i class="fa-solid fa-pen"></i></button>
                                <?php endif; ?>
                                <?php if (can('users.manage')): ?>
                                <form method="post" onsubmit="return confirm('حذف شود؟')">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $u['id'] ?>">
                                    <button type="submit" class="btn-icon btn-sm" style="color:#f87171"><i class="fa-solid fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($users)): ?><tr><td colspan="7" style="text-align:center;color:var(--text-2);padding:30px">کاربری ثبت نشده است.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="uModal">
    <div class="modal-box">
        <div class="modal-head"><h3 id="mTitle">کاربر جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="f_id">
            <div class="form-group">
                <label>تصویر پروفایل</label>
                <img id="f_preview" class="current-image" style="border-radius:50%" src="<?= e(image_url(null, 'users')) ?>">
                <input type="file" name="avatar" class="form-control" accept="image/*" data-preview="#f_preview">
            </div>
            <div class="form-row">
                <div class="form-group"><label>نام کامل</label><input type="text" name="full_name" id="f_name" class="form-control" required></div>
                <div class="form-group"><label>ایمیل</label><input type="email" name="email" id="f_email" class="form-control" required></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>موبایل</label><input type="text" name="phone" id="f_phone" class="form-control"></div>
                <div class="form-group"><label>نقش</label><input type="text" name="role" id="f_role" class="form-control" value="مشتری"></div>
            </div>
            <div class="form-group">
                <label>وضعیت</label>
                <select name="status" id="f_status" class="form-control">
                    <option value="active">فعال</option>
                    <option value="inactive">غیرفعال</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(data) {
    document.getElementById('uModal').classList.add('show');
    if (data) {
        mTitle.textContent = 'ویرایش کاربر';
        f_id.value = data.id; f_name.value = data.full_name; f_email.value = data.email;
        f_phone.value = data.phone || ''; f_role.value = data.role; f_status.value = data.status;
        f_preview.src = data.avatar ? '<?= UPLOAD_URL ?>users/' + data.avatar : '<?= e(image_url(null, "users")) ?>';
    } else {
        mTitle.textContent = 'کاربر جدید';
        document.querySelector('#uModal form').reset(); f_id.value = '';
        f_preview.src = '<?= e(image_url(null, "users")) ?>';
    }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
