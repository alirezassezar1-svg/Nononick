<?php
require_once __DIR__ . '/includes/auth.php';
require_permission('messages.view');
$pageTitle = 'پیام ها';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
        require_permission('messages.manage');
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'read') {
        db()->prepare('UPDATE messages SET is_read = 1 WHERE id = ?')->execute([$id]);
        redirect('messages.php');
    }
    if ($action === 'delete') {
        db()->prepare('DELETE FROM messages WHERE id = ?')->execute([$id]);
        set_flash('success', 'پیام حذف شد.');
        redirect('messages.php');
    }
    if ($action === 'save') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');
        if ($name && $email && $message) {
            db()->prepare('INSERT INTO messages (name, email, subject, message) VALUES (?,?,?,?)')
                ->execute([$name, $email, $subject, $message]);
            set_flash('success', 'پیام ثبت شد.');
        }
        redirect('messages.php');
    }
}

$messages = db()->query('SELECT * FROM messages ORDER BY is_read ASC, created_at DESC')->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <div class="page-head">
                <div><h2>صندوق پیام‌ها</h2><p class="breadcrumb">داشبورد <b>/ پیام‌ها</b></p></div>
                <?php if (can('messages.manage')): ?>
                <button class="btn btn-primary" style="width:auto" onclick="document.getElementById('mModal').classList.add('show')"><i class="fa-solid fa-plus"></i> ثبت پیام</button>
                <?php endif; ?>
            </div>

            <?php foreach ($messages as $m): ?>
            <div class="message-item glass <?= $m['is_read'] ? '' : 'unread' ?>">
                <div class="avatar-sq"><?= mb_substr($m['name'], 0, 1) ?></div>
                <div style="flex:1">
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
                        <b style="font-size:14px;"><?= e($m['name']) ?> <small style="color:var(--text-2);font-weight:400;">— <?= e($m['email']) ?><?php if (!empty($m['phone'])): ?> — <a href="tel:<?= e($m['phone']) ?>" style="color:var(--purple-2)"><i class="fa-solid fa-phone"></i> <?= e($m['phone']) ?></a><?php endif; ?></small></b>
                        <small style="color:var(--text-2)"><?= time_ago($m['created_at']) ?></small>
                    </div>
                    <p style="font-size:12.5px;color:var(--purple-2);margin:6px 0 4px;"><?= e($m['subject'] ?: 'بدون موضوع') ?></p>
                    <p style="font-size:13px;color:var(--text-1);line-height:1.9;"><?= nl2br(e($m['message'])) ?></p>
                    <div class="actions-cell" style="margin-top:12px;">
                        <?php if (!$m['is_read']): ?>
                        <form method="post"><input type="hidden" name="csrf_token" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="read"><input type="hidden" name="id" value="<?= $m['id'] ?>">
                            <button class="btn btn-outline btn-sm" type="submit"><i class="fa-solid fa-envelope-open"></i> علامت‌گذاری خوانده‌شده</button>
                        </form>
                        <?php endif; ?>
                        <?php if (can('messages.manage')): ?>
                        <form method="post" onsubmit="return confirm('حذف شود؟')"><input type="hidden" name="csrf_token" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $m['id'] ?>">
                            <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash"></i> حذف</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (empty($messages)): ?><p style="color:var(--text-2);text-align:center;padding:30px">پیامی وجود ندارد.</p><?php endif; ?>
        </div>
    </div>
</div>

<div class="modal-overlay" id="mModal">
    <div class="modal-box">
        <div class="modal-head"><h3>ثبت پیام جدید</h3><button class="close-modal" data-modal-close><i class="fa-solid fa-xmark"></i></button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="save">
            <div class="form-row">
                <div class="form-group"><label>نام</label><input type="text" name="name" class="form-control" required></div>
                <div class="form-group"><label>ایمیل</label><input type="email" name="email" class="form-control" required></div>
            </div>
            <div class="form-group"><label>موضوع</label><input type="text" name="subject" class="form-control"></div>
            <div class="form-group"><label>متن پیام</label><textarea name="message" class="form-control" required></textarea></div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" data-modal-close>انصراف</button>
                <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ثبت</button>
            </div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
