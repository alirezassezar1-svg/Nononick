<?php
/**
 * Nononik — تولید خودکار sitemap.xml
 *
 * چرا لازم بود: sitemap.xml قبلی فقط ۵ تا صفحه‌ی ثابت (خانه/خدمات/نمونه‌کارها/
 * مقالات/تماس) داشت و هیچ‌کدوم از مقاله‌ها یا نمونه‌کارهای تک‌تک توش نبودن،
 * چون اصلاً URL اختصاصی نداشتن. این اسکریپت فایل sitemap.xml رو از نو
 * می‌سازه و تمام مقاله‌های منتشرشده + نمونه‌کارها رو هم اضافه می‌کنه.
 *
 * نحوه‌ی اجرا:
 *   ۱) همین الان یک‌بار دستی توی مرورگر باز کن: https://nononick.ir/sitemap-generate.php
 *      (بعد از باز شدن، sitemap.xml آپدیت می‌شه)
 *   ۲) توصیه می‌شه در cPanel → Cron Jobs یک جاب روزانه بسازی که همین آدرس رو
 *      فراخوانی کنه (مثلاً هر روز ساعت ۴ بامداد) تا بعد از هر مقاله/نمونه‌کار
 *      جدید، sitemap خودکار به‌روز بمونه:
 *      curl -s https://nononick.ir/sitemap-generate.php > /dev/null
 */
require_once __DIR__ . '/config/database.php';

$siteDomain = 'https://nononick.ir';

$staticPages = [
    ['loc' => '/',              'changefreq' => 'weekly',  'priority' => '1.0'],
    ['loc' => '/services.php',  'changefreq' => 'monthly', 'priority' => '0.8'],
    ['loc' => '/portfolio.php', 'changefreq' => 'weekly',  'priority' => '0.8'],
    ['loc' => '/blog.php',      'changefreq' => 'weekly',  'priority' => '0.6'],
    ['loc' => '/contact.php',   'changefreq' => 'monthly', 'priority' => '0.7'],
];

$xml = new XMLWriter();
$xml->openMemory();
$xml->setIndent(true);
$xml->startDocument('1.0', 'UTF-8');
$xml->startElement('urlset');
$xml->writeAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');

foreach ($staticPages as $p) {
    $xml->startElement('url');
    $xml->writeElement('loc', $siteDomain . $p['loc']);
    $xml->writeElement('changefreq', $p['changefreq']);
    $xml->writeElement('priority', $p['priority']);
    $xml->endElement();
}

// مقالات منتشرشده
$articles = db()->query("SELECT slug, created_at FROM articles WHERE status = 'published' AND slug IS NOT NULL AND slug != ''")->fetchAll();
foreach ($articles as $a) {
    $xml->startElement('url');
    $xml->writeElement('loc', $siteDomain . '/blog-single.php?slug=' . rawurlencode($a['slug']));
    $xml->writeElement('lastmod', date('Y-m-d', strtotime($a['created_at'])));
    $xml->writeElement('changefreq', 'monthly');
    $xml->writeElement('priority', '0.6');
    $xml->endElement();
}

// نمونه‌کارها
$portfolioItems = db()->query("SELECT slug, created_at FROM portfolio WHERE slug IS NOT NULL AND slug != ''")->fetchAll();
foreach ($portfolioItems as $p) {
    $xml->startElement('url');
    $xml->writeElement('loc', $siteDomain . '/portfolio-single.php?slug=' . rawurlencode($p['slug']));
    $xml->writeElement('lastmod', date('Y-m-d', strtotime($p['created_at'])));
    $xml->writeElement('changefreq', 'monthly');
    $xml->writeElement('priority', '0.7');
    $xml->endElement();
}

$xml->endElement(); // urlset
$xml->endDocument();

file_put_contents(__DIR__ . '/sitemap.xml', $xml->outputMemory());

$total = count($staticPages) + count($articles) + count($portfolioItems);
header('Content-Type: text/plain; charset=utf-8');
echo "sitemap.xml با موفقیت به‌روزرسانی شد — {$total} آدرس ثبت شد.\n";
echo "- صفحات ثابت: " . count($staticPages) . "\n";
echo "- مقالات: " . count($articles) . "\n";
echo "- نمونه‌کارها: " . count($portfolioItems) . "\n";
